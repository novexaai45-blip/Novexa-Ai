import { useState, useEffect, useRef, useCallback } from "react";
import { initializeApp } from "firebase/app";
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged } from "firebase/auth";

/* -------- Firebase Config -------- */
const firebaseConfig = {
  apiKey: "AIzaSyBYdBy_DZduoJ9iHj_brcafFZ8xpkQR9Qk",
  authDomain: "novexa-ai-4d9da.firebaseapp.com",
  projectId: "novexa-ai-4d9da",
  storageBucket: "novexa-ai-4d9da.firebasestorage.app",
  messagingSenderId: "605886298883",
  appId: "1:605886298883:web:e01633c3891edb97ed8736",
  measurementId: "G-8S6CQ0NB7P"
};
const firebaseApp = initializeApp(firebaseConfig);
const firebaseAuth = getAuth(firebaseApp);
const googleProvider = new GoogleAuthProvider();
import {
  Send, Plus, Trash2, Pencil, Copy, Check, Sun, Moon, Settings as SettingsIcon,
  LogOut, Menu, X, Loader2, Sparkles, Globe, Eye, EyeOff, AlertCircle, User as UserIcon,
  Mic, MicOff, Volume2, VolumeX, Download, Share2, ChevronRight,
  MessageSquare, GraduationCap, UploadCloud, FileText, FileSpreadsheet, FileType2,
  NotebookPen, ListChecks, Layers, Calculator, BookOpenCheck, ArrowLeft, RotateCcw,
  ChevronLeft, Trash, Paperclip,
  Code2, Bug, Terminal, PenLine, Newspaper, Mail, Briefcase, SpellCheck,
  Wand2, FileCode2, Play, Code,
  Search, BarChart3, ShieldCheck, Cloud, FileDown, Database, TrendingUp, MapPin, FilePlus2,
  Phone, PhoneOff, PhoneCall, PhoneMissed, Radio, Zap, History, Gauge, Languages,
  WifiOff, Signal, StopCircle, PlayCircle,
  Image, ImagePlus, Palette, RefreshCw, ZoomIn, ExternalLink, Star, Grid3x3,
  Crop, Film, Brush, Pencil as PencilIcon, Box, Clapperboard, Maximize2,
  Camera, SwitchCamera,
} from "lucide-react";
import mammoth from "mammoth";
import * as XLSX from "xlsx";

/* ========================= SUBSCRIPTION PLANS ========================= */
const PLANS = {
  free: {
    id: "free",
    name: "Free",
    price: "₹0",
    priceEn: "$0",
    period: "/month",
    color: "#6b7280",
    badge: "FREE",
    features: [
      "20 AI messages/day",
      "Basic chat (Groq/OpenRouter)",
      "Study AI & Writing tools",
      "Voice input/output",
      "1 file upload/day",
      "Image generation (5/day demo)",
    ],
    limits: { messages: 20, images: 5, files: 1 },
  },
  pro: {
    id: "pro",
    name: "Pro",
    price: "₹299",
    priceEn: "$4",
    period: "/month",
    color: "#7c3aed",
    badge: "PRO",
    popular: true,
    features: [
      "500 AI messages/day",
      "All AI providers (Groq, OpenRouter, Gemini)",
      "Web search & News AI",
      "Unlimited file uploads",
      "Image generation (50/day)",
      "Video AI generation",
      "Priority response speed",
      "Chat history sync",
    ],
    limits: { messages: 500, images: 50, files: 999 },
  },
  premium: {
    id: "premium",
    name: "Premium",
    price: "₹799",
    priceEn: "$10",
    period: "/month",
    color: "#d97706",
    badge: "⭐ PREMIUM",
    features: [
      "Unlimited AI messages",
      "All Pro features included",
      "GPT-4o & Claude access",
      "Unlimited image & video AI",
      "Custom AI persona",
      "Early access to new features",
      "Priority support",
      "No rate limits ever",
    ],
    limits: { messages: 99999, images: 99999, files: 99999 },
  },
};

/* ----------------------------- i18n strings ----------------------------- */
const STR = {
  en: {
    tagline: "Your bilingual AI companion — ask anything, in English or Hindi.",
    signIn: "Sign in", createAccount: "Create account", or: "or",
    continueGoogle: "Continue with Google",
    name: "Name", email: "Email", password: "Password",
    newChat: "New chat", chatsLabel: "Chats", noChats: "No chats yet — start one above.",
    you: "You", thinking: "Novexa is thinking",
    placeholder: "Message Novexa… (Hinglish chalega!)",
    copy: "Copy", copied: "Copied", rename: "Rename", del: "Delete",
    confirmDelete: "Delete this chat?", yes: "Yes", no: "No",
    settings: "Settings", profile: "Profile", logout: "Sign out",
    activeProvider: "Active provider", apiKey: "API key", modelId: "Model ID",
    suggested: "Suggested", getKeyAt: "Get a free key at",
    appearance: "Appearance", light: "Light", dark: "Dark", language: "Language",
    save: "Save changes", saved: "Saved ✓",
    emptyTitle: "How can I help you today?",
    emptySubtitle: "Ask anything — switch between Hindi and English anytime.",
    needKey: (p) => `Using the shared server (no key needed). Add your own ${p} API key in Settings for your own rate limits.`,
    openSettings: "Open settings",
    networkErr: "Network error — check your connection and try again.",
    invalidLogin: "Email or password didn't match.",
    emailTaken: "An account with this email already exists.",
    fillFields: "Fill in all fields to continue.",
    demoNote: "Demo account — stored only in this browser, not a real backend.",
    editName: "Display name", account: "Account",
    voiceSettings: "Voice Settings",
    voiceGender: "Voice Gender",
    voiceLang: "Voice Language",
    male: "Male", female: "Female",
    listening: "Listening…",
    exportChat: "Export chat",
    shareChat: "Share chat",
    shareNotSupported: "Copied to clipboard!",
    suggestions: [
      "What can you help me with?",
      "Explain quantum computing simply",
      "Write a short poem in Hindi",
      "Best productivity tips for developers",
      "Translate 'Good morning' to Hindi",
      "Tell me a fun fact",
    ],
    /* ---- Study AI (v1.2) ---- */
    navChat: "Chat", navStudy: "Study AI",
    studyTitle: "Study Assistant",
    studyDocs: "Documents", studyChat: "Document Chat", studyNotes: "Notes Generator",
    studyQuiz: "Quiz Generator", studyFlash: "Flashcards", studyHomework: "Homework Helper",
    studyMath: "Math Solver", studySummary: "Summarizer",
    uploadTitle: "Upload a document", uploadSub: "Drag & drop a PDF, Word or Excel file here, or click to browse",
    uploadHint: "Supports .pdf .doc .docx .xls .xlsx — up to 15MB",
    noDocs: "No documents uploaded yet.", selectDoc: "Select a document to get started",
    removeDoc: "Remove", processing: "Processing file…",
    shortSummary: "Short Summary", detailedSummary: "Detailed Summary", keyPoints: "Key Points",
    generate: "Generate", regenerate: "Regenerate",
    notesShort: "Short Notes", notesDetailed: "Detailed Notes", notesBullets: "Bullet Points",
    askAboutDoc: "Ask a question about this document…",
    quizMCQ: "Multiple Choice", quizTF: "True / False", quizShort: "Short Answer",
    generateQuiz: "Generate Quiz", submitQuiz: "Submit Answers", yourScore: "Your score",
    generateFlash: "Generate Flashcards", studyMode: "Study Mode", flipCard: "Tap to flip",
    cardOf: "Card", homeworkPlaceholder: "Type your school or college question here…",
    mathPlaceholder: "Type a math problem (algebra, geometry, calculus...)",
    solve: "Solve", explain: "Explain step-by-step", needDocFirst: "Upload a document first.",
    fileTooLarge: "File is too large (max 15MB).", unsupportedFile: "Unsupported file type.",
    correct: "Correct", incorrect: "Incorrect", showAnswer: "Show answer",
    next: "Next", prev: "Previous", reset: "Reset",

    /* ---- Coding + Writing AI (v1.3, Features 41-50) ---- */
    navCoding: "Coding Tools", navWriting: "Writing Tools",
    codingTitle: "Coding Tools", writingTitle: "Writing Tools",
    toolCodeGen: "Code Generator", toolCodeDebug: "Code Debugger",
    toolWebGen: "Website Generator", toolPyHelper: "Python Helper",
    toolEssay: "Essay Writer", toolBlog: "Blog Writer", toolEmail: "Email Writer",
    toolResume: "Resume Builder", toolGrammar: "Grammar Fixer", toolParaphrase: "Paraphraser",

    selectLanguage: "Language",
    codePromptPlaceholder: "Describe the code you want, e.g. \"a responsive navbar with a dropdown menu\"…",
    generateCode: "Generate Code",
    debugCodePlaceholder: "Paste your code here to find and fix errors…",
    analyzeDebug: "Analyze & Fix",
    issuesFound: "Issues Found", correctedCode: "Corrected Code",
    webPromptPlaceholder: "Describe the website you want, e.g. \"a portfolio landing page for a photographer\"…",
    generateWebsite: "Generate Website",
    previewLabel: "Live Preview", htmlLabel: "HTML", cssLabel: "CSS", jsLabel: "JavaScript",
    pyModeGenerate: "Generate", pyModeExplain: "Explain", pyModeDebug: "Debug", pyModeOptimize: "Optimize",
    pyPromptPlaceholder: "Describe a script, paste code to explain/debug/optimize…",
    runPython: "Run", noCodeYet: "Generated code will appear here.",

    essayShort: "Short", essayMedium: "Medium", essayLong: "Long",
    essayTopicPlaceholder: "Enter an essay topic…",
    generateEssay: "Generate Essay", wordsApprox: "words (approx.)",

    blogTopicPlaceholder: "Enter a blog topic or keyword…",
    generateBlog: "Generate Blog Post",

    emailFormal: "Formal", emailInformal: "Informal", emailBusiness: "Business",
    emailPurposePlaceholder: "What is this email about? e.g. \"follow up after a job interview\"…",
    generateEmail: "Generate Email", copyEmail: "Copy Email",

    resumeFullName: "Full Name", resumeContact: "Contact Details (email, phone)",
    resumeSkills: "Skills", resumeEducation: "Education", resumeExperience: "Experience",
    resumeTemplate: "Template", templateModern: "Modern", templateClassic: "Classic", templateMinimal: "Minimal",
    generateResume: "Generate Resume", downloadResume: "Download Resume", printResume: "Print / Save as PDF",
    resumePreview: "Resume Preview", fillResumeFirst: "Fill in your details and generate a resume to see the preview.",

    grammarPlaceholder: "Paste text to fix grammar, structure and readability…",
    fixGrammarBtn: "Fix Grammar",

    paraphraseSimple: "Simple", paraphraseProfessional: "Professional", paraphraseCreative: "Creative",
    paraphrasePlaceholder: "Paste the text you want to rewrite…",
    paraphraseBtn: "Paraphrase",

    resultLabel: "Result", noResultYet: "Your result will appear here.",

    /* ---- v1.4: Web Intelligence + File Chat ---- */
    navIntel: "Web Intel", navFiles: "File Chat",
    intelTitle: "Web Intelligence", filesTitle: "File Chat",
    toolWebSearch: "Web Search", toolNews: "News", toolWeather: "Weather",
    toolFactCheck: "Fact Check", toolDataAnalysis: "Data Analysis", toolCharts: "Charts & Graphs",
    searchPlaceholder: "Search the web…", searchBtn: "Search",
    searchKeyNote: "Add a free Tavily API key in Settings → Web Search for live results. Without a key, Novexa will answer from its own knowledge instead.",
    sources: "Sources", noResultsFound: "No results found.",
    newsTopicPlaceholder: "Topic, e.g. \"AI in India\", \"cricket\", \"stock market\"…",
    getNews: "Get Latest News",
    weatherCityPlaceholder: "Enter city name…", getWeather: "Get Weather",
    useMyLocation: "Use my location", locating: "Locating…",
    feelsLike: "Feels like", humidity: "Humidity", wind: "Wind", condition: "Condition",
    factCheckPlaceholder: "Paste a claim or statement to verify…", checkFact: "Check Fact",
    verdict: "Verdict", trueLabel: "Likely True", falseLabel: "Likely False", unclearLabel: "Unclear",
    dataInputCsv: "Paste CSV/JSON data, or upload a file below", uploadData: "Upload Data File",
    analyzeData: "Analyze Data", dataSummary: "Summary", aiInsights: "AI Insights",
    chartType: "Chart Type", barChart: "Bar", lineChart: "Line", pieChart: "Pie",
    generateChart: "Generate Chart", chartFromData: "Uses the dataset from Data Analysis, or paste your own below",
    chartDataPlaceholder: "label,value\nJan,120\nFeb,150\nMar,90",
    filesChatTitle: "Chat with your files", uploadMultiHint: "Upload one or more PDF, DOC/DOCX or TXT files, then ask questions about them together.",
    noFilesYet: "No files uploaded yet.", filesSelected: "files selected", clearAll: "Clear all",
    askAboutFiles: "Ask a question about your uploaded files…",
    exportPdf: "Export as PDF", searchApiKeyLabel: "Web Search API key (Tavily)",
    optional: "optional", liveData: "Live data", aiKnowledge: "From AI knowledge (no live search key set)",
    rowsLabel: "Rows", colsLabel: "Columns", fetchingLive: "Fetching live data…",

    /* ---- v1.5: AI Voice Call (Features 61-70) ---- */
    navVoiceCall: "Voice Call",
    voiceCallTitle: "AI Voice Call",
    voiceCallSubtitle: "Talk to Novexa AI hands-free",
    startCall: "Start Call", endCall: "End Call", connecting: "Connecting…",
    callActive: "Call Active", callEnded: "Call Ended",
    callDuration: "Duration", callHistory: "Call History",
    noCallHistory: "No past calls yet.",
    callHistoryEmpty: "Start a voice call to see your history here.",
    aiSpeaking: "Novexa is speaking…", aiListening: "Listening…",
    youSpoke: "You", aiResponded: "Novexa",
    interruptAI: "Stop AI", resumeListening: "Resume",
    micPermissionErr: "Microphone permission denied. Please allow mic access.",
    speechNotSupported: "Speech recognition not supported in this browser.",
    continuousMode: "Hands-free Mode", continuousModeHint: "AI listens automatically after each reply",
    voiceSpeed: "Voice Speed", voiceQuality: "Voice Quality",
    speedSlow: "Slow", speedNormal: "Normal", speedFast: "Fast",
    qualityNormal: "Normal", qualityHD: "HD",
    callLangHindi: "Hindi", callLangEnglish: "English", callLangHinglish: "Hinglish",
    voiceCallLang: "Call Language",
    tapToSpeak: "Tap mic to speak",
    callSessionSaved: "Call saved to history",
    clearHistory: "Clear History",
    deleteCall: "Delete",
    callMinutes: "min", callSeconds: "sec",
    callTranscript: "Transcript",

    /* ---- v1.6: AI Image Generation (Features 71-80) ---- */
    navImageGen: "Image AI",
    imgGenTitle: "AI Image Generator",
    imgGenSubtitle: "Turn words into stunning visuals",
    imgPromptLabel: "Describe your image",
    imgPromptPlaceholder: "A futuristic city at sunset with neon lights reflecting on rain-soaked streets, cinematic, ultra-detailed…",
    imgStyleLabel: "Style",
    imgSizeLabel: "Aspect Ratio",
    imgCountLabel: "Variations",
    imgGenerateBtn: "Generate Images",
    imgRegenerateBtn: "Regenerate",
    imgEnhanceBtn: "✨ Enhance Prompt",
    imgEnhancing: "Enhancing prompt…",
    imgGenerating: "Generating your images…",
    imgDownload: "Download",
    imgShare: "Share",
    imgCopyPrompt: "Copy Prompt",
    imgHistory: "Image History",
    imgHistoryEmpty: "No images generated yet. Create your first one above!",
    imgClearHistory: "Clear History",
    imgDeleteImage: "Delete",
    imgStyles: {
      realistic: "Realistic",
      anime: "Anime",
      cartoon: "Cartoon",
      "3d": "3D Render",
      digitalart: "Digital Art",
      fantasy: "Fantasy",
      sketch: "Sketch",
      cinematic: "Cinematic",
    },
    imgSizes: {
      "1:1": "1:1 Square",
      "9:16": "9:16 Portrait",
      "16:9": "16:9 Landscape",
    },
    imgApiKeyNote: "Add a Stable Diffusion / Hugging Face API key in Settings → Image AI for real generation. In demo mode, AI will describe what the image would look like.",
    imgSettingsLabel: "Image API Key (Hugging Face)",
    imgModelLabel: "Image Model",
    imgErrorTryAgain: "Image generation failed. Try again or check your API key.",
    imgNoKey: "No image API key set — running in AI-description mode.",
    imgVariations: ["1 image", "2 images", "4 images"],
    imgEditPrompt: "Edit Prompt",
    imgAddToChat: "Send to Chat",
    imgGenerated: (n) => `${n} image${n !== 1 ? "s" : ""} generated`,

    /* ---- v1.7: Generator mode tabs (Features 71-74) ---- */
    imgTabText: "Text to Image",
    imgTabImage: "Image to Image",
    imgTabAudio: "Audio to Image",

    /* ---- v1.7 Feature 72: Image-to-Image ---- */
    i2iUploadTitle: "Upload an image",
    i2iUploadSub: "Drag & drop an image here, or click to browse",
    i2iUploadHint: "Supports JPG, PNG, WEBP — up to 8MB",
    i2iChangeImage: "Change Image",
    i2iRemoveImage: "Remove",
    i2iPromptLabel: "Describe the transformation",
    i2iPromptPlaceholder: "e.g. \"turn this into a watercolor painting\", \"make the lighting cinematic\", \"add a fantasy forest background\"…",
    i2iStrengthLabel: "Transformation Strength",
    i2iStrengthSubtle: "Subtle",
    i2iStrengthDramatic: "Dramatic",
    i2iGenerateBtn: "Transform Image",
    i2iGenerating: "Transforming your image…",
    i2iNeedImage: "Please upload an image first.",
    i2iFileTooLarge: "Image is too large (max 8MB).",
    i2iUnsupportedFile: "Unsupported file type. Use JPG, PNG, or WEBP.",
    i2iOriginal: "Original",
    i2iPreserveNote: "Novexa keeps the original subject and composition in mind while applying your changes.",

    /* ---- v1.7 Feature 73: Audio-to-Image ---- */
    a2iRecordStart: "Tap to speak",
    a2iRecordStop: "Tap to stop",
    a2iListening: "Listening…",
    a2iTranscriptLabel: "Transcript",
    a2iLangLabel: "Voice Language",
    a2iNotSupported: "Voice input isn't supported in this browser.",
    a2iClear: "Clear",
    a2iEmptyHint: "Tap the mic and describe the image you want — in English, Hindi, or Hinglish.",
    a2iOptimizing: "Turning your voice into an image prompt…",
    a2iOptimizeBtn: "✨ Build Prompt from Voice",

    /* ---- v1.7 Feature 74: AI Prompt Enhancer (also used by image/audio modes) ---- */
    imgEnhanceNote: "One tap adds style, lighting, quality, and composition detail to your prompt.",

    /* ---- v1.8: Advanced Image Generator additions (Feature 77) ---- */
    imgQualityLabel: "Quality",
    imgQualities: { sd: "Standard", hd: "HD", uhd: "Ultra HD" },
    imgSpeedLabel: "Generation Mode",
    imgSpeedFast: "Fast", imgSpeedQuality: "Quality",
    imgSpeedFastHint: "Quicker, fewer details", imgSpeedQualityHint: "Slower, more refined",
    imgNegativeLabel: "Negative Prompt", imgNegativeOptional: "(optional)",
    imgNegativePlaceholder: "Things to avoid, e.g. \"blurry, watermark, extra fingers, low quality\"…",
    imgAdvancedToggle: "Advanced Options",
    imgUpscaleBtn: "Upscale", imgUpscaling: "Upscaling…", imgUpscaledBadge: "Upscaled 2x",

    /* ---- v1.8: AI Image Editor (Feature 75) ---- */
    navImageEditor: "Image Editor",
    editTitle: "AI Image Editor",
    editSubtitle: "Remove backgrounds, fix colors, restore, and reshape your photos",
    editUploadTitle: "Upload a photo to edit",
    editUploadSub: "Drag & drop an image here, or click to browse",
    editUploadHint: "Supports JPG, PNG, WEBP — up to 8MB",
    editChangeImage: "Change Photo", editStartOver: "Start Over",
    editOneClickLabel: "One-Click Tools",
    editToolRemovebg: "Remove Background", editToolEnhance: "Enhance & Restore",
    editToolUpscale: "Upscale 2x", editToolRecolor: "Recolor",
    editInstructionLabel: "Describe an edit",
    editInstructionPlaceholder: "e.g. \"replace the sky with a sunset\", \"add a small dog next to the bench\", \"change the shirt to red\"…",
    editApplyBtn: "Apply Edit", editApplying: "Applying edit…",
    editTransformLabel: "Crop, Resize & Rotate",
    editCropTab: "Crop", editResizeTab: "Resize", editRotateTab: "Rotate",
    editCropHint: "Drag the box to select the area to keep",
    editApplyCrop: "Apply Crop",
    editWidthLabel: "Width", editHeightLabel: "Height", editLockAspect: "Lock aspect ratio",
    editApplyResize: "Apply Resize",
    editRotateLeft: "Rotate -90°", editRotateRight: "Rotate +90°", editApplyRotate: "Apply Rotation",
    editResultLabel: "Edited Result", editOriginalLabel: "Original",
    editDownload: "Download", editShare: "Share", editSaveToGallery: "Save to Gallery",
    editUndo: "Undo", editRedo: "Redo", editReset: "Reset to Original",
    editNoImage: "Upload a photo above to start editing.",
    editNeedImage: "Please upload a photo first.",
    editFileTooLarge: "Image is too large (max 8MB).",
    editUnsupportedFile: "Unsupported file type. Use JPG, PNG, or WEBP.",
    editErrorTryAgain: "Edit failed. Try again or check your API key.",
    editApiKeyNote: "Add a Hugging Face API key in Settings → Image AI for real AI edits. In demo mode, Novexa will describe how the edit would look.",
    editSavedToGallery: "Saved to your gallery!",

    /* ---- v1.8: Text-to-Video Generator (Feature 76) ---- */
    navVideoGen: "Video AI",
    vidGenTitle: "AI Text-to-Video",
    vidGenSubtitle: "Turn a written scene into a short video",
    vidPromptLabel: "Describe your video",
    vidPromptPlaceholder: "A drone shot flying over a misty mountain valley at sunrise, cinematic…",
    vidStyleLabel: "Style", vidSizeLabel: "Aspect Ratio", vidDurationLabel: "Duration",
    vidGenerateBtn: "Generate Video", vidRegenerateBtn: "Regenerate",
    vidGenerating: "Generating your video… this can take a minute",
    vidNoKey: "No image/video API key set — running in AI-storyboard mode.",
    vidApiKeyNote: "Add a Hugging Face API key in Settings → Image AI to attempt real video generation. In demo mode, Novexa describes a shot-by-shot storyboard instead.",
    vidDownload: "Download Video", vidShare: "Share",
    vidHistory: "Video History", vidHistoryEmpty: "No videos generated yet. Create your first one above!",
    vidClearHistory: "Clear History", vidDeleteVideo: "Delete",
    vidStoryboardTitle: "Storyboard Preview", vidStoryboardNote: "Demo mode — shown as a written storyboard instead of a rendered video.",
    vidErrorTryAgain: "Video generation failed. Try again, or check your API key.",
    vidSeconds: "sec",
    vidGenerated: "Video generated",

    /* ---- v1.8: AI Media Gallery (Feature 78) ---- */
    navGallery: "Media Gallery",
    galleryTitle: "AI Media Gallery",
    gallerySubtitle: "All your generated and edited images & videos, in one place",
    gallerySearchPlaceholder: "Search by prompt…",
    galleryFilterAll: "All", galleryFilterImage: "Images", galleryFilterVideo: "Videos", galleryFilterEdit: "Edited",
    galleryEmpty: "No media yet. Generate images, videos, or edits to see them here.",
    galleryNoResults: "Nothing matches your search.",
    galleryClearAll: "Clear All", galleryConfirmClearAll: "Delete all media? This can't be undone.",
    galleryDelete: "Delete", galleryDownload: "Download", galleryShare: "Share",
    galleryCloudSyncLabel: "Cloud Sync", galleryCloudSyncOn: "On", galleryCloudSyncOff: "Off",
    galleryCloudSyncHint: "When on, Novexa saves a copy of your generated media to your account so it's still here next time you open the app. Very large files may be skipped to save space.",
    galleryItemCount: (n) => `${n} item${n !== 1 ? "s" : ""}`,
    galleryViewFull: "View",
    galleryTypeImage: "Image", galleryTypeVideo: "Video", galleryTypeEdit: "Edited Image",

    /* ---- v1.9: Chat Multimodal Upload (Features 78-81) ---- */
    attachImage: "Upload photo", attachFile: "Upload file", openCamera: "Use camera",
    switchCamera: "Switch camera", capturePhoto: "Capture", retakePhoto: "Retake",
    usePhoto: "Use photo", cancelCamera: "Cancel", cameraNotSupported: "Camera not available on this device/browser.",
    cameraPermissionDenied: "Camera access was denied. Check your browser permissions.",
    removeAttachment: "Remove", attachmentsLabel: "Attachments",
    dragDropHint: "Drop images or files to attach them", analyzingFiles: "Reading files…",
    unsupportedAttachment: "Unsupported file — try an image, PDF, Word, Excel or text file.",
    attachmentTooLarge: "File is too large (max 15MB).",
    composerPlaceholderAttach: "Ask about the attached files…",
    filesAttached: (n) => `${n} file${n !== 1 ? "s" : ""} attached`,
  },
  hi: {
    tagline: "आपका द्विभाषी AI साथी — अंग्रेज़ी या हिंदी में कुछ भी पूछें।",
    signIn: "साइन इन करें", createAccount: "अकाउंट बनाएं", or: "या",
    continueGoogle: "Google से जारी रखें",
    name: "नाम", email: "ईमेल", password: "पासवर्ड",
    newChat: "नई चैट", chatsLabel: "चैट्स", noChats: "अभी कोई चैट नहीं — ऊपर से नई शुरू करें।",
    you: "आप", thinking: "Novexa सोच रहा है",
    placeholder: "Novexa को मैसेज करें… (Hinglish bhi chalega!)",
    copy: "कॉपी करें", copied: "कॉपी हो गया", rename: "नाम बदलें", del: "डिलीट करें",
    confirmDelete: "यह चैट डिलीट करें?", yes: "हाँ", no: "नहीं",
    settings: "सेटिंग्स", profile: "प्रोफ़ाइल", logout: "साइन आउट",
    activeProvider: "सक्रिय प्रोवाइडर", apiKey: "API कुंजी", modelId: "मॉडल ID",
    suggested: "सुझाए गए", getKeyAt: "फ्री कुंजी पाएं",
    appearance: "थीम", light: "लाइट", dark: "डार्क", language: "भाषा",
    save: "सेव करें", saved: "सेव हो गया ✓",
    emptyTitle: "आज मैं आपकी कैसे मदद करूं?",
    emptySubtitle: "कुछ भी पूछें — कभी भी हिंदी और अंग्रेज़ी में बदल सकते हैं।",
    needKey: (p) => `शेयर्ड सर्वर इस्तेमाल हो रहा है (कुंजी जरूरी नहीं)। अपनी ${p} API कुंजी सेटिंग्स में डालें ताकि आपकी अपनी रेट लिमिट मिले।`,
    openSettings: "सेटिंग्स खोलें",
    networkErr: "नेटवर्क एरर — अपना कनेक्शन जांचें और फिर कोशिश करें।",
    invalidLogin: "ईमेल या पासवर्ड मेल नहीं खाया।",
    emailTaken: "इस ईमेल से अकाउंट पहले से मौजूद है।",
    fillFields: "जारी रखने के लिए सभी फ़ील्ड भरें।",
    demoNote: "डेमो अकाउंट — सिर्फ इस ब्राउज़र में सेव है, कोई असली बैकएंड नहीं।",
    editName: "नाम", account: "अकाउंट",
    voiceSettings: "वॉयस सेटिंग्स",
    voiceGender: "आवाज़ का लिंग",
    voiceLang: "आवाज़ की भाषा",
    male: "पुरुष", female: "महिला",
    listening: "सुन रहा हूं…",
    exportChat: "चैट डाउनलोड करें",
    shareChat: "चैट शेयर करें",
    shareNotSupported: "क्लिपबोर्ड पर कॉपी हो गया!",
    suggestions: [
      "आप मेरी क्या मदद कर सकते हैं?",
      "क्वांटम कंप्यूटिंग आसान भाषा में समझाएं",
      "हिंदी में एक छोटी कविता लिखें",
      "Developers के लिए best productivity tips",
      "'Good morning' का हिंदी अनुवाद करें",
      "कोई मज़ेदार fact बताएं",
    ],
    navChat: "चैट", navStudy: "स्टडी AI",
    studyTitle: "स्टडी असिस्टेंट",
    studyDocs: "दस्तावेज़", studyChat: "डॉक्यूमेंट चैट", studyNotes: "नोट्स जनरेटर",
    studyQuiz: "क्विज़ जनरेटर", studyFlash: "फ्लैशकार्ड्स", studyHomework: "होमवर्क हेल्पर",
    studyMath: "मैथ सॉल्वर", studySummary: "सारांश",
    uploadTitle: "दस्तावेज़ अपलोड करें", uploadSub: "PDF, Word या Excel फ़ाइल यहाँ ड्रैग करें या क्लिक करके चुनें",
    uploadHint: "सपोर्ट: .pdf .doc .docx .xls .xlsx — 15MB तक",
    noDocs: "अभी कोई दस्तावेज़ अपलोड नहीं है।", selectDoc: "शुरू करने के लिए एक दस्तावेज़ चुनें",
    removeDoc: "हटाएं", processing: "फ़ाइल प्रोसेस हो रही है…",
    shortSummary: "छोटा सारांश", detailedSummary: "विस्तृत सारांश", keyPoints: "मुख्य बिंदु",
    generate: "जनरेट करें", regenerate: "फिर से जनरेट करें",
    notesShort: "छोटे नोट्स", notesDetailed: "विस्तृत नोट्स", notesBullets: "बुलेट पॉइंट्स",
    askAboutDoc: "इस दस्तावेज़ के बारे में सवाल पूछें…",
    quizMCQ: "बहुविकल्पीय", quizTF: "सही / गलत", quizShort: "संक्षिप्त उत्तर",
    generateQuiz: "क्विज़ बनाएं", submitQuiz: "उत्तर जमा करें", yourScore: "आपका स्कोर",
    generateFlash: "फ्लैशकार्ड बनाएं", studyMode: "स्टडी मोड", flipCard: "पलटने के लिए टैप करें",
    cardOf: "कार्ड", homeworkPlaceholder: "अपना स्कूल या कॉलेज का सवाल यहाँ लिखें…",
    mathPlaceholder: "गणित की समस्या लिखें (algebra, geometry, calculus...)",
    solve: "हल करें", explain: "चरण-दर-चरण समझाएं", needDocFirst: "पहले एक दस्तावेज़ अपलोड करें।",
    fileTooLarge: "फ़ाइल बहुत बड़ी है (अधिकतम 15MB)।", unsupportedFile: "असमर्थित फ़ाइल प्रकार।",
    correct: "सही", incorrect: "गलत", showAnswer: "उत्तर दिखाएं",
    next: "अगला", prev: "पिछला", reset: "रीसेट",

    /* ---- Coding + Writing AI (v1.3, Features 41-50) ---- */
    navCoding: "कोडिंग टूल्स", navWriting: "राइटिंग टूल्स",
    codingTitle: "कोडिंग टूल्स", writingTitle: "राइटिंग टूल्स",
    toolCodeGen: "कोड जनरेटर", toolCodeDebug: "कोड डिबगर",
    toolWebGen: "वेबसाइट जनरेटर", toolPyHelper: "पाइथन हेल्पर",
    toolEssay: "निबंध लेखक", toolBlog: "ब्लॉग लेखक", toolEmail: "ईमेल लेखक",
    toolResume: "रिज़्यूमे बिल्डर", toolGrammar: "ग्रामर फिक्सर", toolParaphrase: "पैराफ्रेज़र",

    selectLanguage: "भाषा",
    codePromptPlaceholder: "अपना कोड describe करें, जैसे \"dropdown menu वाला responsive navbar\"…",
    generateCode: "कोड जनरेट करें",
    debugCodePlaceholder: "एरर ढूंढने और ठीक करने के लिए अपना कोड यहाँ पेस्ट करें…",
    analyzeDebug: "जांचें और ठीक करें",
    issuesFound: "समस्याएं मिलीं", correctedCode: "सुधारा गया कोड",
    webPromptPlaceholder: "अपनी वेबसाइट describe करें, जैसे \"एक फ़ोटोग्राफ़र के लिए पोर्टफोलियो लैंडिंग पेज\"…",
    generateWebsite: "वेबसाइट जनरेट करें",
    previewLabel: "लाइव प्रीव्यू", htmlLabel: "HTML", cssLabel: "CSS", jsLabel: "JavaScript",
    pyModeGenerate: "जनरेट करें", pyModeExplain: "समझाएं", pyModeDebug: "डिबग करें", pyModeOptimize: "ऑप्टिमाइज़ करें",
    pyPromptPlaceholder: "स्क्रिप्ट describe करें, या explain/debug/optimize के लिए कोड पेस्ट करें…",
    runPython: "रन करें", noCodeYet: "जनरेट किया गया कोड यहाँ दिखेगा।",

    essayShort: "छोटा", essayMedium: "मध्यम", essayLong: "बड़ा",
    essayTopicPlaceholder: "निबंध का विषय लिखें…",
    generateEssay: "निबंध जनरेट करें", wordsApprox: "शब्द (लगभग)",

    blogTopicPlaceholder: "ब्लॉग का विषय या कीवर्ड लिखें…",
    generateBlog: "ब्लॉग जनरेट करें",

    emailFormal: "औपचारिक", emailInformal: "अनौपचारिक", emailBusiness: "बिज़नेस",
    emailPurposePlaceholder: "यह ईमेल किस बारे में है? जैसे \"job interview के बाद follow up\"…",
    generateEmail: "ईमेल जनरेट करें", copyEmail: "ईमेल कॉपी करें",

    resumeFullName: "पूरा नाम", resumeContact: "संपर्क विवरण (ईमेल, फ़ोन)",
    resumeSkills: "स्किल्स", resumeEducation: "शिक्षा", resumeExperience: "अनुभव",
    resumeTemplate: "टेम्पलेट", templateModern: "मॉडर्न", templateClassic: "क्लासिक", templateMinimal: "मिनिमल",
    generateResume: "रिज़्यूमे जनरेट करें", downloadResume: "रिज़्यूमे डाउनलोड करें", printResume: "प्रिंट / PDF सेव करें",
    resumePreview: "रिज़्यूमे प्रीव्यू", fillResumeFirst: "प्रीव्यू देखने के लिए अपना विवरण भरें और रिज़्यूमे जनरेट करें।",

    grammarPlaceholder: "ग्रामर, स्ट्रक्चर और readability सुधारने के लिए टेक्स्ट पेस्ट करें…",
    fixGrammarBtn: "ग्रामर ठीक करें",

    paraphraseSimple: "सरल", paraphraseProfessional: "प्रोफेशनल", paraphraseCreative: "क्रिएटिव",
    paraphrasePlaceholder: "जिस टेक्स्ट को फिर से लिखना है उसे पेस्ट करें…",
    paraphraseBtn: "पैराफ्रेज़ करें",

    resultLabel: "परिणाम", noResultYet: "आपका परिणाम यहाँ दिखेगा।",

    /* ---- v1.4: Web Intelligence + File Chat ---- */
    navIntel: "वेब इंटेल", navFiles: "फ़ाइल चैट",
    intelTitle: "वेब इंटेलिजेंस", filesTitle: "फ़ाइल चैट",
    toolWebSearch: "वेब सर्च", toolNews: "न्यूज़", toolWeather: "मौसम",
    toolFactCheck: "फैक्ट चेक", toolDataAnalysis: "डेटा एनालिसिस", toolCharts: "चार्ट्स और ग्राफ",
    searchPlaceholder: "वेब पर सर्च करें…", searchBtn: "सर्च करें",
    searchKeyNote: "लाइव रिज़ल्ट के लिए सेटिंग्स → वेब सर्च में फ्री Tavily API कुंजी जोड़ें। कुंजी न होने पर Novexa अपने ज्ञान से जवाब देगा।",
    sources: "स्रोत", noResultsFound: "कोई परिणाम नहीं मिला।",
    newsTopicPlaceholder: "विषय, जैसे \"AI in India\", \"क्रिकेट\", \"शेयर बाज़ार\"…",
    getNews: "ताज़ा खबरें लाएं",
    weatherCityPlaceholder: "शहर का नाम डालें…", getWeather: "मौसम देखें",
    useMyLocation: "मेरी लोकेशन इस्तेमाल करें", locating: "लोकेट हो रहा है…",
    feelsLike: "महसूस होता है", humidity: "नमी", wind: "हवा", condition: "स्थिति",
    factCheckPlaceholder: "जाँचने के लिए कोई दावा या बयान पेस्ट करें…", checkFact: "फैक्ट चेक करें",
    verdict: "निष्कर्ष", trueLabel: "संभवतः सच", falseLabel: "संभवतः गलत", unclearLabel: "अस्पष्ट",
    dataInputCsv: "CSV/JSON डेटा पेस्ट करें, या नीचे फ़ाइल अपलोड करें", uploadData: "डेटा फ़ाइल अपलोड करें",
    analyzeData: "डेटा एनालाइज़ करें", dataSummary: "सारांश", aiInsights: "AI इनसाइट्स",
    chartType: "चार्ट प्रकार", barChart: "बार", lineChart: "लाइन", pieChart: "पाई",
    generateChart: "चार्ट बनाएं", chartFromData: "डेटा एनालिसिस वाला डेटासेट उपयोग होगा, या नीचे अपना डेटा पेस्ट करें",
    chartDataPlaceholder: "लेबल,वैल्यू\nJan,120\nFeb,150\nMar,90",
    filesChatTitle: "अपनी फाइलों से चैट करें", uploadMultiHint: "एक या अधिक PDF, DOC/DOCX या TXT फ़ाइलें अपलोड करें, फिर उनके बारे में एक साथ सवाल पूछें।",
    noFilesYet: "अभी कोई फ़ाइल अपलोड नहीं हुई।", filesSelected: "फ़ाइलें चुनी गईं", clearAll: "सभी हटाएं",
    askAboutFiles: "अपनी अपलोड की गई फाइलों के बारे में सवाल पूछें…",
    exportPdf: "PDF के रूप में एक्सपोर्ट करें", searchApiKeyLabel: "वेब सर्च API कुंजी (Tavily)",
    optional: "वैकल्पिक", liveData: "लाइव डेटा", aiKnowledge: "AI ज्ञान से (कोई लाइव सर्च कुंजी सेट नहीं)",
    rowsLabel: "पंक्तियाँ", colsLabel: "कॉलम", fetchingLive: "लाइव डेटा लाया जा रहा है…",

    /* ---- v1.5: AI Voice Call ---- */
    navVoiceCall: "वॉयस कॉल",
    voiceCallTitle: "AI वॉयस कॉल",
    voiceCallSubtitle: "Novexa AI से हैंड्स-फ्री बात करें",
    startCall: "कॉल शुरू करें", endCall: "कॉल समाप्त करें", connecting: "कनेक्ट हो रहा है…",
    callActive: "कॉल जारी है", callEnded: "कॉल समाप्त",
    callDuration: "अवधि", callHistory: "कॉल हिस्ट्री",
    noCallHistory: "अभी कोई पुरानी कॉल नहीं।",
    callHistoryEmpty: "कॉल हिस्ट्री देखने के लिए वॉयस कॉल शुरू करें।",
    aiSpeaking: "Novexa बोल रहा है…", aiListening: "सुन रहा है…",
    youSpoke: "आप", aiResponded: "Novexa",
    interruptAI: "AI रोकें", resumeListening: "फिर सुनें",
    micPermissionErr: "माइक्रोफ़ोन की अनुमति नहीं है। कृपया माइक एक्सेस दें।",
    speechNotSupported: "इस ब्राउज़र में स्पीच रिकग्निशन सपोर्ट नहीं है।",
    continuousMode: "हैंड्स-फ्री मोड", continuousModeHint: "AI हर जवाब के बाद खुद सुनता है",
    voiceSpeed: "आवाज़ की गति", voiceQuality: "आवाज़ की क्वालिटी",
    speedSlow: "धीमी", speedNormal: "सामान्य", speedFast: "तेज़",
    qualityNormal: "सामान्य", qualityHD: "HD",
    callLangHindi: "हिंदी", callLangEnglish: "English", callLangHinglish: "Hinglish",
    voiceCallLang: "कॉल भाषा",
    tapToSpeak: "बोलने के लिए माइक दबाएं",
    callSessionSaved: "कॉल हिस्ट्री में सेव हुई",
    clearHistory: "हिस्ट्री साफ़ करें",
    deleteCall: "हटाएं",
    callMinutes: "मिनट", callSeconds: "सेकंड",
    callTranscript: "ट्रांसक्रिप्ट",

    /* ---- v1.6: AI Image Generation ---- */
    navImageGen: "इमेज AI",
    imgGenTitle: "AI इमेज जनरेटर",
    imgGenSubtitle: "शब्दों को शानदार तस्वीरों में बदलें",
    imgPromptLabel: "अपनी इमेज describe करें",
    imgPromptPlaceholder: "सूर्यास्त के समय नियॉन लाइट्स से जगमगाता भविष्यवादी शहर, cinematic, ultra-detailed…",
    imgStyleLabel: "स्टाइल",
    imgSizeLabel: "आकार अनुपात",
    imgCountLabel: "वेरिएशन",
    imgGenerateBtn: "इमेज बनाएं",
    imgRegenerateBtn: "फिर से बनाएं",
    imgEnhanceBtn: "✨ Prompt सुधारें",
    imgEnhancing: "Prompt सुधारा जा रहा है…",
    imgGenerating: "इमेज बनाई जा रही है…",
    imgDownload: "डाउनलोड",
    imgShare: "शेयर करें",
    imgCopyPrompt: "Prompt कॉपी करें",
    imgHistory: "इमेज हिस्ट्री",
    imgHistoryEmpty: "अभी कोई इमेज नहीं बनी। ऊपर से पहली इमेज बनाएं!",
    imgClearHistory: "हिस्ट्री साफ़ करें",
    imgDeleteImage: "हटाएं",
    imgStyles: {
      realistic: "रियलिस्टिक",
      anime: "एनिमे",
      cartoon: "कार्टून",
      "3d": "3D रेंडर",
      digitalart: "डिजिटल आर्ट",
      fantasy: "फैंटेसी",
      sketch: "स्केच",
      cinematic: "सिनेमेटिक",
    },
    imgSizes: {
      "1:1": "1:1 स्क्वेयर",
      "9:16": "9:16 पोर्ट्रेट",
      "16:9": "16:9 लैंडस्केप",
    },
    imgApiKeyNote: "असली इमेज जनरेशन के लिए Settings → Image AI में Hugging Face API कुंजी डालें। Demo मोड में AI इमेज का description देगा।",
    imgSettingsLabel: "इमेज API कुंजी (Hugging Face)",
    imgModelLabel: "इमेज मॉडल",
    imgErrorTryAgain: "इमेज जनरेशन विफल। फिर कोशिश करें या API कुंजी जांचें।",
    imgNoKey: "कोई इमेज API कुंजी नहीं — AI-description मोड में चल रहा है।",
    imgVariations: ["1 इमेज", "2 इमेज", "4 इमेज"],
    imgEditPrompt: "Prompt संपादित करें",
    imgAddToChat: "Chat में भेजें",
    imgGenerated: (n) => `${n} इमेज${n !== 1 ? "ें" : ""} बनाई गई`,

    /* ---- v1.7: जनरेटर मोड टैब (Features 71-74) ---- */
    imgTabText: "टेक्स्ट से इमेज",
    imgTabImage: "इमेज से इमेज",
    imgTabAudio: "ऑडियो से इमेज",

    /* ---- v1.7 Feature 72: Image-to-Image ---- */
    i2iUploadTitle: "एक इमेज अपलोड करें",
    i2iUploadSub: "यहाँ इमेज drag & drop करें, या browse करने के लिए क्लिक करें",
    i2iUploadHint: "JPG, PNG, WEBP सपोर्टेड — अधिकतम 8MB",
    i2iChangeImage: "इमेज बदलें",
    i2iRemoveImage: "हटाएं",
    i2iPromptLabel: "बदलाव describe करें",
    i2iPromptPlaceholder: "जैसे \"इसे watercolor painting बनाएं\", \"lighting को cinematic बनाएं\", \"फैंटेसी जंगल का background जोड़ें\"…",
    i2iStrengthLabel: "बदलाव की तीव्रता",
    i2iStrengthSubtle: "हल्का",
    i2iStrengthDramatic: "ज़्यादा",
    i2iGenerateBtn: "इमेज बदलें",
    i2iGenerating: "आपकी इमेज बदली जा रही है…",
    i2iNeedImage: "पहले एक इमेज अपलोड करें।",
    i2iFileTooLarge: "इमेज बहुत बड़ी है (अधिकतम 8MB)।",
    i2iUnsupportedFile: "असमर्थित फ़ाइल प्रकार। JPG, PNG, या WEBP इस्तेमाल करें।",
    i2iOriginal: "ओरिजिनल",
    i2iPreserveNote: "Novexa आपके बदलाव लागू करते समय ओरिजिनल विषय और रचना को ध्यान में रखता है।",

    /* ---- v1.7 Feature 73: Audio-to-Image ---- */
    a2iRecordStart: "बोलने के लिए टैप करें",
    a2iRecordStop: "रोकने के लिए टैप करें",
    a2iListening: "सुन रहा है…",
    a2iTranscriptLabel: "ट्रांसक्रिप्ट",
    a2iLangLabel: "वॉइस भाषा",
    a2iNotSupported: "इस ब्राउज़र में वॉइस इनपुट सपोर्टेड नहीं है।",
    a2iClear: "साफ़ करें",
    a2iEmptyHint: "माइक टैप करें और अपनी इमेज describe करें — English, Hindi, या Hinglish में।",
    a2iOptimizing: "आपकी आवाज़ को इमेज prompt में बदला जा रहा है…",
    a2iOptimizeBtn: "✨ आवाज़ से Prompt बनाएं",

    /* ---- v1.7 Feature 74: AI Prompt Enhancer ---- */
    imgEnhanceNote: "एक टैप से आपके prompt में स्टाइल, लाइटिंग, क्वालिटी और कंपोज़िशन की डिटेल जुड़ जाती है।",

    /* ---- v1.8: Advanced Image Generator additions (Feature 77) ---- */
    imgQualityLabel: "क्वालिटी",
    imgQualities: { sd: "स्टैंडर्ड", hd: "HD", uhd: "अल्ट्रा HD" },
    imgSpeedLabel: "जेनरेशन मोड",
    imgSpeedFast: "फास्ट", imgSpeedQuality: "क्वालिटी",
    imgSpeedFastHint: "तेज़, कम डिटेल", imgSpeedQualityHint: "धीमा, ज़्यादा बेहतर",
    imgNegativeLabel: "नेगेटिव प्रॉम्प्ट", imgNegativeOptional: "(वैकल्पिक)",
    imgNegativePlaceholder: "जिन चीज़ों से बचना है, जैसे \"ब्लर, वॉटरमार्क, एक्स्ट्रा फिंगर्स, लो क्वालिटी\"…",
    imgAdvancedToggle: "एडवांस्ड ऑप्शन्स",
    imgUpscaleBtn: "अपस्केल", imgUpscaling: "अपस्केल हो रहा है…", imgUpscaledBadge: "2x अपस्केल्ड",

    /* ---- v1.8: AI Image Editor (Feature 75) ---- */
    navImageEditor: "इमेज एडिटर",
    editTitle: "AI इमेज एडिटर",
    editSubtitle: "बैकग्राउंड हटाएं, रंग ठीक करें, रिस्टोर करें और अपनी फोटो को नया रूप दें",
    editUploadTitle: "एडिट करने के लिए फोटो अपलोड करें",
    editUploadSub: "यहाँ इमेज ड्रैग एंड ड्रॉप करें, या क्लिक करके चुनें",
    editUploadHint: "JPG, PNG, WEBP सपोर्टेड — अधिकतम 8MB",
    editChangeImage: "फोटो बदलें", editStartOver: "फिर से शुरू करें",
    editOneClickLabel: "वन-क्लिक टूल्स",
    editToolRemovebg: "बैकग्राउंड हटाएं", editToolEnhance: "एन्हांस और रिस्टोर",
    editToolUpscale: "2x अपस्केल", editToolRecolor: "रीकलर",
    editInstructionLabel: "एडिट का वर्णन करें",
    editInstructionPlaceholder: "जैसे \"आसमान को सूर्यास्त से बदलें\", \"बेंच के पास एक छोटा कुत्ता जोड़ें\", \"शर्ट को लाल करें\"…",
    editApplyBtn: "एडिट लागू करें", editApplying: "एडिट लागू हो रहा है…",
    editTransformLabel: "क्रॉप, रीसाइज़ और रोटेट",
    editCropTab: "क्रॉप", editResizeTab: "रीसाइज़", editRotateTab: "रोटेट",
    editCropHint: "रखने के लिए एरिया चुनने हेतु बॉक्स खींचें",
    editApplyCrop: "क्रॉप लागू करें",
    editWidthLabel: "चौड़ाई", editHeightLabel: "ऊँचाई", editLockAspect: "आस्पेक्ट रेशियो लॉक करें",
    editApplyResize: "रीसाइज़ लागू करें",
    editRotateLeft: "-90° घुमाएं", editRotateRight: "+90° घुमाएं", editApplyRotate: "रोटेशन लागू करें",
    editResultLabel: "एडिटेड रिज़ल्ट", editOriginalLabel: "ओरिजिनल",
    editDownload: "डाउनलोड", editShare: "शेयर", editSaveToGallery: "गैलरी में सेव करें",
    editUndo: "अनडू", editRedo: "रीडू", editReset: "ओरिजिनल पर रीसेट करें",
    editNoImage: "एडिटिंग शुरू करने के लिए ऊपर फोटो अपलोड करें।",
    editNeedImage: "कृपया पहले एक फोटो अपलोड करें।",
    editFileTooLarge: "इमेज बहुत बड़ी है (अधिकतम 8MB)।",
    editUnsupportedFile: "असमर्थित फाइल टाइप। JPG, PNG, या WEBP इस्तेमाल करें।",
    editErrorTryAgain: "एडिट फेल हो गया। फिर कोशिश करें या अपनी API कुंजी जांचें।",
    editApiKeyNote: "असली AI एडिट के लिए सेटिंग्स → Image AI में Hugging Face API कुंजी डालें। डेमो मोड में, Novexa बताएगा कि एडिट कैसा दिखेगा।",
    editSavedToGallery: "आपकी गैलरी में सेव हो गया!",

    /* ---- v1.8: Text-to-Video Generator (Feature 76) ---- */
    navVideoGen: "वीडियो AI",
    vidGenTitle: "AI टेक्स्ट-टू-वीडियो",
    vidGenSubtitle: "लिखे हुए सीन को छोटे वीडियो में बदलें",
    vidPromptLabel: "अपने वीडियो का वर्णन करें",
    vidPromptPlaceholder: "सूर्योदय के समय कोहरे से भरी पहाड़ी घाटी के ऊपर ड्रोन शॉट, सिनेमैटिक…",
    vidStyleLabel: "स्टाइल", vidSizeLabel: "आस्पेक्ट रेशियो", vidDurationLabel: "अवधि",
    vidGenerateBtn: "वीडियो जेनरेट करें", vidRegenerateBtn: "फिर से जेनरेट करें",
    vidGenerating: "आपका वीडियो जेनरेट हो रहा है… इसमें एक मिनट लग सकता है",
    vidNoKey: "कोई इमेज/वीडियो API कुंजी सेट नहीं — AI-स्टोरीबोर्ड मोड में चल रहा है।",
    vidApiKeyNote: "असली वीडियो जेनरेशन के लिए सेटिंग्स → Image AI में Hugging Face API कुंजी डालें। डेमो मोड में, Novexa वीडियो के बजाय शॉट-बाय-शॉट स्टोरीबोर्ड लिखकर बताता है।",
    vidDownload: "वीडियो डाउनलोड करें", vidShare: "शेयर",
    vidHistory: "वीडियो हिस्ट्री", vidHistoryEmpty: "अभी तक कोई वीडियो जेनरेट नहीं हुआ। ऊपर अपना पहला वीडियो बनाएं!",
    vidClearHistory: "हिस्ट्री साफ़ करें", vidDeleteVideo: "डिलीट करें",
    vidStoryboardTitle: "स्टोरीबोर्ड प्रीव्यू", vidStoryboardNote: "डेमो मोड — रेंडर किए गए वीडियो के बजाय लिखित स्टोरीबोर्ड दिखाया गया है।",
    vidErrorTryAgain: "वीडियो जेनरेशन फेल हो गया। फिर कोशिश करें, या अपनी API कुंजी जांचें।",
    vidSeconds: "सेकंड",
    vidGenerated: "वीडियो जेनरेट हुआ",

    /* ---- v1.8: AI Media Gallery (Feature 78) ---- */
    navGallery: "मीडिया गैलरी",
    galleryTitle: "AI मीडिया गैलरी",
    gallerySubtitle: "आपकी सभी जेनरेट और एडिट की गई इमेज व वीडियो, एक ही जगह",
    gallerySearchPlaceholder: "प्रॉम्प्ट से खोजें…",
    galleryFilterAll: "सभी", galleryFilterImage: "इमेज", galleryFilterVideo: "वीडियो", galleryFilterEdit: "एडिटेड",
    galleryEmpty: "अभी कोई मीडिया नहीं। यहाँ देखने के लिए इमेज, वीडियो या एडिट जेनरेट करें।",
    galleryNoResults: "आपकी खोज से कुछ मेल नहीं खाता।",
    galleryClearAll: "सभी साफ़ करें", galleryConfirmClearAll: "सारा मीडिया डिलीट करें? यह वापस नहीं हो सकता।",
    galleryDelete: "डिलीट करें", galleryDownload: "डाउनलोड", galleryShare: "शेयर",
    galleryCloudSyncLabel: "क्लाउड सिंक", galleryCloudSyncOn: "ऑन", galleryCloudSyncOff: "ऑफ",
    galleryCloudSyncHint: "ऑन होने पर, Novexa आपके जेनरेट किए मीडिया की एक कॉपी आपके अकाउंट में सेव करता है ताकि अगली बार ऐप खोलने पर भी यह यहाँ रहे। बहुत बड़ी फाइलें स्किप हो सकती हैं।",
    galleryItemCount: (n) => `${n} आइटम`,
    galleryViewFull: "देखें",
    galleryTypeImage: "इमेज", galleryTypeVideo: "वीडियो", galleryTypeEdit: "एडिटेड इमेज",

    /* ---- v1.9: Chat Multimodal Upload (Features 78-81) ---- */
    attachImage: "फोटो अपलोड करें", attachFile: "फ़ाइल अपलोड करें", openCamera: "कैमरा इस्तेमाल करें",
    switchCamera: "कैमरा बदलें", capturePhoto: "कैप्चर करें", retakePhoto: "दोबारा लें",
    usePhoto: "फोटो इस्तेमाल करें", cancelCamera: "रद्द करें", cameraNotSupported: "इस डिवाइस/ब्राउज़र पर कैमरा उपलब्ध नहीं है।",
    cameraPermissionDenied: "कैमरा एक्सेस अस्वीकृत कर दिया गया। अपनी ब्राउज़र सेटिंग्स जांचें।",
    removeAttachment: "हटाएं", attachmentsLabel: "अटैचमेंट्स",
    dragDropHint: "अटैच करने के लिए इमेज या फ़ाइलें यहाँ छोड़ें", analyzingFiles: "फ़ाइलें पढ़ी जा रही हैं…",
    unsupportedAttachment: "असमर्थित फ़ाइल — इमेज, PDF, Word, Excel या टेक्स्ट फ़ाइल आज़माएं।",
    attachmentTooLarge: "फ़ाइल बहुत बड़ी है (अधिकतम 15MB)।",
    composerPlaceholderAttach: "अटैच की गई फ़ाइलों के बारे में पूछें…",
    filesAttached: (n) => `${n} फ़ाइल${n !== 1 ? "ें" : ""} अटैच की गईं`,
  },
};

const GROQ_MODELS = ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "gemma2-9b-it", "deepseek-r1-distill-llama-70b"];
// Note: Groq's models above are text-only. For chat attachments that include images,
// pick an OpenRouter vision model (e.g. "openai/gpt-4o-mini") in Settings — vision only
// works through OpenRouter, not Groq.
const OR_MODELS = ["openai/gpt-4o-mini", "anthropic/claude-3.5-sonnet", "meta-llama/llama-3.1-8b-instruct:free", "google/gemini-flash-1.5"];
// Vision-capable OpenRouter models — used to warn the user if they attach an image
// while on a text-only model.
const OR_VISION_MODELS = ["openai/gpt-4o-mini", "anthropic/claude-3.5-sonnet", "google/gemini-flash-1.5"];

/* Extracts plain text from a PDF File without any external library, since Groq and
   OpenRouter (unlike Claude) don't accept raw PDF bytes — they need text.
   PDFs store text inside "BT ... ET" blocks as Tj / TJ show-text operators; this walks
   those blocks and pulls the literal string content out of them. Works well for normal
   text-based PDFs (notes, assignments, articles, reports). Scanned/image-only PDFs have
   no embedded text layer, so nothing will be found — those need OCR, which this doesn't do. */
async function extractPdfText(file, maxChars = 60000) {
  const buf = await file.arrayBuffer();
  const bytes = new Uint8Array(buf);
  // Decode as Latin1 so every byte maps 1:1 to a char code — safe for binary PDF structure.
  let raw = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    raw += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }

  function decodePdfString(s) {
    // Handle (...) literal strings: unescape \n \r \t \( \) \\ and octal escapes.
    return s.replace(/\\(\d{1,3}|[nrtbf()\\])/g, (m, esc) => {
      if (esc === "n") return "\n";
      if (esc === "r") return "\r";
      if (esc === "t") return "\t";
      if (esc === "b" || esc === "f") return "";
      if (esc === "(" || esc === ")" || esc === "\\") return esc;
      const code = parseInt(esc, 8);
      return Number.isNaN(code) ? "" : String.fromCharCode(code);
    });
  }

  const blocks = raw.match(/BT([\s\S]*?)ET/g) || [];
  let text = "";
  for (const block of blocks) {
    // (literal string) Tj   or   [(a) -120 (b) ...] TJ
    const showOps = block.match(/\((?:[^()\\]|\\.)*\)\s*Tj|\[(?:[^\[\]]|\\.)*\]\s*TJ/g) || [];
    for (const op of showOps) {
      const literals = op.match(/\((?:[^()\\]|\\.)*\)/g) || [];
      for (const lit of literals) {
        text += decodePdfString(lit.slice(1, -1));
      }
      text += " ";
    }
    text += "\n";
  }

  text = text.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();

  if (!text) {
    return "[No extractable text found in this PDF — it may be a scanned/image-only document, which this app can't OCR. Try a text-based PDF, or copy/paste the content directly into the chat.]";
  }
  if (text.length > maxChars) {
    text = text.slice(0, maxChars) + `\n\n[Note: PDF text was long and has been truncated to ${maxChars} characters.]`;
  }
  return text;
}

/* Feature 41: supported code-generation languages */
const CODE_LANGUAGES = ["HTML", "CSS", "JavaScript", "Python", "React", "Node.js"];

/* ============================== v1.6: Image Generation Constants ============================== */
const IMAGE_STYLES = [
  { id: "realistic", label: "Realistic", icon: "📷", suffix: "photorealistic, 8k, ultra-detailed, professional photography, sharp focus" },
  { id: "anime", label: "Anime", icon: "🎌", suffix: "anime style, vibrant colors, Studio Ghibli inspired, detailed manga art" },
  { id: "cartoon", label: "Cartoon", icon: "🎨", suffix: "cartoon style, colorful, smooth shading, animated, playful illustration" },
  { id: "3d", label: "3D Render", icon: "📦", suffix: "3D render, octane render, ray tracing, volumetric lighting, hyperrealistic" },
  { id: "digitalart", label: "Digital Art", icon: "🖌️", suffix: "digital art, concept art, trending on artstation, vibrant, detailed brushwork, sharp" },
  { id: "fantasy", label: "Fantasy", icon: "🧙", suffix: "epic fantasy art, magical atmosphere, dramatic glowing light, intricate detail, mythical" },
  { id: "sketch", label: "Sketch", icon: "✏️", suffix: "pencil sketch, hand-drawn, detailed linework, charcoal, artistic illustration" },
  { id: "cinematic", label: "Cinematic", icon: "🎬", suffix: "cinematic, dramatic lighting, film grain, anamorphic, movie scene, epic" },
];
const IMAGE_SIZES = [
  { id: "1:1", label: "1:1", sublabel: "Square", w: 512, h: 512 },
  { id: "9:16", label: "9:16", sublabel: "Portrait", w: 512, h: 896 },
  { id: "16:9", label: "16:9", sublabel: "Landscape", w: 896, h: 512 },
];
const IMAGE_COUNTS = [1, 2, 4];
const HF_MODELS = [
  "stabilityai/stable-diffusion-xl-base-1.0",
  "runwayml/stable-diffusion-v1-5",
  "CompVis/stable-diffusion-v1-4",
];

/* ============================== v1.7: Image-to-Image + Audio-to-Image Constants (Features 71-74) ============================== */
const I2I_MAX_BYTES = 8 * 1024 * 1024; // 8MB
const I2I_ACCEPTED_TYPES = ["image/png", "image/jpeg", "image/jpg", "image/webp"];
const AUDIO_LANGS = [
  { id: "en", label: "English", code: "en-US" },
  { id: "hi", label: "Hindi", code: "hi-IN" },
  { id: "hinglish", label: "Hinglish", code: "hi-IN" },
];
const IMG_GEN_MODES = ["text", "image", "audio"]; // text-to-image | image-to-image | audio-to-image

/* ============================== v1.8: Advanced Image Generator additions (Feature 77) ============================== */
const IMAGE_QUALITIES = [
  { id: "sd", label: "Standard", mult: 1 },
  { id: "hd", label: "HD", mult: 1.5 },
  { id: "uhd", label: "Ultra HD", mult: 2 },
];
const GEN_SPEED_MODES = [
  { id: "fast", steps: 16, guidance: 6.5 },
  { id: "quality", steps: 36, guidance: 8.5 },
];

/* ============================== v1.8: AI Image Editor Constants (Feature 75) ============================== */
const EDIT_TOOLS = [
  { id: "removebg", label: "Remove Background", icon: "✂️" },
  { id: "enhance", label: "Enhance & Restore", icon: "✨" },
  { id: "upscale", label: "Upscale 2x", icon: "🔍" },
  { id: "recolor", label: "Recolor", icon: "🎨" },
];
const EDIT_MAX_BYTES = 8 * 1024 * 1024; // 8MB
const EDIT_ACCEPTED_TYPES = ["image/png", "image/jpeg", "image/jpg", "image/webp"];

/* ============================== v1.8: Text-to-Video Constants (Feature 76) ============================== */
const VIDEO_STYLES = [
  { id: "cinematic", label: "Cinematic", icon: "🎬", suffix: "cinematic, dramatic lighting, film grain, smooth camera motion" },
  { id: "realistic", label: "Realistic", icon: "📷", suffix: "photorealistic, natural lighting, lifelike motion, 4k" },
  { id: "anime", label: "Anime", icon: "🎌", suffix: "anime style, vibrant colors, expressive motion, Studio Ghibli inspired" },
  { id: "3d", label: "3D Render", icon: "📦", suffix: "3D render, octane render, smooth animation, volumetric lighting" },
];
const VIDEO_SIZES = [
  { id: "16:9", label: "16:9", sublabel: "Landscape", w: 896, h: 512 },
  { id: "9:16", label: "9:16", sublabel: "Portrait", w: 512, h: 896 },
  { id: "1:1", label: "1:1", sublabel: "Square", w: 512, h: 512 },
];
const VIDEO_DURATIONS = [3, 5, 8];
const HF_VIDEO_MODELS = [
  "damo-vilab/text-to-video-ms-1.7b",
  "cerspense/zeroscope_v2_576w",
];

/* ============================== v1.8: Media Gallery Constants (Feature 78) ============================== */
const GALLERY_FILTERS = ["all", "image", "video", "edit"];
const GALLERY_SYNC_MAX_BYTES = 900_000; // per-item base64 cap when Cloud Sync is on

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const initials = (n) => (n || "?").trim().split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();

/* v1.8 Feature 78: convert a Blob to a base64 data URL (used for optional Cloud Sync persistence) */
function blobToDataURL(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error("Read failed"));
    r.readAsDataURL(blob);
  });
}

/* v1.8 Feature 78: strip ephemeral blob: URLs out of generated-media history before persisting.
   If Cloud Sync produced a `persisted` data URL within the size cap, that becomes the stored url
   (so it survives reload). Otherwise the url is cleared and the UI falls back to a placeholder
   instead of a dead blob: link. */
function sanitizeMediaForStorage(m) {
  if (!m) return m;
  if (m.isDemo) return { isDemo: true, desc: m.desc };
  if (m.persisted) return { isDemo: false, desc: "", url: m.persisted };
  return { isDemo: false, desc: "", url: null };
}
function sanitizeHistoryForStorage(history, mediaKey) {
  if (!Array.isArray(history)) return history;
  return history.slice(0, 50).map((item) => {
    const media = item[mediaKey];
    const sanitized = Array.isArray(media) ? media.map(sanitizeMediaForStorage) : sanitizeMediaForStorage(media);
    return { ...item, [mediaKey]: sanitized };
  });
}

/* v1.8 Feature 77: load any image src (blob:/data:/http) into an HTMLImageElement */
function loadImageEl(src) {
  return new Promise((resolve, reject) => {
    const img = new window.Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not load image"));
    img.src = src;
  });
}

/* v1.8 Feature 77: client-side 2x upscale with a light sharpen pass — used as the real,
   always-available fallback for "Upscale" when no Stable Diffusion upscaler API is set. */
async function canvasUpscale(srcUrl, factor = 2) {
  const img = await loadImageEl(srcUrl);
  const w = img.naturalWidth * factor, h = img.naturalHeight * factor;
  const canvas = document.createElement("canvas");
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, 0, 0, w, h);

  // Light unsharp-mask style sharpen (3x3 kernel) to recover some perceived detail
  const data = ctx.getImageData(0, 0, w, h);
  const src = data.data;
  const out = new Uint8ClampedArray(src.length);
  const kernel = [0, -0.18, 0, -0.18, 1.72, -0.18, 0, -0.18, 0];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) {
        out[i] = src[i]; out[i + 1] = src[i + 1]; out[i + 2] = src[i + 2]; out[i + 3] = src[i + 3];
        continue;
      }
      for (let c = 0; c < 3; c++) {
        let sum = 0, k = 0;
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const ni = ((y + dy) * w + (x + dx)) * 4 + c;
            sum += src[ni] * kernel[k++];
          }
        }
        out[i + c] = sum;
      }
      out[i + 3] = src[i + 3];
    }
  }
  data.data.set(out);
  ctx.putImageData(data, 0, 0);
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), "image/png"));
}

/* v1.8 Feature 75: crop an image to a normalized rect {x,y,w,h} given as 0-1 fractions */
async function canvasCrop(srcUrl, rect) {
  const img = await loadImageEl(srcUrl);
  const sx = Math.round(rect.x * img.naturalWidth);
  const sy = Math.round(rect.y * img.naturalHeight);
  const sw = Math.max(1, Math.round(rect.w * img.naturalWidth));
  const sh = Math.max(1, Math.round(rect.h * img.naturalHeight));
  const canvas = document.createElement("canvas");
  canvas.width = sw; canvas.height = sh;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), "image/png"));
}

/* v1.8 Feature 75: resize an image to exact pixel dimensions */
async function canvasResize(srcUrl, width, height) {
  const img = await loadImageEl(srcUrl);
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width)); canvas.height = Math.max(1, Math.round(height));
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), "image/png"));
}

/* v1.8 Feature 75: rotate an image by an arbitrary degree (canvas grows to fit) */
async function canvasRotate(srcUrl, degrees) {
  const img = await loadImageEl(srcUrl);
  const rad = (degrees * Math.PI) / 180;
  const sin = Math.abs(Math.sin(rad)), cos = Math.abs(Math.cos(rad));
  const w = img.naturalWidth, h = img.naturalHeight;
  const newW = Math.round(w * cos + h * sin);
  const newH = Math.round(w * sin + h * cos);
  const canvas = document.createElement("canvas");
  canvas.width = newW; canvas.height = newH;
  const ctx = canvas.getContext("2d");
  ctx.translate(newW / 2, newH / 2);
  ctx.rotate(rad);
  ctx.drawImage(img, -w / 2, -h / 2, w, h);
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), "image/png"));
}

/* ------------------------------- Brand mark ------------------------------ */
function NovexaMark({ size = 28, busy = false }) {
  return (
    <span className="nx-mark" style={{ width: size, height: size }}>
      <Sparkles size={size} className={`nx-mark-big${busy ? " nx-spin" : ""}`} strokeWidth={1.6} />
      <Sparkles size={Math.round(size * 0.52)} className={`nx-mark-small${busy ? " nx-pulse" : ""}`} strokeWidth={1.6} />
    </span>
  );
}

/* ======================== Feature 27: Typing Dots ======================== */
function TypingDots() {
  return (
    <div className="nx-typing-dots">
      <span /><span /><span />
    </div>
  );
}

/* ================================ Styles ================================= */
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@600;700;800&family=Inter:wght@400;500;600&family=Hind:wght@400;500;600&display=swap');

.nx-root, .nx-root * { box-sizing: border-box; }
.nx-root {
  --bg:#F0EFF8; --surface:#FFFFFF; --surface-2:#F7F6FD; --border:#E0DDF5;
  --text:#1C1A2E; --text-muted:#6C6685; --brand:#5B5FEF; --brand-700:#4347C4;
  --brand-soft:#EEEEFF; --accent:#F2A93B; --accent-soft:#FDEACB;
  --danger:#D8456C; --danger-soft:#FBE3EA;
  --shadow: 0 12px 32px rgba(43,39,92,0.12);
  --shadow-sm: 0 2px 8px rgba(43,39,92,0.07);
  --radius-lg: 16px; --radius-md: 12px; --radius-sm: 8px;
  background:var(--bg); color:var(--text);
  font-family:'Inter','Hind',sans-serif;
  height:100%; min-height:600px; width:100%; position:relative; overflow:hidden;
  display:flex; border-radius:16px; border:1px solid var(--border);
}
.nx-root.dark {
  --bg:#0E0C1A; --surface:#17152A; --surface-2:#1E1B35; --border:#2A2749;
  --text:#ECE9FF; --text-muted:#9892BD; --brand:#7B7FF7; --brand-700:#5B5FEF;
  --brand-soft:#1E1D40; --accent:#F2A93B; --accent-soft:#3B2E18;
  --danger:#F08AAA; --danger-soft:#3A1F2C;
  --shadow: 0 16px 40px rgba(0,0,0,0.5);
  --shadow-sm: 0 2px 8px rgba(0,0,0,0.3);
}
.nx-root h1,.nx-root h2,.nx-root h3,.nx-root .nx-display { font-family:'Poppins','Hind',sans-serif; }

/* ---- mark ---- */
.nx-mark { position:relative; display:inline-flex; flex-shrink:0; }
.nx-mark-big { color:var(--brand); position:absolute; top:0; left:0; }
.nx-mark-small { color:var(--accent); position:absolute; bottom:-15%; right:-15%; }
.nx-pulse { animation:nx-pulse 1.4s ease-in-out infinite; }
.nx-spin { animation:nx-spin 3.2s linear infinite; }
@keyframes nx-pulse { 0%,100%{opacity:.55;transform:scale(.9)} 50%{opacity:1;transform:scale(1.08)} }
@keyframes nx-spin { from{transform:rotate(0)} to{transform:rotate(360deg)} }

/* Feature 27: typing dots */
.nx-typing-dots { display:inline-flex; align-items:center; gap:5px; padding:4px 2px; }
.nx-typing-dots span { width:7px; height:7px; border-radius:50%; background:var(--text-muted); display:block;
  animation:nx-dot-bounce 1.2s ease-in-out infinite; }
.nx-typing-dots span:nth-child(2) { animation-delay:.2s; }
.nx-typing-dots span:nth-child(3) { animation-delay:.4s; }
@keyframes nx-dot-bounce { 0%,80%,100%{transform:translateY(0);opacity:.5} 40%{transform:translateY(-6px);opacity:1} }

/* Feature 22: recording indicator */
.nx-recording-badge { display:inline-flex; align-items:center; gap:6px; font-size:12px; color:var(--danger);
  font-weight:600; animation:nx-pulse 1s ease-in-out infinite; }
.nx-recording-dot { width:8px; height:8px; border-radius:50%; background:var(--danger); }

@media (prefers-reduced-motion:reduce) { .nx-pulse,.nx-spin,.nx-dot-bounce,.nx-recording-badge { animation:none !important; } }

/* ---- generic ---- */
.nx-btn { display:inline-flex; align-items:center; gap:8px; border-radius:var(--radius-sm); border:1px solid transparent;
  font:inherit; font-size:13.5px; font-weight:600; padding:10px 16px; cursor:pointer;
  transition:transform .12s, opacity .15s, background .15s, box-shadow .15s; color:var(--text); }
.nx-btn:active { transform:scale(0.96); }
.nx-btn:focus-visible { outline:2px solid var(--brand); outline-offset:2px; }
.nx-btn-primary { background:var(--brand); color:#fff; box-shadow:0 2px 8px rgba(91,95,239,.3); }
.nx-btn-primary:hover { background:var(--brand-700); box-shadow:0 4px 14px rgba(91,95,239,.4); }
.nx-btn-primary:disabled { opacity:.45; cursor:not-allowed; box-shadow:none; }
.nx-btn-ghost { background:transparent; border-color:var(--border); }
.nx-btn-ghost:hover { background:var(--surface-2); }
.nx-btn-danger { background:var(--danger-soft); color:var(--danger); border-color:transparent; }
.nx-btn-secondary { background:var(--surface-2); border-color:var(--border); }
.nx-btn-secondary:hover { background:var(--surface-3, var(--surface-2)); }

/* ---- v1.9 Features 78-81: chat upload + camera ---- */
.nx-composer-dragover { outline:2px dashed var(--brand); outline-offset:2px; background:var(--brand-soft); }
.nx-attach-strip { display:flex; flex-wrap:wrap; gap:8px; padding:0 2px 8px; align-items:center; }
.nx-attach-chip { position:relative; display:flex; align-items:center; gap:6px; background:var(--surface-2);
  border:1px solid var(--border); border-radius:10px; padding:4px 8px 4px 4px; max-width:180px; }
.nx-attach-chip img { width:32px; height:32px; object-fit:cover; border-radius:6px; flex-shrink:0; }
.nx-attach-chip-file { width:32px; height:32px; border-radius:6px; background:var(--surface-3, var(--brand-soft));
  display:flex; align-items:center; justify-content:center; color:var(--brand); flex-shrink:0; }
.nx-attach-chip-name { font-size:12px; color:var(--text-muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:90px; }
.nx-attach-chip button { background:transparent; border:none; cursor:pointer; color:var(--text-muted); display:flex;
  align-items:center; justify-content:center; border-radius:50%; width:18px; height:18px; flex-shrink:0; }
.nx-attach-chip button:hover { background:var(--danger-soft); color:var(--danger); }
.nx-attach-busy { font-size:12px; color:var(--text-muted); display:flex; align-items:center; gap:6px; }

.nx-msg-attachments { display:flex; flex-wrap:wrap; gap:6px; margin-bottom:6px; justify-content:flex-end; }
.nx-msg-attach-img { width:84px; height:84px; object-fit:cover; border-radius:12px; border:1px solid var(--border); }
.nx-msg-attach-file { display:flex; align-items:center; gap:6px; background:var(--surface-2); border:1px solid var(--border);
  border-radius:10px; padding:6px 10px; font-size:12.5px; color:var(--text); max-width:220px; }
.nx-msg-attach-file span { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }

.nx-camera-modal { width:min(440px, 92vw); background:var(--surface); border-radius:var(--radius-lg);
  border:1px solid var(--border); overflow:hidden; display:flex; flex-direction:column; box-shadow:0 20px 60px rgba(0,0,0,.35); }
.nx-camera-header { display:flex; align-items:center; justify-content:space-between; padding:14px 16px;
  border-bottom:1px solid var(--border); font-weight:600; }
.nx-camera-body { background:#000; display:flex; align-items:center; justify-content:center; min-height:320px; max-height:60vh; }
.nx-camera-preview { width:100%; max-height:60vh; object-fit:contain; }
.nx-camera-controls { display:flex; align-items:center; justify-content:center; gap:18px; padding:16px; }
.nx-camera-shutter { width:56px; height:56px; border-radius:50%; background:#fff; border:4px solid var(--border);
  cursor:pointer; flex-shrink:0; }
.nx-camera-shutter:hover { border-color:var(--brand); }
.nx-camera-shutter:disabled { opacity:.4; cursor:not-allowed; }

.nx-btn-danger:hover { opacity:.85; }
.nx-btn-icon { padding:7px; border-radius:var(--radius-sm); background:transparent; border:1px solid transparent;
  color:var(--text-muted); cursor:pointer; display:inline-flex; transition:background .15s, color .12s, transform .1s; }
.nx-btn-icon:hover { background:var(--surface-2); color:var(--text); }
.nx-btn-icon:active { transform:scale(.93); }
.nx-btn-icon:focus-visible { outline:2px solid var(--brand); outline-offset:2px; }
.nx-btn-icon.active { color:var(--brand); background:var(--brand-soft); }

.nx-field { display:flex; flex-direction:column; gap:6px; margin-bottom:14px; }
.nx-field label { font-size:12px; font-weight:600; color:var(--text-muted); text-transform:uppercase; letter-spacing:.04em; }
.nx-input { width:100%; padding:10px 14px; border-radius:var(--radius-sm); border:1.5px solid var(--border);
  background:var(--surface); color:var(--text); font:inherit; font-size:14px; transition:border-color .15s, box-shadow .15s; }
.nx-input:focus { outline:none; border-color:var(--brand); box-shadow:0 0 0 3px rgba(91,95,239,.12); }
.nx-input-row { position:relative; display:flex; align-items:center; }
.nx-input-row .nx-input { padding-right:42px; }
.nx-input-row button { position:absolute; right:6px; background:none; border:none; color:var(--text-muted); cursor:pointer; padding:6px; display:flex; }

.nx-chip { font-size:12.5px; padding:6px 12px; border-radius:999px; border:1.5px solid var(--border);
  background:var(--surface-2); color:var(--text-muted); cursor:pointer; transition:all .15s; font-weight:500; }
.nx-chip:hover { color:var(--text); border-color:var(--brand); background:var(--brand-soft); }
.nx-chip.active { background:var(--brand); color:#fff; border-color:var(--brand); box-shadow:0 2px 8px rgba(91,95,239,.25); }

.nx-banner { display:flex; align-items:flex-start; gap:8px; background:var(--danger-soft); color:var(--danger);
  border-radius:var(--radius-sm); padding:10px 14px; font-size:13px; margin:8px 16px 0; }

/* ---- layout ---- */
.nx-app { display:flex; width:100%; height:100%; position:relative; }

/* ---- sidebar ---- */
.nx-sidebar { width:276px; flex-shrink:0; background:var(--surface); border-right:1px solid var(--border);
  display:flex; flex-direction:column; height:100%; transition:transform .24s cubic-bezier(.4,0,.2,1); z-index:30; }
.nx-sidebar-head { padding:16px 14px; display:flex; align-items:center; gap:10px; border-bottom:1px solid var(--border); }
.nx-brandname { font-weight:800; font-size:17px; letter-spacing:-.3px; background:linear-gradient(135deg,var(--brand),var(--accent)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.nx-newchat { margin:12px 14px 6px; }
.nx-chatlist { flex:1; overflow-y:auto; padding:4px 8px; display:flex; flex-direction:column; gap:1px; }
.nx-chat-item { position:relative; display:flex; align-items:center; gap:8px; padding:9px 10px; border-radius:var(--radius-sm);
  cursor:pointer; color:var(--text); font-size:13.5px; transition:background .14s; }
.nx-chat-item:hover { background:var(--surface-2); }
.nx-chat-item.active { background:var(--brand-soft); color:var(--brand); }
.nx-chat-title { flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:13.5px; }
.nx-chat-actions { display:flex; gap:2px; opacity:0; transition:opacity .15s; }
.nx-chat-item:hover .nx-chat-actions, .nx-chat-item.active .nx-chat-actions { opacity:1; }
.nx-chat-rename-input { width:100%; background:var(--surface); border:1.5px solid var(--brand); border-radius:6px; padding:4px 8px; font:inherit; font-size:13.5px; color:var(--text); }
.nx-confirm-row { display:flex; gap:6px; align-items:center; font-size:12px; color:var(--text-muted); }
.nx-empty-chats { padding:14px 10px; font-size:12.5px; color:var(--text-muted); line-height:1.5; }

.nx-sidebar-foot { border-top:1px solid var(--border); padding:12px 14px; display:flex; flex-direction:column; gap:8px; }
.nx-user-row { display:flex; align-items:center; gap:10px; padding:8px 10px; border-radius:var(--radius-sm); cursor:pointer; transition:background .14s; }
.nx-user-row:hover { background:var(--surface-2); }
.nx-avatar { width:34px; height:34px; border-radius:50%; background:linear-gradient(135deg,var(--brand),var(--accent));
  color:#fff; display:flex; align-items:center; justify-content:center; font-size:12.5px; font-weight:700; flex-shrink:0; }
.nx-user-meta { flex:1; min-width:0; }
.nx-user-name { font-size:13.5px; font-weight:600; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.nx-user-email { font-size:11.5px; color:var(--text-muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.nx-icon-row { display:flex; gap:2px; justify-content:space-between; }

.nx-backdrop { position:fixed; inset:0; background:rgba(10,8,20,.5); z-index:25; display:none; backdrop-filter:blur(2px); }

/* ---- main ---- */
.nx-main { flex:1; display:flex; flex-direction:column; min-width:0; height:100%; background:var(--bg); }
.nx-topbar { display:flex; align-items:center; gap:10px; padding:13px 18px; border-bottom:1px solid var(--border);
  flex-shrink:0; background:var(--surface); }
.nx-topbar-title { font-weight:700; font-size:14.5px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; flex:1; }
.nx-topbar-sub { font-size:11.5px; color:var(--text-muted); }
.nx-topbar-actions { display:flex; gap:2px; margin-left:auto; }
.nx-menu-btn { display:none; }

/* ---- messages ---- */
.nx-messages { flex:1; overflow-y:auto; padding:20px 0 12px; display:flex; flex-direction:column; gap:2px;
  scroll-behavior:smooth; }
.nx-msg-row { display:flex; padding:5px 20px; animation:nx-msg-in .2s ease; }
@keyframes nx-msg-in { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
.nx-msg-row.user { justify-content:flex-end; }
.nx-msg-bubble { max-width:min(600px,84%); padding:12px 16px; border-radius:var(--radius-lg); font-size:14.5px; line-height:1.6; white-space:pre-wrap; position:relative; }
.nx-msg-bubble.ai { background:var(--surface); border:1px solid var(--border); border-top-left-radius:4px; box-shadow:var(--shadow-sm); }
.nx-msg-bubble.user { background:linear-gradient(135deg,var(--brand),var(--brand-700)); color:#fff; border-top-right-radius:4px; box-shadow:0 2px 10px rgba(91,95,239,.25); }
.nx-msg-actions { display:flex; gap:4px; margin-top:5px; align-items:center; }
.nx-msg-copy { font-size:11.5px; display:inline-flex; align-items:center; gap:4px; color:var(--text-muted); background:none; border:none; cursor:pointer; padding:3px 6px; border-radius:5px; transition:background .12s, color .12s; }
.nx-msg-copy:hover { background:var(--surface-2); color:var(--text); }

/* Feature 28: prompt suggestions */
.nx-suggestions { display:flex; flex-wrap:wrap; gap:8px; justify-content:center; max-width:520px; margin-top:16px; }
.nx-suggestion-chip { display:flex; align-items:center; gap:6px; font-size:13px; padding:9px 14px; border-radius:999px;
  border:1.5px solid var(--border); background:var(--surface); color:var(--text); cursor:pointer;
  transition:all .16s; font-family:inherit; font-weight:500; box-shadow:var(--shadow-sm); }
.nx-suggestion-chip:hover { border-color:var(--brand); background:var(--brand-soft); color:var(--brand); transform:translateY(-1px); box-shadow:0 4px 12px rgba(91,95,239,.15); }
.nx-suggestion-chip svg { color:var(--brand); flex-shrink:0; }

/* ---- empty state ---- */
.nx-empty-state { flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; gap:6px; padding:28px; }
.nx-empty-state h2 { font-size:22px; margin:10px 0 4px; }
.nx-empty-state p { font-size:13.5px; color:var(--text-muted); max-width:360px; margin:0; }

/* Feature 27: enhanced loading row */
.nx-loading-row { display:flex; align-items:center; gap:10px; padding:8px 20px; color:var(--text-muted); font-size:13px; }
.nx-loading-bubble { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg);
  border-top-left-radius:4px; padding:12px 16px; box-shadow:var(--shadow-sm); display:inline-block; }

/* ---- composer ---- */
.nx-composer-wrap { padding:10px 16px 14px; border-top:1px solid var(--border); flex-shrink:0; background:var(--surface); }
.nx-composer { display:flex; align-items:flex-end; gap:6px; background:var(--surface-2); border:1.5px solid var(--border);
  border-radius:var(--radius-lg); padding:6px 6px 6px 14px; transition:border-color .2s, box-shadow .2s; }
.nx-composer:focus-within { border-color:var(--brand); box-shadow:0 0 0 3px rgba(91,95,239,.1); }
.nx-composer textarea { flex:1; resize:none; border:none; background:transparent; color:var(--text); font:inherit;
  font-size:14.5px; max-height:140px; line-height:1.55; padding:7px 0; outline:none; }
.nx-composer textarea::placeholder { color:var(--text-muted); }
.nx-composer-btns { display:flex; gap:4px; align-items:center; padding-bottom:2px; flex-shrink:0; }
.nx-send-btn { background:var(--brand); color:#fff; border:none; border-radius:var(--radius-sm); width:36px; height:36px;
  display:flex; align-items:center; justify-content:center; cursor:pointer; transition:background .15s, transform .1s, box-shadow .15s;
  box-shadow:0 2px 8px rgba(91,95,239,.3); }
.nx-send-btn:hover { background:var(--brand-700); box-shadow:0 4px 14px rgba(91,95,239,.4); }
.nx-send-btn:disabled { opacity:.4; cursor:not-allowed; box-shadow:none; }
.nx-send-btn:active { transform:scale(.92); }
.nx-key-hint { display:flex; align-items:center; justify-content:center; gap:8px; font-size:12.5px; color:var(--text-muted); padding:6px 0 2px; }

/* Feature 22: voice recording indicator in composer */
.nx-voice-indicator { display:flex; align-items:center; justify-content:center; gap:8px; padding:6px 0 2px; font-size:12.5px; }

/* ---- auth ---- */
.nx-auth-wrap { width:100%; height:100%; display:flex; align-items:center; justify-content:center; padding:24px; overflow-y:auto; }
.nx-auth-card { width:100%; max-width:390px; background:var(--surface); border:1px solid var(--border); border-radius:20px; padding:32px 28px; box-shadow:var(--shadow); }
.nx-auth-brand { display:flex; align-items:center; gap:10px; justify-content:center; margin-bottom:6px; }
.nx-auth-tagline { text-align:center; font-size:13px; color:var(--text-muted); margin:0 0 24px; }
.nx-tabs { display:flex; background:var(--surface-2); border-radius:10px; padding:4px; margin-bottom:20px; gap:4px; }
.nx-tab { flex:1; text-align:center; padding:9px; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer;
  color:var(--text-muted); transition:all .16s; }
.nx-tab.active { background:var(--surface); color:var(--text); box-shadow:var(--shadow-sm); }
.nx-divider { display:flex; align-items:center; gap:10px; color:var(--text-muted); font-size:12px; margin:16px 0; }
.nx-divider::before,.nx-divider::after { content:''; flex:1; height:1px; background:var(--border); }
.nx-google-btn { width:100%; justify-content:center; }
.nx-google-badge { width:19px; height:19px; border-radius:50%; background:var(--text); color:var(--surface); font-size:11px; font-weight:800; display:flex; align-items:center; justify-content:center; }
.nx-lang-toggle-corner { position:absolute; top:16px; right:16px; }

/* ---- modal ---- */
.nx-modal-overlay { position:absolute; inset:0; background:rgba(10,8,20,.5); display:flex; align-items:center; justify-content:center; z-index:50; padding:18px; backdrop-filter:blur(4px); }
.nx-modal { width:100%; max-width:470px; max-height:90%; overflow-y:auto; background:var(--surface); border:1px solid var(--border);
  border-radius:20px; padding:24px; box-shadow:var(--shadow); animation:nx-modal-in .18s ease; }
@keyframes nx-modal-in { from{opacity:0;transform:scale(.96) translateY(8px)} to{opacity:1;transform:scale(1) translateY(0)} }
.nx-modal-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
.nx-modal-head h3 { margin:0; font-size:18px; }
.nx-section-label { font-size:11.5px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:var(--text-muted);
  margin:20px 0 8px; }
.nx-section-label:first-child { margin-top:0; }
.nx-chip-row { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:6px; }
.nx-link-hint { font-size:11.5px; color:var(--text-muted); }
.nx-link-hint a { color:var(--brand); text-decoration:none; }
.nx-link-hint a:hover { text-decoration:underline; }
.nx-provider-switch { display:flex; gap:8px; margin-bottom:16px; flex-wrap:wrap; }
.nx-provider-switch .nx-chip { flex:1; text-align:center; padding:9px; font-size:13px; min-width:80px; }
.nx-toggle-row { display:flex; align-items:center; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--border); }
.nx-toggle-row:last-of-type { border-bottom:none; }
.nx-pill-group { display:flex; background:var(--surface-2); border-radius:9px; padding:3px; gap:2px; }
.nx-pill { padding:6px 12px; border-radius:7px; font-size:12.5px; font-weight:600; cursor:pointer; color:var(--text-muted);
  border:none; background:none; transition:all .15s; }
.nx-pill.active { background:var(--surface); color:var(--text); box-shadow:var(--shadow-sm); }
.nx-save-row { display:flex; align-items:center; gap:10px; margin-top:20px; }
.nx-saved-flag { font-size:12.5px; color:var(--brand); font-weight:600; }
.nx-demo-note { font-size:11.5px; color:var(--text-muted); margin-top:14px; line-height:1.55; }

/* ---- scrollbars ---- */
.nx-root *::-webkit-scrollbar { width:6px; height:6px; }
.nx-root *::-webkit-scrollbar-track { background:transparent; }
.nx-root *::-webkit-scrollbar-thumb { background:var(--border); border-radius:8px; }
.nx-root *::-webkit-scrollbar-thumb:hover { background:var(--text-muted); }

/* ---- mic recording pulse ---- */
.nx-btn-icon.recording { color:#fff !important; background:var(--danger) !important; border-color:var(--danger) !important; animation:nx-mic-pulse 1s ease-in-out infinite; }
@keyframes nx-mic-pulse { 0%,100%{box-shadow:0 0 0 0 rgba(216,69,108,.4)} 50%{box-shadow:0 0 0 6px rgba(216,69,108,0)} }

/* ---- Feature 30: mobile improvements ---- */
@media (max-width:880px) {
  .nx-sidebar { position:fixed; top:0; left:0; height:100%; transform:translateX(-100%); box-shadow:var(--shadow); }
  .nx-sidebar.open { transform:translateX(0); }
  .nx-backdrop.show { display:block; }
  .nx-menu-btn { display:inline-flex; }
  .nx-msg-bubble { max-width:90%; }
  .nx-topbar-actions .nx-btn-icon span { display:none; }
  .nx-composer-wrap { padding:8px 10px 12px; }
}
@media (max-width:480px) {
  .nx-suggestions { gap:6px; }
  .nx-suggestion-chip { font-size:12px; padding:8px 12px; }
  .nx-empty-state h2 { font-size:18px; }
}

/* ============================ Feature 31-40: Study AI ============================ */
.nx-nav-switch { display:flex; gap:4px; padding:8px 14px 0; }
.nx-nav-switch button { flex:1; min-width:0; display:flex; align-items:center; justify-content:center; gap:5px;
  font-size:11.5px; font-weight:600; padding:7px 4px; border-radius:var(--radius-sm); border:1.5px solid var(--border);
  background:var(--surface-2); color:var(--text-muted); cursor:pointer; transition:all .15s; white-space:nowrap; overflow:hidden; }
.nx-nav-switch button.active { background:var(--brand); color:#fff; border-color:var(--brand); }

.nx-study-layout { display:flex; flex:1; min-height:0; }
.nx-study-side { width:220px; flex-shrink:0; border-right:1px solid var(--border); padding:14px 10px; overflow-y:auto; background:var(--surface); }
.nx-study-side-title { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:var(--text-muted); padding:6px 8px 10px; }
.nx-study-tab { display:flex; align-items:center; gap:9px; padding:9px 10px; border-radius:var(--radius-sm); cursor:pointer;
  font-size:13.5px; color:var(--text); margin-bottom:2px; transition:background .14s; }
.nx-study-tab:hover { background:var(--surface-2); }
.nx-study-tab.active { background:var(--brand-soft); color:var(--brand); font-weight:600; }
.nx-study-tab svg { flex-shrink:0; }

.nx-study-main { flex:1; min-width:0; display:flex; flex-direction:column; overflow-y:auto; padding:20px 24px; gap:16px; }
.nx-study-doclist { display:flex; flex-direction:column; gap:6px; margin-top:6px; }
.nx-doc-chip { display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:var(--radius-sm); border:1.5px solid var(--border);
  background:var(--surface-2); cursor:pointer; font-size:12.5px; transition:all .14s; }
.nx-doc-chip.active { border-color:var(--brand); background:var(--brand-soft); color:var(--brand); }
.nx-doc-chip-name { flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.nx-doc-chip-del { color:var(--text-muted); flex-shrink:0; display:flex; }
.nx-doc-chip-del:hover { color:var(--danger); }

.nx-upload-zone { border:2px dashed var(--border); border-radius:var(--radius-lg); padding:36px 20px; text-align:center;
  cursor:pointer; transition:all .18s; background:var(--surface-2); }
.nx-upload-zone:hover, .nx-upload-zone.drag { border-color:var(--brand); background:var(--brand-soft); }
.nx-upload-zone svg { color:var(--brand); margin-bottom:8px; }
.nx-upload-zone h4 { margin:4px 0; font-size:15px; }
.nx-upload-zone p { margin:0; font-size:12.5px; color:var(--text-muted); }

.nx-study-card { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg); padding:18px; box-shadow:var(--shadow-sm); }
.nx-study-card h4 { margin:0 0 10px; font-size:14.5px; }
.nx-mode-row { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:12px; }
.nx-result-box { background:var(--surface-2); border-radius:var(--radius-md); padding:14px; font-size:13.5px; line-height:1.65; white-space:pre-wrap; max-height:420px; overflow-y:auto; }

.nx-docchat-thread { flex:1; display:flex; flex-direction:column; gap:10px; overflow-y:auto; min-height:120px; }
.nx-docchat-row { display:flex; }
.nx-docchat-row.user { justify-content:flex-end; }
.nx-docchat-bubble { max-width:80%; padding:10px 14px; border-radius:14px; font-size:13.5px; line-height:1.55; white-space:pre-wrap; }
.nx-docchat-bubble.user { background:linear-gradient(135deg,var(--brand),var(--brand-700)); color:#fff; border-bottom-right-radius:4px; }
.nx-docchat-bubble.ai { background:var(--surface); border:1px solid var(--border); border-bottom-left-radius:4px; }

.nx-quiz-q { border:1px solid var(--border); border-radius:var(--radius-md); padding:14px; margin-bottom:12px; background:var(--surface-2); }
.nx-quiz-q-title { font-weight:600; font-size:13.5px; margin-bottom:8px; }
.nx-quiz-opt { display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:8px; border:1.5px solid var(--border);
  background:var(--surface); cursor:pointer; font-size:13px; margin-bottom:6px; transition:all .13s; }
.nx-quiz-opt:hover { border-color:var(--brand); }
.nx-quiz-opt.selected { border-color:var(--brand); background:var(--brand-soft); }
.nx-quiz-opt.correct { border-color:#2EA86B; background:rgba(46,168,107,.12); }
.nx-quiz-opt.incorrect { border-color:var(--danger); background:var(--danger-soft); }
.nx-quiz-short-input { width:100%; padding:8px 10px; border-radius:8px; border:1.5px solid var(--border); background:var(--surface); color:var(--text); font:inherit; font-size:13px; }
.nx-quiz-score { font-weight:700; font-size:15px; color:var(--brand); margin-top:8px; }

.nx-flash-card { width:100%; max-width:420px; min-height:200px; margin:0 auto; perspective:1200px; cursor:pointer; }
.nx-flash-inner { position:relative; width:100%; height:200px; transition:transform .5s; transform-style:preserve-3d; }
.nx-flash-inner.flipped { transform:rotateY(180deg); }
.nx-flash-face { position:absolute; inset:0; backface-visibility:hidden; border-radius:var(--radius-lg); border:1px solid var(--border);
  display:flex; align-items:center; justify-content:center; text-align:center; padding:20px; font-size:15px; line-height:1.5;
  background:var(--surface); box-shadow:var(--shadow-sm); }
.nx-flash-face.back { transform:rotateY(180deg); background:var(--brand-soft); color:var(--brand); font-weight:600; }
.nx-flash-nav { display:flex; align-items:center; justify-content:center; gap:14px; margin-top:14px; }
.nx-flash-hint { text-align:center; font-size:11.5px; color:var(--text-muted); margin-top:8px; }

.nx-study-empty { flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; text-align:center; color:var(--text-muted); padding:30px; }
.nx-table-wrap { overflow:auto; max-height:340px; border:1px solid var(--border); border-radius:var(--radius-md); }
.nx-data-table { border-collapse:collapse; width:100%; font-size:12.5px; }
.nx-data-table th, .nx-data-table td { border:1px solid var(--border); padding:6px 10px; text-align:left; white-space:nowrap; }
.nx-data-table th { background:var(--surface-2); position:sticky; top:0; }

.nx-textarea-box { width:100%; min-height:90px; padding:10px 14px; border-radius:var(--radius-md); border:1.5px solid var(--border);
  background:var(--surface); color:var(--text); font:inherit; font-size:13.5px; resize:vertical; }
.nx-textarea-box:focus { outline:none; border-color:var(--brand); }

@media (max-width:880px) {
  .nx-study-layout { flex-direction:column; }
  .nx-study-side { width:100%; border-right:none; border-bottom:1px solid var(--border); display:flex; overflow-x:auto; gap:4px; padding:10px; }
  .nx-study-side-title { display:none; }
  .nx-study-tab { flex-shrink:0; margin-bottom:0; }
  .nx-study-main { padding:14px; }
}

/* ============================ Features 41-50: Coding + Writing AI ============================ */
.nx-nav-switch { flex-wrap:wrap; }
.nx-nav-switch button { flex-basis: calc(33.33% - 4px); }

.nx-mode-row .nx-chip { display:inline-flex; align-items:center; gap:6px; }

/* ---- code block + syntax highlighting ---- */
.nx-codeblock { background:#1A1730; border:1px solid var(--border); border-radius:var(--radius-md); overflow:hidden; margin:10px 0; }
.nx-root.dark .nx-codeblock { background:#0B0A16; }
.nx-codeblock-bar { display:flex; align-items:center; justify-content:space-between; padding:7px 12px; background:rgba(255,255,255,0.04); border-bottom:1px solid rgba(255,255,255,0.08); }
.nx-codeblock-lang { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:#B7B2E8; }
.nx-codeblock-copy { display:inline-flex; align-items:center; gap:5px; background:none; border:none; color:#B7B2E8; font:inherit; font-size:12px; font-weight:600; cursor:pointer; padding:3px 6px; border-radius:6px; transition:background .15s,color .15s; }
.nx-codeblock-copy:hover { background:rgba(255,255,255,0.1); color:#fff; }
.nx-codeblock pre { margin:0; padding:14px; overflow-x:auto; max-height:420px; }
.nx-codeblock code { font-family:'Menlo','Consolas',monospace; font-size:12.8px; line-height:1.65; color:#E7E4FF; white-space:pre; }
.nx-tok-keyword { color:#7FB1FF; font-weight:600; }
.nx-tok-string { color:#9EE6A8; }
.nx-tok-comment { color:#7A7596; font-style:italic; }
.nx-tok-number { color:#F2A93B; }
.nx-tok-tag { color:#F08AAA; font-weight:600; }
.nx-tok-attr { color:#B7B2E8; }
.nx-tok-prop { color:#7FB1FF; }
.nx-tok-func { color:#9EE6A8; }

.nx-ai-text-block { font-size:13.5px; line-height:1.65; white-space:pre-wrap; color:var(--text); margin:8px 0; }

/* ---- code tabs (Feature 43: website generator) ---- */
.nx-code-tabs { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:12px; }
.nx-preview-frame-wrap { border:1px solid var(--border); border-radius:var(--radius-md); overflow:hidden; background:#fff; }
.nx-preview-frame-wrap iframe { width:100%; height:420px; border:none; display:block; background:#fff; }
.nx-preview-toolbar { display:flex; align-items:center; gap:8px; padding:8px 12px; background:var(--surface-2); border-bottom:1px solid var(--border); font-size:12px; color:var(--text-muted); }

/* ---- copy-result button (Features 45-50) ---- */
.nx-copy-result-btn { display:inline-flex; align-items:center; gap:6px; font-size:12.5px; font-weight:600; color:var(--brand);
  background:var(--brand-soft); border:none; border-radius:7px; padding:6px 11px; cursor:pointer; transition:opacity .15s; }
.nx-copy-result-btn:hover { opacity:.82; }
.nx-result-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:8px; }
.nx-result-head h5 { margin:0; font-size:12.5px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:var(--text-muted); }

/* ---- resume builder (Feature 48) ---- */
.nx-resume-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px 16px; }
.nx-resume-grid .nx-field.full { grid-column:1 / -1; }
.nx-resume-preview { border:1px solid var(--border); border-radius:var(--radius-lg); padding:26px; background:#fff; color:#1C1A2E;
  font-size:13px; line-height:1.6; white-space:pre-wrap; max-height:560px; overflow-y:auto; }
.nx-resume-preview.tpl-modern { font-family:'Inter',sans-serif; border-top:6px solid var(--brand); }
.nx-resume-preview.tpl-classic { font-family:'Hind',serif; border-top:6px solid #1C1A2E; }
.nx-resume-preview.tpl-minimal { font-family:'Inter',sans-serif; border-top:1px solid var(--border); }
.nx-resume-actions { display:flex; gap:10px; margin-top:14px; flex-wrap:wrap; }

@media (max-width:600px) {
  .nx-resume-grid { grid-template-columns:1fr; }
}

/* ---- v1.4: Web Intelligence Hub ---- */
.nx-source-link { display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:var(--radius-md);
  background:var(--surface-2); font-size:12.5px; text-decoration:none; color:var(--text); margin-bottom:6px; overflow:hidden; }
.nx-source-link span:last-child { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.nx-source-link:hover { background:var(--border); }
.nx-source-idx { flex-shrink:0; width:18px; height:18px; border-radius:50%; background:var(--brand); color:#fff;
  font-size:10px; font-weight:700; display:flex; align-items:center; justify-content:center; }

.nx-weather-card { margin-top:14px; background:linear-gradient(135deg,var(--brand),var(--brand-700)); color:#fff;
  border-radius:var(--radius-lg); padding:20px; }
.nx-weather-place { display:flex; align-items:center; gap:6px; font-size:13px; opacity:.9; }
.nx-weather-temp { font-size:40px; font-weight:800; margin:6px 0 0; }
.nx-weather-cond { font-size:14px; opacity:.95; margin-bottom:14px; }
.nx-weather-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; padding-top:12px; border-top:1px solid rgba(255,255,255,.25); }
.nx-weather-grid div { display:flex; flex-direction:column; gap:2px; }
.nx-weather-grid span { font-size:10.5px; opacity:.8; text-transform:uppercase; letter-spacing:.04em; }
.nx-weather-grid b { font-size:14px; }

.nx-table-wrap { overflow-x:auto; border:1px solid var(--border); border-radius:var(--radius-md); margin-top:8px; }
.nx-data-table { width:100%; border-collapse:collapse; font-size:12.5px; }
.nx-data-table th, .nx-data-table td { padding:8px 10px; text-align:left; border-bottom:1px solid var(--border); white-space:nowrap; }
.nx-data-table th { background:var(--surface-2); font-weight:700; }

.nx-stat-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(140px,1fr)); gap:8px; margin-top:10px; }
.nx-stat-card { background:var(--surface-2); border-radius:var(--radius-md); padding:10px 12px; }
.nx-stat-name { font-size:11.5px; font-weight:700; color:var(--text-muted); margin-bottom:3px; text-transform:uppercase; }
.nx-stat-vals { font-size:12px; }

.nx-chart-box { margin-top:16px; background:var(--surface-2); border-radius:var(--radius-lg); padding:16px; }

/* ---- v1.4: File Chat ---- */
.nx-filechat-layout { display:flex; flex:1; min-height:0; }
.nx-filechat-side { width:240px; flex-shrink:0; border-right:1px solid var(--border); padding:16px; overflow-y:auto; }
.nx-upload-zone { width:100%; display:flex; flex-direction:column; align-items:center; gap:8px; padding:22px 10px;
  border:1.5px dashed var(--border); border-radius:var(--radius-lg); background:var(--surface-2); color:var(--text-muted);
  font-size:12.5px; font-weight:600; cursor:pointer; margin-top:8px; transition:.15s; }
.nx-upload-zone:hover { border-color:var(--brand); color:var(--brand); }
.nx-uploading { display:flex; align-items:center; gap:6px; font-size:12px; color:var(--text-muted); margin-top:10px; }
.nx-filechat-list { margin-top:14px; display:flex; flex-direction:column; gap:6px; }
.nx-filechat-item { display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:var(--radius-md);
  background:var(--surface-2); font-size:12.5px; }
.nx-filechat-name { flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.nx-filechat-main { flex:1; min-width:0; display:flex; flex-direction:column; }
.nx-filechat-messages { flex:1; overflow-y:auto; padding:20px 24px; display:flex; flex-direction:column; gap:14px; }
.nx-filechat-main .nx-composer { margin:0 24px 20px; }

@media (max-width:680px) {
  .nx-filechat-layout { flex-direction:column; }
  .nx-filechat-side { width:100%; border-right:none; border-bottom:1px solid var(--border); }
  .nx-filechat-messages, .nx-filechat-main .nx-composer { padding-left:14px; padding-right:14px; margin-left:0; margin-right:0; }
}

/* ============================== v1.5: AI Voice Call (Features 61-70) ============================== */

/* Call screen container */
.nx-call-screen {
  flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-start;
  position: relative; overflow: hidden; background: var(--bg);
}

/* Animated gradient orb when call is active */
.nx-call-orb-wrap {
  position: relative; display: flex; align-items: center; justify-content: center;
  width: 180px; height: 180px; margin: 24px auto 16px; flex-shrink: 0;
}
.nx-call-orb {
  width: 140px; height: 140px; border-radius: 50%;
  background: radial-gradient(circle at 38% 36%, var(--brand) 0%, var(--brand-700) 55%, #2B1D6E 100%);
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 0 0 0 rgba(91,95,239,.5);
  transition: transform .3s;
  position: relative; z-index: 2;
}
.nx-call-orb.speaking {
  animation: nx-orb-pulse 1.2s ease-in-out infinite;
}
.nx-call-orb.listening {
  animation: nx-orb-listen 1.6s ease-in-out infinite;
}
.nx-call-orb.idle {
  opacity: .7;
}
@keyframes nx-orb-pulse {
  0%,100% { box-shadow: 0 0 0 0 rgba(91,95,239,.45); transform: scale(1); }
  50% { box-shadow: 0 0 0 28px rgba(91,95,239,0); transform: scale(1.06); }
}
@keyframes nx-orb-listen {
  0%,100% { box-shadow: 0 0 0 0 rgba(216,69,108,.4); transform: scale(1); }
  50% { box-shadow: 0 0 0 22px rgba(216,69,108,0); transform: scale(1.04); }
}
.nx-call-orb-ring {
  position: absolute; border-radius: 50%; border: 2px solid var(--brand); opacity: 0;
  animation: nx-ring-expand 2s ease-out infinite;
}
.nx-call-orb-ring:nth-child(1) { width: 160px; height: 160px; animation-delay: 0s; }
.nx-call-orb-ring:nth-child(2) { width: 180px; height: 180px; animation-delay: .5s; }
.nx-call-orb-ring:nth-child(3) { width: 200px; height: 200px; animation-delay: 1s; }
@keyframes nx-ring-expand {
  0% { transform: scale(.8); opacity: .6; }
  100% { transform: scale(1.1); opacity: 0; }
}

/* Status text area */
.nx-call-status-label {
  font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 4px; text-align: center;
}
.nx-call-name {
  font-family: 'Poppins', sans-serif; font-size: 22px; font-weight: 700; color: var(--text);
  text-align: center; margin: 0 0 2px;
}
.nx-call-timer {
  font-size: 14px; color: var(--text-muted); font-variant-numeric: tabular-nums; text-align: center;
  margin-bottom: 10px;
}

/* Live transcript bubble */
.nx-call-transcript-live {
  width: 100%; max-width: 420px; margin: 0 auto 12px;
  background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-lg);
  padding: 12px 16px; font-size: 13.5px; line-height: 1.55; min-height: 52px;
  color: var(--text); box-shadow: var(--shadow-sm); text-align: center;
  transition: opacity .3s;
}
.nx-call-transcript-live.speaking { border-color: var(--brand); color: var(--brand); }
.nx-call-transcript-live.listening { border-color: var(--danger); }

/* Call controls */
.nx-call-controls {
  display: flex; align-items: center; justify-content: center; gap: 16px;
  padding: 16px; flex-shrink: 0;
}
.nx-call-btn {
  width: 58px; height: 58px; border-radius: 50%; display: flex; align-items: center;
  justify-content: center; border: none; cursor: pointer;
  transition: transform .15s, box-shadow .15s, opacity .15s;
  font-family: inherit;
}
.nx-call-btn:active { transform: scale(.92); }
.nx-call-btn.primary {
  width: 72px; height: 72px;
  background: linear-gradient(135deg, var(--brand), var(--brand-700));
  color: #fff; box-shadow: 0 4px 18px rgba(91,95,239,.4);
}
.nx-call-btn.primary:hover { box-shadow: 0 6px 24px rgba(91,95,239,.55); }
.nx-call-btn.danger {
  background: var(--danger); color: #fff;
  box-shadow: 0 4px 18px rgba(216,69,108,.35);
}
.nx-call-btn.danger:hover { opacity: .88; }
.nx-call-btn.secondary {
  background: var(--surface-2); color: var(--text-muted);
  border: 1.5px solid var(--border);
}
.nx-call-btn.secondary:hover { background: var(--border); color: var(--text); }
.nx-call-btn.active-mic {
  background: var(--danger-soft); color: var(--danger);
  border: 2px solid var(--danger); animation: nx-mic-pulse 1s ease-in-out infinite;
}
.nx-call-btn:disabled { opacity: .4; cursor: not-allowed; }

/* Start call big button */
.nx-call-start-btn {
  display: flex; flex-direction: column; align-items: center; gap: 10px;
  background: linear-gradient(135deg, #2EA86B, #1E7A4F);
  color: #fff; border: none; border-radius: 24px; padding: 20px 48px;
  font-family: 'Poppins', sans-serif; font-size: 16px; font-weight: 700;
  cursor: pointer; box-shadow: 0 6px 24px rgba(46,168,107,.4);
  transition: transform .15s, box-shadow .15s;
}
.nx-call-start-btn:hover { transform: translateY(-2px); box-shadow: 0 10px 32px rgba(46,168,107,.5); }
.nx-call-start-btn:active { transform: scale(.97); }
.nx-call-start-btn svg { width: 32px; height: 32px; }

/* Pre-call setup panel */
.nx-call-pre {
  flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 24px; gap: 20px; text-align: center;
}
.nx-call-pre h2 { font-family: 'Poppins', sans-serif; font-size: 22px; margin: 0; }
.nx-call-pre p { color: var(--text-muted); font-size: 13.5px; margin: 0; max-width: 340px; }

/* Call options row */
.nx-call-options {
  display: flex; flex-wrap: wrap; gap: 10px; justify-content: center;
  background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-lg);
  padding: 16px; width: 100%; max-width: 400px;
}
.nx-call-option-row {
  display: flex; align-items: center; justify-content: space-between; width: 100%;
  font-size: 13px;
}
.nx-call-option-label { color: var(--text-muted); font-weight: 600; display: flex; align-items: center; gap: 6px; }

/* Waveform bars (speaking animation) */
.nx-waveform {
  display: flex; align-items: center; justify-content: center; gap: 3px;
  height: 28px;
}
.nx-waveform span {
  width: 3px; border-radius: 2px; background: var(--brand);
  animation: nx-wave 1s ease-in-out infinite;
  transform-origin: bottom;
}
.nx-waveform span:nth-child(1) { height: 8px; animation-delay: 0s; }
.nx-waveform span:nth-child(2) { height: 18px; animation-delay: .1s; }
.nx-waveform span:nth-child(3) { height: 24px; animation-delay: .2s; }
.nx-waveform span:nth-child(4) { height: 14px; animation-delay: .3s; }
.nx-waveform span:nth-child(5) { height: 20px; animation-delay: .4s; }
.nx-waveform span:nth-child(6) { height: 10px; animation-delay: .5s; }
.nx-waveform span:nth-child(7) { height: 16px; animation-delay: .15s; }
@keyframes nx-wave {
  0%, 100% { transform: scaleY(0.4); opacity: .5; }
  50% { transform: scaleY(1); opacity: 1; }
}
.nx-waveform.mic span { background: var(--danger); }
.nx-waveform.idle span { animation: none; transform: scaleY(0.3); opacity: .3; }

/* Call history tab */
.nx-call-history-list {
  width: 100%; display: flex; flex-direction: column; gap: 8px;
  max-height: 360px; overflow-y: auto; padding: 0 4px;
}
.nx-call-history-item {
  background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-md);
  padding: 12px 14px; display: flex; flex-direction: column; gap: 6px;
}
.nx-call-history-header {
  display: flex; align-items: center; justify-content: space-between;
}
.nx-call-history-date { font-size: 11.5px; color: var(--text-muted); }
.nx-call-history-dur { font-size: 12px; font-weight: 700; color: var(--brand); }
.nx-call-history-turns { font-size: 12px; color: var(--text-muted); }
.nx-call-history-preview {
  font-size: 12.5px; color: var(--text); line-height: 1.45;
  overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
}
.nx-call-tab-row {
  display: flex; gap: 8px; padding: 12px 16px 0; flex-shrink: 0;
}
.nx-call-tab {
  flex: 1; padding: 8px; border-radius: var(--radius-sm); border: 1.5px solid var(--border);
  background: var(--surface-2); color: var(--text-muted); font: inherit; font-size: 12.5px;
  font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: center;
  gap: 6px; transition: all .15s;
}
.nx-call-tab.active { background: var(--brand); color: #fff; border-color: var(--brand); }

/* Topbar voice call button */
.nx-voice-call-fab {
  position: fixed; bottom: 80px; right: 16px; width: 52px; height: 52px;
  background: linear-gradient(135deg, #2EA86B, var(--brand)); color: #fff;
  border-radius: 50%; display: flex; align-items: center; justify-content: center;
  box-shadow: 0 4px 18px rgba(46,168,107,.45); border: none; cursor: pointer; z-index: 20;
  transition: transform .15s;
}
.nx-voice-call-fab:hover { transform: scale(1.07); }

/* Error banner in call */
.nx-call-error {
  display: flex; align-items: center; gap: 8px; background: var(--danger-soft);
  color: var(--danger); border-radius: var(--radius-sm); padding: 10px 14px;
  font-size: 12.5px; width: 100%; max-width: 400px; margin: 0 auto;
}

/* Hands-free toggle */
.nx-toggle-switch {
  position: relative; width: 40px; height: 22px; flex-shrink: 0;
}
.nx-toggle-switch input { opacity: 0; width: 0; height: 0; }
.nx-toggle-slider {
  position: absolute; inset: 0; background: var(--border); border-radius: 999px;
  cursor: pointer; transition: background .2s;
}
.nx-toggle-slider::before {
  content: ""; position: absolute; width: 16px; height: 16px; border-radius: 50%;
  background: #fff; top: 3px; left: 3px; transition: transform .2s;
}
.nx-toggle-switch input:checked + .nx-toggle-slider { background: var(--brand); }
.nx-toggle-switch input:checked + .nx-toggle-slider::before { transform: translateX(18px); }

@media (max-width: 480px) {
  .nx-call-orb-wrap { width: 140px; height: 140px; margin: 16px auto 12px; }
  .nx-call-orb { width: 110px; height: 110px; }
  .nx-call-name { font-size: 18px; }
  .nx-call-controls { gap: 12px; }
  .nx-call-btn.primary { width: 62px; height: 62px; }
  .nx-call-pre { padding: 16px; }
  .nx-call-options { padding: 12px; }
}

/* ============================== v1.6: AI Image Generation (Features 71-80) ============================== */

.nx-img-layout { display: flex; flex: 1; min-height: 0; overflow: hidden; }

/* Left panel: generator */
.nx-img-panel {
  width: 340px; flex-shrink: 0; border-right: 1px solid var(--border);
  overflow-y: auto; padding: 20px 18px; background: var(--surface);
  display: flex; flex-direction: column; gap: 16px;
}
.nx-img-panel-title { font-family: 'Poppins',sans-serif; font-size: 17px; font-weight: 700; margin: 0; }
.nx-img-panel-sub { font-size: 12px; color: var(--text-muted); margin: 0; }

/* Prompt box */
.nx-img-prompt-wrap { position: relative; }
.nx-img-prompt {
  width: 100%; min-height: 90px; max-height: 180px; resize: vertical;
  padding: 12px 14px; border-radius: var(--radius-md); border: 1.5px solid var(--border);
  background: var(--surface-2); color: var(--text); font: inherit; font-size: 13.5px;
  line-height: 1.55; transition: border-color .15s, box-shadow .15s;
}
.nx-img-prompt:focus { outline: none; border-color: var(--brand); box-shadow: 0 0 0 3px rgba(91,95,239,.1); }
.nx-img-prompt::placeholder { color: var(--text-muted); }

.nx-img-enhance-btn {
  margin-top: 6px; width: 100%; display: flex; align-items: center; justify-content: center;
  gap: 6px; padding: 8px; border-radius: var(--radius-sm); border: 1.5px dashed var(--border);
  background: transparent; color: var(--brand); font: inherit; font-size: 12.5px; font-weight: 600;
  cursor: pointer; transition: all .15s;
}
.nx-img-enhance-btn:hover { background: var(--brand-soft); border-color: var(--brand); }
.nx-img-enhance-btn:disabled { opacity: .45; cursor: not-allowed; }

/* Style grid */
.nx-img-style-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px;
}
.nx-img-style-btn {
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  padding: 10px 6px; border-radius: var(--radius-md); border: 1.5px solid var(--border);
  background: var(--surface-2); cursor: pointer; font: inherit; color: var(--text-muted);
  font-size: 11px; font-weight: 600; transition: all .15s; text-align: center;
}
.nx-img-style-btn .nx-img-style-icon { font-size: 20px; line-height: 1; }
.nx-img-style-btn:hover { border-color: var(--brand); color: var(--brand); background: var(--brand-soft); }
.nx-img-style-btn.active { border-color: var(--brand); background: var(--brand); color: #fff; }

/* Size selector */
.nx-img-size-row { display: flex; gap: 8px; }
.nx-img-size-btn {
  flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px;
  padding: 8px 6px; border-radius: var(--radius-sm); border: 1.5px solid var(--border);
  background: var(--surface-2); cursor: pointer; font: inherit; transition: all .15s;
}
.nx-img-size-label { font-size: 13px; font-weight: 700; color: var(--text); }
.nx-img-size-sub { font-size: 10px; color: var(--text-muted); }
.nx-img-size-preview { border-radius: 3px; background: var(--border); transition: background .15s; }
.nx-img-size-btn:hover { border-color: var(--brand); }
.nx-img-size-btn.active { border-color: var(--brand); background: var(--brand-soft); }
.nx-img-size-btn.active .nx-img-size-label { color: var(--brand); }
.nx-img-size-btn.active .nx-img-size-preview { background: var(--brand); }

/* Count selector */
.nx-img-count-row { display: flex; gap: 8px; }
.nx-img-count-btn {
  flex: 1; padding: 8px; border-radius: var(--radius-sm); border: 1.5px solid var(--border);
  background: var(--surface-2); cursor: pointer; font: inherit; font-size: 13px; font-weight: 600;
  color: var(--text-muted); text-align: center; transition: all .15s;
}
.nx-img-count-btn:hover { border-color: var(--brand); color: var(--brand); }
.nx-img-count-btn.active { border-color: var(--brand); background: var(--brand); color: #fff; }

/* Generate button */
.nx-img-gen-btn {
  width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px;
  padding: 13px; border-radius: var(--radius-md); border: none;
  background: linear-gradient(135deg, var(--brand), var(--brand-700)); color: #fff;
  font: inherit; font-size: 14.5px; font-weight: 700; cursor: pointer;
  box-shadow: 0 4px 18px rgba(91,95,239,.35); transition: all .15s; font-family: 'Poppins',sans-serif;
}
.nx-img-gen-btn:hover { transform: translateY(-1px); box-shadow: 0 6px 22px rgba(91,95,239,.5); }
.nx-img-gen-btn:disabled { opacity: .5; cursor: not-allowed; transform: none; box-shadow: none; }

/* Right: results + history */
.nx-img-main {
  flex: 1; min-width: 0; overflow-y: auto; display: flex; flex-direction: column; gap: 0;
}

/* Results area */
.nx-img-results-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 16px 20px 8px; flex-shrink: 0;
}
.nx-img-results-title { font-size: 13px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: .05em; }

/* Loading shimmer */
.nx-img-loading {
  display: flex; flex-direction: column; align-items: center; gap: 16px;
  padding: 48px 24px; text-align: center; color: var(--text-muted);
}
.nx-img-shimmer-grid { display: flex; gap: 12px; flex-wrap: wrap; justify-content: center; }
.nx-img-shimmer {
  border-radius: var(--radius-md); background: var(--surface-2);
  animation: nx-shimmer 1.5s ease-in-out infinite alternate;
}
@keyframes nx-shimmer {
  from { opacity: .4; background: var(--surface-2); }
  to { opacity: 1; background: var(--border); }
}

/* Image grid */
.nx-img-grid {
  display: grid; gap: 12px; padding: 12px 20px 20px;
}
.nx-img-grid.count-1 { grid-template-columns: 1fr; max-width: 480px; }
.nx-img-grid.count-2 { grid-template-columns: repeat(2, 1fr); }
.nx-img-grid.count-4 { grid-template-columns: repeat(2, 1fr); }

.nx-img-card {
  position: relative; border-radius: var(--radius-lg); overflow: hidden;
  border: 1.5px solid var(--border); background: var(--surface-2);
  group: "img"; transition: transform .18s, box-shadow .18s;
}
.nx-img-card:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(43,39,92,.18); }

.nx-img-card img {
  width: 100%; height: auto; display: block; border-radius: calc(var(--radius-lg) - 2px);
}

/* Demo image placeholder */
.nx-img-demo-placeholder {
  width: 100%; aspect-ratio: 1; background: linear-gradient(135deg, var(--brand-soft), var(--accent-soft));
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 12px; padding: 24px; text-align: center;
}
.nx-img-demo-icon { font-size: 48px; }
.nx-img-demo-desc { font-size: 13px; color: var(--text); line-height: 1.55; }

/* Image card actions overlay */
.nx-img-card-actions {
  position: absolute; bottom: 0; left: 0; right: 0;
  background: linear-gradient(transparent, rgba(10,8,20,.75));
  padding: 24px 10px 10px; display: flex; gap: 6px; justify-content: center;
  opacity: 0; transition: opacity .18s;
}
.nx-img-card:hover .nx-img-card-actions { opacity: 1; }
.nx-img-action-btn {
  display: flex; align-items: center; gap: 5px; padding: 6px 10px;
  border-radius: var(--radius-sm); background: rgba(255,255,255,.92);
  color: #1C1A2E; border: none; cursor: pointer; font: inherit; font-size: 11.5px;
  font-weight: 700; transition: all .12s;
}
.nx-img-action-btn:hover { background: #fff; transform: scale(1.04); }

/* Prompt display under results */
.nx-img-used-prompt {
  padding: 0 20px 16px; display: flex; align-items: flex-start; gap: 8px;
}
.nx-img-used-prompt-text {
  flex: 1; font-size: 12.5px; color: var(--text-muted); line-height: 1.5;
  background: var(--surface-2); border-radius: var(--radius-sm); padding: 8px 10px;
  border: 1px solid var(--border);
}
.nx-img-regen-btn {
  display: flex; align-items: center; gap: 5px; padding: 7px 12px;
  border-radius: var(--radius-sm); border: 1.5px solid var(--border); background: var(--surface-2);
  color: var(--text-muted); cursor: pointer; font: inherit; font-size: 12px; font-weight: 600;
  white-space: nowrap; transition: all .15s; flex-shrink: 0;
}
.nx-img-regen-btn:hover { border-color: var(--brand); color: var(--brand); background: var(--brand-soft); }

/* History section */
.nx-img-history-section { padding: 0 20px 24px; }
.nx-img-history-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 0 10px; border-top: 1px solid var(--border); margin-top: 4px;
}
.nx-img-history-title { font-size: 13px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: .05em; display: flex; align-items: center; gap: 6px; }
.nx-img-history-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px; margin-top: 8px; }

.nx-img-history-thumb {
  position: relative; border-radius: var(--radius-md); overflow: hidden;
  border: 1.5px solid var(--border); cursor: pointer; aspect-ratio: 1;
  background: var(--surface-2); transition: all .15s;
}
.nx-img-history-thumb:hover { border-color: var(--brand); transform: scale(1.03); }
.nx-img-history-thumb img { width: 100%; height: 100%; object-fit: cover; }
.nx-img-history-demo {
  width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center;
  justify-content: center; gap: 4px; background: linear-gradient(135deg, var(--brand-soft), var(--accent-soft));
  padding: 8px;
}
.nx-img-history-demo-icon { font-size: 28px; }
.nx-img-history-demo-style { font-size: 9.5px; font-weight: 700; color: var(--brand); text-transform: uppercase; }
.nx-img-history-overlay {
  position: absolute; inset: 0; background: rgba(10,8,20,.55);
  display: flex; align-items: center; justify-content: center; gap: 6px;
  opacity: 0; transition: opacity .15s;
}
.nx-img-history-thumb:hover .nx-img-history-overlay { opacity: 1; }
.nx-img-hist-icon-btn {
  width: 28px; height: 28px; border-radius: 50%; background: rgba(255,255,255,.9);
  display: flex; align-items: center; justify-content: center; border: none;
  cursor: pointer; color: #1C1A2E; transition: all .12s;
}
.nx-img-hist-icon-btn:hover { background: #fff; transform: scale(1.1); }
.nx-img-history-prompt {
  font-size: 10px; color: var(--text-muted); margin-top: 4px;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%;
}

/* Empty state */
.nx-img-empty {
  flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 12px; padding: 48px 24px; text-align: center; color: var(--text-muted);
}
.nx-img-empty-icon { font-size: 56px; opacity: .5; }
.nx-img-empty h3 { font-size: 16px; color: var(--text); margin: 0; font-family: 'Poppins',sans-serif; }
.nx-img-empty p { font-size: 13px; max-width: 320px; line-height: 1.55; margin: 0; }

/* API note banner for image */
.nx-img-api-note {
  display: flex; align-items: flex-start; gap: 8px;
  background: var(--accent-soft); border: 1px solid var(--accent);
  color: var(--text); border-radius: var(--radius-sm); padding: 10px 14px;
  font-size: 12px; line-height: 1.5; margin-bottom: 6px;
}

/* Settings for image */
.nx-img-settings-section { padding: 16px 0 0; border-top: 1px solid var(--border); }

/* ============================== v1.7: Generator Mode Tabs (Features 71-74) ============================== */
.nx-img-mode-tabs {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px;
  padding: 4px; border-radius: var(--radius-md); background: var(--surface-2);
  border: 1px solid var(--border);
}
.nx-img-mode-tab {
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  padding: 9px 4px; border-radius: var(--radius-sm); border: none; background: transparent;
  color: var(--text-muted); font: inherit; font-size: 10.5px; font-weight: 700;
  cursor: pointer; transition: all .15s; text-align: center; line-height: 1.2;
}
.nx-img-mode-tab:hover { color: var(--brand); }
.nx-img-mode-tab.active { background: var(--surface); color: var(--brand); box-shadow: 0 2px 8px rgba(43,39,92,.1); }

/* Image-to-Image: upload dropzone (compact variant of .nx-upload-zone) */
.nx-i2i-upload-zone {
  border: 2px dashed var(--border); border-radius: var(--radius-lg); padding: 22px 14px;
  text-align: center; cursor: pointer; transition: all .15s; color: var(--text-muted);
  display: flex; flex-direction: column; align-items: center; gap: 6px;
}
.nx-i2i-upload-zone:hover, .nx-i2i-upload-zone.drag { border-color: var(--brand); background: var(--brand-soft); color: var(--brand); }
.nx-i2i-upload-zone svg { color: var(--brand); }
.nx-i2i-upload-zone h4 { margin: 2px 0 0; font-size: 13.5px; color: var(--text); font-family: 'Poppins',sans-serif; }
.nx-i2i-upload-zone p { margin: 0; font-size: 11.5px; }

.nx-i2i-preview-wrap { position: relative; border-radius: var(--radius-lg); overflow: hidden; border: 1.5px solid var(--border); }
.nx-i2i-preview-wrap img { width: 100%; max-height: 220px; object-fit: contain; display: block; background: var(--surface-2); }
.nx-i2i-preview-actions {
  position: absolute; top: 8px; right: 8px; display: flex; gap: 6px;
}
.nx-i2i-preview-btn {
  display: flex; align-items: center; gap: 4px; padding: 5px 9px; border-radius: var(--radius-sm);
  background: rgba(10,8,20,.65); color: #fff; border: none; cursor: pointer;
  font: inherit; font-size: 11px; font-weight: 600; transition: all .12s; backdrop-filter: blur(4px);
}
.nx-i2i-preview-btn:hover { background: rgba(10,8,20,.85); }

/* Strength slider */
.nx-i2i-strength-row { display: flex; align-items: center; gap: 10px; }
.nx-i2i-strength-row input[type="range"] {
  flex: 1; height: 4px; border-radius: 4px; appearance: none; -webkit-appearance: none;
  background: linear-gradient(90deg, var(--brand), var(--brand) calc(var(--pct, 50) * 1%), var(--border) calc(var(--pct, 50) * 1%), var(--border));
  outline: none; cursor: pointer;
}
.nx-i2i-strength-row input[type="range"]::-webkit-slider-thumb {
  appearance: none; -webkit-appearance: none; width: 16px; height: 16px; border-radius: 50%;
  background: var(--brand); border: 2px solid var(--surface); box-shadow: 0 1px 4px rgba(0,0,0,.25); cursor: pointer;
}
.nx-i2i-strength-row input[type="range"]::-moz-range-thumb {
  width: 16px; height: 16px; border-radius: 50%; background: var(--brand); border: 2px solid var(--surface); cursor: pointer;
}
.nx-i2i-strength-labels { display: flex; justify-content: space-between; font-size: 10.5px; color: var(--text-muted); margin-top: 4px; }

.nx-i2i-note { font-size: 11px; color: var(--text-muted); line-height: 1.5; margin: 0; }

/* Original thumbnail shown alongside Image-to-Image results */
.nx-img-source-row { display: flex; align-items: center; gap: 8px; padding: 0 20px 4px; }
.nx-img-source-thumb { width: 44px; height: 44px; border-radius: var(--radius-sm); object-fit: cover; border: 1.5px solid var(--border); flex-shrink: 0; }
.nx-img-source-label { font-size: 11px; color: var(--text-muted); }

/* ============================== v1.7: Audio-to-Image (Feature 73) ============================== */
.nx-a2i-lang-row { display: flex; gap: 6px; }
.nx-a2i-lang-btn {
  flex: 1; padding: 7px 4px; border-radius: var(--radius-sm); border: 1.5px solid var(--border);
  background: var(--surface-2); color: var(--text-muted); cursor: pointer; font: inherit;
  font-size: 11.5px; font-weight: 600; transition: all .15s;
}
.nx-a2i-lang-btn:hover { border-color: var(--brand); color: var(--brand); }
.nx-a2i-lang-btn.active { border-color: var(--brand); background: var(--brand); color: #fff; }

.nx-a2i-mic-wrap { display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 18px 10px; }
.nx-a2i-mic-btn {
  width: 64px; height: 64px; border-radius: 50%; border: none; cursor: pointer;
  background: linear-gradient(135deg, var(--brand), var(--brand-700)); color: #fff;
  display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 18px rgba(91,95,239,.35);
  transition: all .15s;
}
.nx-a2i-mic-btn:hover { transform: translateY(-1px); }
.nx-a2i-mic-btn.recording { background: linear-gradient(135deg, var(--danger), #b91c1c); animation: nx-pulse 1.4s ease-in-out infinite; }
.nx-a2i-mic-hint { font-size: 12px; color: var(--text-muted); text-align: center; }

.nx-a2i-transcript-box {
  width: 100%; min-height: 64px; border-radius: var(--radius-md); border: 1.5px solid var(--border);
  background: var(--surface-2); padding: 10px 12px; font-size: 13px; line-height: 1.5; color: var(--text);
}
.nx-a2i-transcript-empty { color: var(--text-muted); font-size: 12.5px; }
.nx-a2i-transcript-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 6px; }

/* Responsive image */
@media (max-width: 880px) {
  .nx-img-layout { flex-direction: column; }
  .nx-img-panel { width: 100%; border-right: none; border-bottom: 1px solid var(--border); max-height: 55vh; }
  .nx-img-grid.count-2, .nx-img-grid.count-4 { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 480px) {
  .nx-img-grid.count-4 { grid-template-columns: 1fr 1fr; }
  .nx-img-style-grid { grid-template-columns: repeat(3, 1fr); }
  .nx-img-history-grid { grid-template-columns: repeat(3, 1fr); }
}

/* Lightbox */
.nx-img-lightbox {
  position: fixed; inset: 0; background: rgba(10,8,20,.92); z-index: 100;
  display: flex; align-items: center; justify-content: center; padding: 20px;
  animation: nx-modal-in .15s ease;
}
.nx-img-lightbox img { max-width: 90vw; max-height: 85vh; border-radius: var(--radius-lg); box-shadow: 0 20px 60px rgba(0,0,0,.6); }
.nx-img-lightbox-close {
  position: absolute; top: 16px; right: 16px; width: 40px; height: 40px; border-radius: 50%;
  background: rgba(255,255,255,.15); border: none; color: #fff; cursor: pointer;
  display: flex; align-items: center; justify-content: center; transition: background .15s;
}
.nx-img-lightbox-close:hover { background: rgba(255,255,255,.25); }

/* ============================== v1.8: Advanced Image Generator additions (Feature 77) ============================== */
.nx-img-upscaled-badge {
  position: absolute; top: 8px; left: 8px; z-index: 2; padding: 3px 8px; border-radius: 999px;
  background: rgba(10,8,20,.7); color: #fff; font-size: 9.5px; font-weight: 700; text-transform: uppercase;
  letter-spacing: .04em; backdrop-filter: blur(4px);
}

/* ============================== v1.8: AI Image Editor (Feature 75) ============================== */
.nx-edit-toolbar-row { display: flex; gap: 8px; }
.nx-edit-tool-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
.nx-edit-tool-btn {
  display: flex; flex-direction: column; align-items: center; gap: 5px; padding: 12px 6px;
  border-radius: var(--radius-md); border: 1.5px solid var(--border); background: var(--surface-2);
  cursor: pointer; font: inherit; font-size: 11.5px; font-weight: 600; color: var(--text);
  transition: all .15s; text-align: center;
}
.nx-edit-tool-btn:hover { border-color: var(--brand); background: var(--brand-soft); color: var(--brand); }
.nx-edit-tool-btn:disabled { opacity: .5; cursor: not-allowed; }
.nx-edit-tool-icon { font-size: 22px; line-height: 1; }
.nx-edit-checkbox-row { display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: var(--text-muted); cursor: pointer; }
.nx-edit-checkbox-row input { width: 15px; height: 15px; accent-color: var(--brand); cursor: pointer; }

.nx-edit-canvas-wrap { flex: 1; display: flex; flex-direction: column; gap: 12px; padding: 20px; min-height: 0; overflow-y: auto; align-items: center; }
.nx-edit-preview-img {
  max-width: 100%; max-height: 60vh; border-radius: var(--radius-lg); border: 1.5px solid var(--border);
  background: var(--surface-2); transition: transform .2s; object-fit: contain;
}
.nx-edit-crop-stage {
  position: relative; max-width: 100%; max-height: 60vh; display: inline-flex; touch-action: none;
  border-radius: var(--radius-lg); overflow: hidden; border: 1.5px solid var(--border); background: var(--surface-2);
}
.nx-edit-crop-stage img { max-width: 100%; max-height: 60vh; display: block; pointer-events: none; user-select: none; }
.nx-edit-crop-box {
  position: absolute; border: 2px dashed #fff; box-shadow: 0 0 0 9999px rgba(10,8,20,.45);
  cursor: move; touch-action: none;
}
.nx-edit-crop-handle {
  position: absolute; width: 16px; height: 16px; background: var(--brand); border: 2px solid #fff;
  border-radius: 50%; touch-action: none; cursor: nwse-resize;
}
.nx-edit-crop-handle.nw { top: -9px; left: -9px; }
.nx-edit-crop-handle.se { bottom: -9px; right: -9px; }
.nx-edit-demo-card {
  width: 100%; max-width: 480px; background: linear-gradient(135deg, var(--brand-soft), var(--accent-soft));
  border-radius: var(--radius-lg); padding: 16px 18px; border: 1px solid var(--border);
}
.nx-edit-demo-card-title { font-size: 12px; font-weight: 700; color: var(--brand); margin-bottom: 6px; }
.nx-edit-demo-card p { margin: 0; font-size: 13px; line-height: 1.55; color: var(--text); }
.nx-edit-action-row { display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; }

/* ============================== v1.8: Text-to-Video Generator (Feature 76) ============================== */
.nx-vid-shimmer {
  width: 280px; height: 160px; border-radius: var(--radius-lg); background: var(--surface-2);
  animation: nx-shimmer 1.5s ease-in-out infinite alternate;
}
.nx-vid-player-wrap { border-radius: var(--radius-lg); overflow: hidden; border: 1.5px solid var(--border); max-width: 520px; cursor: pointer; }
.nx-vid-player-wrap video { width: 100%; display: block; background: #000; max-height: 60vh; }
.nx-vid-storyboard-card {
  max-width: 560px; background: linear-gradient(135deg, var(--brand-soft), var(--accent-soft));
  border-radius: var(--radius-lg); padding: 16px 18px; border: 1px solid var(--border);
}
.nx-vid-storyboard-head { display: flex; align-items: center; gap: 8px; font-size: 13.5px; font-weight: 700; color: var(--text); font-family: 'Poppins',sans-serif; }
.nx-vid-style-chip { margin-left: auto; font-size: 11px; font-weight: 600; color: var(--brand); background: var(--surface); padding: 3px 9px; border-radius: 999px; }
.nx-vid-storyboard-note { font-size: 11.5px; color: var(--text-muted); margin: 6px 0 10px; }
.nx-vid-storyboard-text {
  font-family: inherit; white-space: pre-wrap; font-size: 13px; line-height: 1.6; color: var(--text);
  margin: 0; background: var(--surface); border-radius: var(--radius-md); padding: 12px 14px; border: 1px solid var(--border);
}

/* ============================== v1.8: AI Media Gallery (Feature 78) ============================== */
.nx-gallery-wrap { flex: 1; min-height: 0; overflow-y: auto; display: flex; flex-direction: column; gap: 0; }
.nx-gallery-toolbar { display: flex; align-items: center; gap: 12px; padding: 16px 20px 0; flex-wrap: wrap; }
.nx-gallery-search {
  display: flex; align-items: center; gap: 8px; padding: 8px 14px; border-radius: var(--radius-md);
  border: 1.5px solid var(--border); background: var(--surface-2); color: var(--text-muted); flex: 1; min-width: 180px;
}
.nx-gallery-search input { border: none; background: none; outline: none; color: var(--text); font: inherit; font-size: 13px; flex: 1; }
.nx-gallery-filters { display: flex; gap: 6px; flex-wrap: wrap; }
.nx-gallery-toolbar-right { display: flex; align-items: center; gap: 10px; margin-left: auto; }
.nx-gallery-count { font-size: 12px; color: var(--text-muted); white-space: nowrap; }
.nx-gallery-sync-row {
  display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;
  margin: 14px 20px; padding: 12px 16px; border-radius: var(--radius-md); background: var(--surface-2); border: 1px solid var(--border);
}
.nx-gallery-sync-label { display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 700; color: var(--text); }
.nx-gallery-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 14px; padding: 4px 20px 24px; }
.nx-gallery-card { display: flex; flex-direction: column; }
.nx-gallery-type-badge {
  position: absolute; top: 8px; left: 8px; z-index: 2; display: flex; align-items: center; gap: 4px;
  padding: 3px 8px; border-radius: 999px; background: rgba(10,8,20,.65); color: #fff; font-size: 9.5px;
  font-weight: 700; text-transform: uppercase; letter-spacing: .03em; backdrop-filter: blur(4px);
}
.nx-gallery-video-thumb { position: relative; width: 100%; aspect-ratio: 1; background: #000; display: flex; align-items: center; justify-content: center; }
.nx-gallery-video-thumb video { width: 100%; height: 100%; object-fit: cover; }
.nx-gallery-play-icon { position: absolute; color: #fff; filter: drop-shadow(0 2px 6px rgba(0,0,0,.6)); pointer-events: none; }
.nx-gallery-card-prompt {
  font-size: 11px; color: var(--text-muted); margin-top: 6px; line-height: 1.4;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}

@media (max-width: 640px) {
  .nx-gallery-toolbar { flex-direction: column; align-items: stretch; }
  .nx-gallery-toolbar-right { margin-left: 0; justify-content: space-between; }
  .nx-gallery-grid { grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 10px; padding: 4px 14px 20px; }
  .nx-edit-tool-grid { grid-template-columns: repeat(2, 1fr); }
}

/* ---- Subscription Plans ---- */
.nx-plans-grid { display: grid; grid-template-columns: 1fr; gap: 14px; margin-top: 8px; }
.nx-plan-card { border: 2px solid var(--border); border-radius: 16px; padding: 18px; position: relative; transition: all .2s; }
.nx-plan-card.popular { border-color: #7c3aed; box-shadow: 0 0 0 3px rgba(124,58,237,.15); }
.nx-plan-card.current { background: rgba(124,58,237,.07); }
.nx-plan-badge { display: inline-block; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 20px; color: #fff; margin-bottom: 8px; }
.nx-plan-popular-tag { position: absolute; top: -10px; right: 14px; background: #7c3aed; color: #fff; font-size: 10px; font-weight: 700; padding: 2px 10px; border-radius: 20px; }
.nx-plan-name { font-size: 18px; font-weight: 700; margin: 0 0 2px; }
.nx-plan-price { font-size: 26px; font-weight: 800; margin: 6px 0 2px; }
.nx-plan-price span { font-size: 13px; font-weight: 400; color: var(--text-muted); }
.nx-plan-features { list-style: none; padding: 0; margin: 10px 0 14px; }
.nx-plan-features li { font-size: 13px; padding: 3px 0; color: var(--text-muted); }
.nx-plan-features li::before { content: "✓ "; color: #22c55e; font-weight: 700; }
.nx-plan-btn { width: 100%; padding: 10px; border-radius: 10px; font-weight: 600; font-size: 14px; border: none; cursor: pointer; transition: all .2s; }
.nx-plan-btn.active { background: var(--border); color: var(--text-muted); cursor: default; }
.nx-plan-btn.upgrade { color: #fff; }
.nx-usage-bar-wrap { margin: 14px 0 4px; }
.nx-usage-label { display: flex; justify-content: space-between; font-size: 12px; color: var(--text-muted); margin-bottom: 4px; }
.nx-usage-bar { height: 6px; border-radius: 10px; background: var(--border); overflow: hidden; }
.nx-usage-fill { height: 100%; border-radius: 10px; transition: width .4s; }
.nx-limit-badge { display: inline-flex; align-items: center; gap: 4px; background: rgba(239,68,68,.12); color: #ef4444; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 20px; }

`;


/* ============================== APP ============================== */
export default function NovexaAI() {
  const [hydrated, setHydrated] = useState(false);
  const [theme, setTheme] = useState("light");
  const [lang, setLang] = useState("en");

  const [users, setUsers] = useState([]);
  const [sessionUserId, setSessionUserId] = useState(null);

  const [provider, setProvider] = useState("groq");
  const [groqKey, setGroqKey] = useState("");
  const [openrouterKey, setOpenrouterKey] = useState("");
  const [groqModel, setGroqModel] = useState(GROQ_MODELS[0]);
  const [openrouterModel, setOpenrouterModel] = useState(OR_MODELS[0]);

  /* Feature 24: voice preferences */
  const [voiceGender, setVoiceGender] = useState("female");
  const [voiceLangPref, setVoiceLangPref] = useState("en");

  const [chats, setChats] = useState([]);
  const [currentChatId, setCurrentChatId] = useState(null);

  /* Features 31-40: Study AI */
  const [view, setView] = useState("chat"); // "chat"|"study"|"coding"|"writing"|"intel"|"filechat"|"voicecall"|"imagegen"|"imageeditor"|"video"|"gallery"
  const [documents, setDocuments] = useState([]);

  /* v1.4: Web Intelligence + File Chat */
  const [searchApiKey, setSearchApiKey] = useState("");
  const [chatDocs, setChatDocs] = useState([]);
  const [activeDocId, setActiveDocId] = useState(null);

  /* v1.6: Image Generation state */
  const [imageApiKey, setImageApiKey] = useState("");
  const [imageModel, setImageModel] = useState(HF_MODELS[0]);
  const [imageHistory, setImageHistory] = useState([]); // [{id, prompt, style, size, images:[{url,isDemo,desc}], ts, mode}]

  /* v1.8: Text-to-Video state (Feature 76) */
  const [videoModel, setVideoModel] = useState(HF_VIDEO_MODELS[0]);
  const [videoHistory, setVideoHistory] = useState([]); // [{id, prompt, style, size, duration, video:{url,isDemo,desc}, ts}]

  /* v1.8: AI Media Gallery — optional cloud sync (Feature 78) */
  const [galleryCloudSync, setGalleryCloudSync] = useState(false);

  const [authTab, setAuthTab] = useState("signin");
  const [authError, setAuthError] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [modal, setModal] = useState(null);
  const [userPlan, setUserPlan] = useState("free"); // "free" | "pro" | "premium"
  const [usageToday, setUsageToday] = useState({ messages: 0, images: 0, files: 0 });
  const [editingChatId, setEditingChatId] = useState(null);
  const [editingValue, setEditingValue] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  const [draftMsg, setDraftMsg] = useState("");
  const [sending, setSending] = useState(false);
  const [chatError, setChatError] = useState("");

  /* v1.9 Features 78-81: chat attachments (images + files) */
  const [chatAttachments, setChatAttachments] = useState([]);
  const [attachBusy, setAttachBusy] = useState(false);
  const [composerDragOver, setComposerDragOver] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const chatImageInputRef = useRef(null);
  const chatFileInputRef = useRef(null);

  /* Feature 21/22: voice chat */
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef(null);

  /* Feature 23: TTS */
  const [speakingId, setSpeakingId] = useState(null);

  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);
  const t = STR[lang];

  /* ----- load persisted state ----- */
  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("app-data");
        if (res && res.value) {
          const d = JSON.parse(res.value);
          if (d.theme) setTheme(d.theme);
          if (d.lang) setLang(d.lang);
          if (Array.isArray(d.users)) setUsers(d.users);
          if (d.sessionUserId) setSessionUserId(d.sessionUserId);
          if (d.provider) setProvider(d.provider);
          if (d.groqKey) setGroqKey(d.groqKey);
          if (d.openrouterKey) setOpenrouterKey(d.openrouterKey);
          if (d.groqModel) setGroqModel(d.groqModel);
          if (d.openrouterModel) setOpenrouterModel(d.openrouterModel);
          if (Array.isArray(d.chats)) setChats(d.chats);
          if (d.currentChatId) setCurrentChatId(d.currentChatId);
          if (Array.isArray(d.documents)) setDocuments(d.documents);
          if (d.activeDocId) setActiveDocId(d.activeDocId);
          if (d.voiceGender) setVoiceGender(d.voiceGender);
          if (d.voiceLangPref) setVoiceLangPref(d.voiceLangPref);
          if (d.searchApiKey) setSearchApiKey(d.searchApiKey);
          if (d.imageApiKey) setImageApiKey(d.imageApiKey);
          if (d.imageModel) setImageModel(d.imageModel);
          if (Array.isArray(d.imageHistory)) setImageHistory(d.imageHistory);
          if (d.videoModel) setVideoModel(d.videoModel);
          if (Array.isArray(d.videoHistory)) setVideoHistory(d.videoHistory);
          if (typeof d.galleryCloudSync === "boolean") setGalleryCloudSync(d.galleryCloudSync);
        }
      } catch (e) { /* first run */ }
      setHydrated(true);
    })();
  }, []);

  /* ----- persist on change ----- */
  useEffect(() => {
    if (!hydrated) return;
    const payload = JSON.stringify({
      theme, lang, users, sessionUserId, provider, groqKey, openrouterKey,
      groqModel, openrouterModel, chats, currentChatId, voiceGender, voiceLangPref,
      documents: documents.map((d) => ({ ...d, base64: undefined })), activeDocId,
      searchApiKey, imageApiKey, imageModel, videoModel, galleryCloudSync,
      // v1.8 Feature 78: real (non-demo) media only survives reload if Cloud Sync captured
      // a small enough base64 copy at generation time; otherwise the entry falls back to a
      // placeholder rather than a dead blob: URL.
      imageHistory: sanitizeHistoryForStorage(imageHistory, "images"),
      videoHistory: sanitizeHistoryForStorage(videoHistory, "video"),
    });
    window.storage.set("app-data", payload).catch(() => {});
  }, [hydrated, theme, lang, users, sessionUserId, provider, groqKey, openrouterKey,
    groqModel, openrouterModel, chats, currentChatId, voiceGender, voiceLangPref,
    documents, activeDocId, searchApiKey, imageApiKey, imageModel, imageHistory,
    videoModel, videoHistory, galleryCloudSync]);

  /* Feature 29: auto scroll */
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chats, currentChatId, sending]);

  const currentUser = users.find((u) => u.id === sessionUserId) || null;
  const currentChat = chats.find((c) => c.id === currentChatId) || null;
  const activeKey = provider === "groq" ? groqKey : openrouterKey;
  const activeModel = provider === "groq" ? groqModel : openrouterModel;

  /* ====================== Feature 21/22: Voice Chat / STT ====================== */
  const startListening = useCallback(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setChatError("Speech recognition not supported in this browser.");
      return;
    }
    if (isListening) {
      recognitionRef.current?.stop();
      return;
    }
    const recognition = new SR();
    recognitionRef.current = recognition;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = voiceLangPref === "hi" ? "hi-IN" : "en-US";

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      setDraftMsg((prev) => (prev ? prev + " " + transcript : transcript));
      setIsListening(false);
    };
    recognition.start();
  }, [isListening, voiceLangPref]);

  /* ====================== Feature 23/24: Text-to-Speech ====================== */
  const speakMessage = useCallback((msg) => {
    if (!window.speechSynthesis) return;
    if (speakingId === msg.id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(msg.content);

    // Feature 24: pick voice based on preferences
    const voices = window.speechSynthesis.getVoices();
    const langCode = voiceLangPref === "hi" ? "hi" : "en";
    const genderKeywords = voiceGender === "female"
      ? ["female", "zira", "samantha", "victoria", "susan", "karen", "moira", "veena", "woman"]
      : ["male", "david", "mark", "daniel", "alex", "jorge", "man"];

    let chosen = null;
    // Try to match both lang and gender
    for (const v of voices) {
      if (v.lang.startsWith(langCode) && genderKeywords.some(k => v.name.toLowerCase().includes(k))) {
        chosen = v; break;
      }
    }
    // Fallback: just match lang
    if (!chosen) {
      chosen = voices.find(v => v.lang.startsWith(langCode)) || null;
    }
    if (chosen) utterance.voice = chosen;
    utterance.lang = voiceLangPref === "hi" ? "hi-IN" : "en-US";
    utterance.rate = 0.95;
    utterance.pitch = voiceGender === "female" ? 1.1 : 0.9;

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    setSpeakingId(msg.id);
    window.speechSynthesis.speak(utterance);
  }, [speakingId, voiceGender, voiceLangPref]);

  /* ====================== Feature 25: Export Chat ====================== */
  const exportChat = useCallback(() => {
    if (!currentChat) return;
    const lines = [`Novexa AI — ${currentChat.title}`, `Exported: ${new Date().toLocaleString()}`, "=".repeat(50), ""];
    currentChat.messages.forEach((m) => {
      lines.push(`[${m.role === "user" ? "You" : "Novexa"}]`);
      lines.push(m.content);
      lines.push("");
    });
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `novexa-${currentChat.title.slice(0, 30).replace(/\s+/g, "-")}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }, [currentChat]);

  /* ====================== Feature 26: Share Chat ====================== */
  const shareChat = useCallback(async () => {
    if (!currentChat) return;
    const text = currentChat.messages
      .map((m) => `${m.role === "user" ? "You" : "Novexa"}: ${m.content}`)
      .join("\n\n");
    try {
      if (navigator.share) {
        await navigator.share({ title: currentChat.title, text });
      } else {
        await navigator.clipboard.writeText(text);
        setChatError(t.shareNotSupported);
        setTimeout(() => setChatError(""), 2200);
      }
    } catch (e) {
      // user cancelled share
    }
  }, [currentChat, t]);

  /* ====================== v1.4: Export Chat as PDF ====================== */
  const exportChatPDF = useCallback(() => {
    if (!currentChat) return;
    const w = window.open("", "_blank");
    if (!w) return;
    const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const body = currentChat.messages.map((m) => `
      <div style="margin:0 0 16px;">
        <div style="font-weight:700;font-size:12px;color:${m.role === "user" ? "#6d4dfb" : "#16a085"};margin-bottom:4px;">
          ${m.role === "user" ? "You" : "Novexa AI"}
        </div>
        <div style="white-space:pre-wrap;font-size:14px;line-height:1.55;">${esc(m.content)}</div>
      </div>`).join("");
    w.document.write(`<html><head><title>${esc(currentChat.title)}</title></head><body>
      <div style="font-family:Inter,Arial,sans-serif;max-width:720px;margin:32px auto;padding:0 16px;">
        <h2 style="margin:0 0 2px;">${esc(currentChat.title)}</h2>
        <div style="color:#888;font-size:12px;margin-bottom:18px;">Exported from Novexa AI — ${esc(new Date().toLocaleString())}</div>
        ${body}
      </div></body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 250);
  }, [currentChat]);


  function resetAuthForm() { setAuthForm({ name: "", email: "", password: "" }); setAuthError(""); }

  function handleSignup() {
    const { name, email, password } = authForm;
    if (!name.trim() || !email.trim() || !password) { setAuthError(t.fillFields); return; }
    if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) { setAuthError(t.emailTaken); return; }
    setAuthBusy(true);
    const newUser = { id: uid(), name: name.trim(), email: email.trim(), password, provider: "local" };
    setUsers((prev) => [...prev, newUser]);
    setSessionUserId(newUser.id);
    setAuthBusy(false);
    resetAuthForm();
  }

  function handleSignin() {
    const { email, password } = authForm;
    if (!email.trim() || !password) { setAuthError(t.fillFields); return; }
    const match = users.find((u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (!match) { setAuthError(t.invalidLogin); return; }
    setSessionUserId(match.id);
    resetAuthForm();
  }

  async function handleGoogleLogin() {
    try {
      const result = await signInWithPopup(firebaseAuth, googleProvider);
      const user = result.user;
      let g = users.find((u) => u.email === user.email);
      if (!g) {
        g = { id: user.uid, name: user.displayName || "Google User", email: user.email, provider: "google", photo: user.photoURL };
        setUsers((prev) => [...prev, g]);
      }
      setSessionUserId(g.id);
      resetAuthForm();
    } catch (err) {
      setAuthError("Google sign-in failed. Please try again.");
    }
  }

  function handleLogout() {
    setSessionUserId(null);
    setModal(null);
    setSidebarOpen(false);
    window.speechSynthesis?.cancel();
    recognitionRef.current?.stop();
  }

  /* ------------------------------ CHATS -------------------------------- */
  function createNewChat() {
    const chat = { id: uid(), title: t.newChat, messages: [], createdAt: Date.now() };
    setChats((prev) => [chat, ...prev]);
    setCurrentChatId(chat.id);
    setChatError("");
    setSidebarOpen(false);
  }

  function selectChat(id) {
    setCurrentChatId(id);
    setChatError("");
    setEditingChatId(null);
    setConfirmDeleteId(null);
    setSidebarOpen(false);
    window.speechSynthesis?.cancel();
    setSpeakingId(null);
  }

  function startRename(chat) { setEditingChatId(chat.id); setEditingValue(chat.title); }
  function commitRename() {
    setChats((prev) => prev.map((c) => (c.id === editingChatId ? { ...c, title: editingValue.trim() || c.title } : c)));
    setEditingChatId(null);
  }
  function deleteChat(id) {
    setChats((prev) => prev.filter((c) => c.id !== id));
    if (currentChatId === id) setCurrentChatId(null);
    setConfirmDeleteId(null);
  }

  function updateChatMessages(chatId, updater) {
    setChats((prev) => prev.map((c) => (c.id === chatId ? { ...c, messages: updater(c.messages) } : c)));
  }

  async function sendMessage(overrideText) {
    const text = (overrideText || draftMsg).trim();
    const attachments = chatAttachments;
    if ((!text && !attachments.length) || sending) return;

    let chat = currentChat;
    if (!chat) {
      chat = { id: uid(), title: t.newChat, messages: [], createdAt: Date.now() };
      setChats((prev) => [chat, ...prev]);
      setCurrentChatId(chat.id);
    }
    const chatId = chat.id;
    const userMsg = {
      id: uid(), role: "user", content: text, ts: Date.now(),
      attachments: attachments.map((a) => ({ id: a.id, kind: a.kind, name: a.name, previewUrl: a.previewUrl })),
    };
    const newMessages = [...chat.messages, userMsg];
    updateChatMessages(chatId, () => newMessages);
    if (chat.title === t.newChat || chat.title === STR.en.newChat || chat.title === STR.hi.newChat) {
      const shortTitle = (text || (attachments[0] && attachments[0].name) || t.newChat);
      setChats((prev) => prev.map((c) => (c.id === chatId ? { ...c, title: shortTitle.length > 42 ? shortTitle.slice(0, 42) + "…" : shortTitle } : c)));
    }
    setDraftMsg("");
    setChatAttachments([]);
    setChatError("");
    setSending(true);

    const sys = {
      role: "system",
      content: "You are Novexa AI, a friendly, helpful assistant fluent in both Hindi and English. Match the language the user writes in; if they mix Hindi and English (Hinglish), reply naturally in the same mixed style. Keep answers clear, concise and well structured. When the user attaches images or files, look at them carefully and answer using their actual content.",
    };
    const apiMessages = [sys, ...newMessages.slice(-16, -1).map((m) => ({ role: m.role, content: m.content }))];

    try {
      let reply;
      if (attachments.length) {
        // v2.0: attachments now route through whichever provider is active (Groq/OpenRouter)
        // instead of always going to Claude. Images need a vision-capable model.
        reply = await callMultimodal(apiMessages, text, attachments);
      } else {
        reply = provider === "groq"
          ? await callGroq([...apiMessages, { role: "user", content: text }], groqKey, groqModel)
          : await callOpenRouter([...apiMessages, { role: "user", content: text }], openrouterKey, openrouterModel);
      }
      const aiMsg = { id: uid(), role: "assistant", content: reply || "…", ts: Date.now() };
      updateChatMessages(chatId, (msgs) => [...msgs, aiMsg]);
    } catch (err) {
      setChatError(err.message || t.networkErr);
    } finally {
      setSending(false);
    }
  }

  /* Feature 28: suggestion click sends directly */
  function handleSuggestion(text) {
    sendMessage(text);
  }

  /* If the user has saved their own key in Settings, call Groq/OpenRouter directly from
     the browser (fast, zero backend dependency). If no key is set, fall back to our own
     serverless proxy (/api/groq, /api/openrouter) which holds a server-side key in an
     env var — this keeps the key out of the browser entirely. See /api/README.md. */
  async function callGroq(messages, key, model) {
    const useProxy = !key;
    const url = useProxy ? "/api/groq" : "https://api.groq.com/openai/v1/chat/completions";
    const headers = { "Content-Type": "application/json" };
    if (!useProxy) headers.Authorization = `Bearer ${key}`;
    let res;
    try {
      res = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: 1024 }),
      });
    } catch { throw new Error(STR[lang].networkErr); }
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body?.error?.message || `Groq error (${res.status})`);
    }
    const data = await res.json();
    return data?.choices?.[0]?.message?.content ?? "";
  }

  async function callOpenRouter(messages, key, model) {
    const useProxy = !key;
    const url = useProxy ? "/api/openrouter" : "https://openrouter.ai/api/v1/chat/completions";
    const headers = { "Content-Type": "application/json" };
    if (!useProxy) {
      headers.Authorization = `Bearer ${key}`;
      headers["HTTP-Referer"] = "https://novexa.ai";
      headers["X-Title"] = "Novexa AI";
    }
    let res;
    try {
      res = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: 1024 }),
      });
    } catch { throw new Error(STR[lang].networkErr); }
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body?.error?.message || `OpenRouter error (${res.status})`);
    }
    const data = await res.json();
    return data?.choices?.[0]?.message?.content ?? "";
  }

  /* Generic dispatcher reused by Study AI features (Features 31-40) */
  async function callAI(messages) {
    if (provider === "groq") return callGroq(messages, groqKey, groqModel);
    return callOpenRouter(messages, openrouterKey, openrouterModel);
  }

  /* Runs an instruction against a document. PDFs are now pre-extracted to plain text at
     upload time (see extractPdfText), so every doc kind goes through the same text path —
     no Claude document API needed. */
  async function runDocAI(doc, instruction) {
    const sys = "You are Novexa Study AI, an assistant that helps students understand documents. Answer using the document content only. Be clear and well structured.";
    const messages = [
      { role: "system", content: sys + `\n\nDocument "${doc.name}" content:\n${(doc.textContent || "").slice(0, 12000)}` },
      { role: "user", content: instruction },
    ];
    return callAI(messages);
  }

  /* Builds an OpenAI-style content array (the format Groq/OpenRouter both expect) for a
     vision request — image as a base64 data URL alongside the text prompt. */
  function buildVisionContent(promptText, base64, mediaType) {
    return [
      { type: "text", text: promptText },
      { type: "image_url", image_url: { url: `data:${mediaType};base64,${base64}` } },
    ];
  }

  /* v2.0: vision call used by the Image-to-Image demo path (no HF key set) — sends the
     uploaded image to the active provider so the AI-description fallback can reference
     what's actually in the picture. Only works on a vision-capable model (OpenRouter). */
  async function callImageVision(base64, mediaType, prompt) {
    if (provider === "groq") {
      throw new Error("Groq models are text-only. Switch to OpenRouter with a vision model (e.g. openai/gpt-4o-mini) in Settings to analyze images.");
    }
    if (!OR_VISION_MODELS.includes(openrouterModel)) {
      throw new Error(`"${openrouterModel}" doesn't support images. Pick a vision model like openai/gpt-4o-mini in Settings.`);
    }
    return callOpenRouter([{ role: "user", content: buildVisionContent(prompt, base64, mediaType) }], openrouterKey, openrouterModel);
  }

  /* v2.0 (was Feature 81): send text + image attachments together through the active
     provider. PDFs/Word/Excel attachments arrive as already-extracted text (see
     extractPdfText / handleChatFilesAdded) and are simply appended to the prompt; only
     images need the vision content-block format, and only on a vision-capable model. */
  async function callMultimodal(priorTextMessages, promptText, attachments) {
    const images = attachments.filter((a) => a.kind === "image");
    const textAttachments = attachments.filter((a) => a.kind !== "image");

    let appendedText = promptText || "";
    for (const a of textAttachments) {
      appendedText += `\n\n[Attached file: ${a.name}]\n${(a.textContent || "").slice(0, 12000)}`;
    }
    if (!appendedText.trim()) appendedText = "Please look at the attached file(s).";

    if (images.length) {
      if (provider === "groq") {
        throw new Error("Groq models are text-only. Switch to OpenRouter with a vision model (e.g. openai/gpt-4o-mini) in Settings to send images.");
      }
      if (!OR_VISION_MODELS.includes(openrouterModel)) {
        throw new Error(`"${openrouterModel}" doesn't support images. Pick a vision model like openai/gpt-4o-mini in Settings.`);
      }
      const content = [{ type: "text", text: appendedText }];
      for (const img of images) {
        content.push({ type: "image_url", image_url: { url: `data:${img.mediaType};base64,${img.base64}` } });
      }
      const convo = [...priorTextMessages, { role: "user", content }];
      return callOpenRouter(convo, openrouterKey, openrouterModel);
    }

    // No images — plain text path, works on either provider.
    return callAI([...priorTextMessages, { role: "user", content: appendedText }]);
  }

  function copyMessage(msg) {
    navigator.clipboard?.writeText(msg.content).then(() => {
      setCopiedId(msg.id);
      setTimeout(() => setCopiedId(null), 1500);
    }).catch(() => {});
  }

  /* Features 31/33/34: file upload + parsing for Study AI */
  const [uploadBusy, setUploadBusy] = useState(false);
  const [uploadError, setUploadError] = useState("");

  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result.split(",")[1]);
      r.onerror = () => reject(new Error("Read failed"));
      r.readAsDataURL(file);
    });
  }

  async function handleFilesAdded(fileList) {
    const t2 = STR[lang];
    const files = Array.from(fileList || []);
    for (const file of files) {
      if (file.size > 15 * 1024 * 1024) { setUploadError(t2.fileTooLarge); continue; }
      const ext = file.name.split(".").pop().toLowerCase();
      let kind = null;
      if (ext === "pdf") kind = "pdf";
      else if (ext === "doc" || ext === "docx") kind = "docx";
      else if (ext === "xls" || ext === "xlsx") kind = "xlsx";
      if (!kind) { setUploadError(t2.unsupportedFile); continue; }

      setUploadBusy(true);
      setUploadError("");
      try {
        const doc = {
          id: uid(), name: file.name, size: file.size, kind, uploadedAt: Date.now(),
          textContent: "", sheets: null, base64: null,
        };
        if (kind === "pdf") {
          doc.textContent = await extractPdfText(file);
        } else if (kind === "docx") {
          const arrayBuffer = await file.arrayBuffer();
          const result = await mammoth.extractRawText({ arrayBuffer });
          doc.textContent = result.value || "";
        } else if (kind === "xlsx") {
          const arrayBuffer = await file.arrayBuffer();
          const wb = XLSX.read(arrayBuffer, { type: "array" });
          const sheets = wb.SheetNames.map((name) => {
            const ws = wb.Sheets[name];
            return { name, rows: XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" }) };
          });
          doc.sheets = sheets;
          doc.textContent = sheets.map((s) => `Sheet: ${s.name}\n` + s.rows.map((r) => r.join(", ")).join("\n")).join("\n\n");
        }
        setDocuments((prev) => [doc, ...prev]);
        setActiveDocId(doc.id);
      } catch (e) {
        setUploadError(e.message || t2.unsupportedFile);
      } finally {
        setUploadBusy(false);
      }
    }
  }

  function removeDocument(id) {
    setDocuments((prev) => prev.filter((d) => d.id !== id));
    if (activeDocId === id) setActiveDocId(null);
  }

  /* ====================== v1.9 Features 78-81: AI Chat Upload ====================== */
  function dataUrlToBase64(dataUrl) { return dataUrl.split(",")[1]; }

  async function readFileAsText(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result || "");
      r.onerror = () => reject(new Error("Read failed"));
      r.readAsText(file);
    });
  }

  /* Feature 78/79: process images and documents dropped/picked/captured in chat */
  async function handleChatFilesAdded(fileList) {
    const t2 = STR[lang];
    const files = Array.from(fileList || []);
    if (!files.length) return;
    setAttachBusy(true);
    setChatError("");
    for (const file of files) {
      if (file.size > 15 * 1024 * 1024) { setChatError(t2.attachmentTooLarge); continue; }
      const ext = file.name.split(".").pop().toLowerCase();
      const isImage = file.type.startsWith("image/") || ["jpg", "jpeg", "png", "webp"].includes(ext);
      try {
        if (isImage) {
          const dataUrl = await new Promise((resolve, reject) => {
            const r = new FileReader();
            r.onload = () => resolve(r.result);
            r.onerror = () => reject(new Error("Read failed"));
            r.readAsDataURL(file);
          });
          const mediaType = file.type || (ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg");
          setChatAttachments((prev) => [...prev, {
            id: uid(), kind: "image", name: file.name, mediaType,
            base64: dataUrlToBase64(dataUrl), previewUrl: dataUrl,
          }]);
        } else if (ext === "pdf") {
          const textContent = await extractPdfText(file);
          setChatAttachments((prev) => [...prev, { id: uid(), kind: "doc", name: file.name, textContent }]);
        } else if (ext === "doc" || ext === "docx") {
          const arrayBuffer = await file.arrayBuffer();
          const result = await mammoth.extractRawText({ arrayBuffer });
          setChatAttachments((prev) => [...prev, { id: uid(), kind: "doc", name: file.name, textContent: result.value || "" }]);
        } else if (ext === "xls" || ext === "xlsx") {
          const arrayBuffer = await file.arrayBuffer();
          const wb = XLSX.read(arrayBuffer, { type: "array" });
          const sheets = wb.SheetNames.map((name) => {
            const ws = wb.Sheets[name];
            return { name, rows: XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" }) };
          });
          const textContent = sheets.map((s) => `Sheet: ${s.name}\n` + s.rows.map((r) => r.join(", ")).join("\n")).join("\n\n");
          setChatAttachments((prev) => [...prev, { id: uid(), kind: "doc", name: file.name, textContent }]);
        } else if (ext === "txt") {
          const textContent = await readFileAsText(file);
          setChatAttachments((prev) => [...prev, { id: uid(), kind: "doc", name: file.name, textContent }]);
        } else {
          setChatError(t2.unsupportedAttachment);
        }
      } catch (e) {
        setChatError(e.message || t2.unsupportedAttachment);
      }
    }
    setAttachBusy(false);
  }

  function removeChatAttachment(id) {
    setChatAttachments((prev) => prev.filter((a) => a.id !== id));
  }

  function handleComposerDrop(e) {
    e.preventDefault();
    setComposerDragOver(false);
    handleChatFilesAdded(e.dataTransfer.files);
  }

  /* Feature 80: capture a photo from the device camera */
  function handleCameraCapture(dataUrl) {
    setChatAttachments((prev) => [...prev, {
      id: uid(), kind: "image", name: `camera-${Date.now()}.jpg`, mediaType: "image/jpeg",
      base64: dataUrlToBase64(dataUrl), previewUrl: dataUrl,
    }]);
    setCameraOpen(false);
  }

  function handleComposerKey(e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  /* -------------------------------- RENDER -------------------------------- */
  if (!hydrated) {
    return (
      <div className={`nx-root${theme === "dark" ? " dark" : ""}`} style={{ alignItems: "center", justifyContent: "center" }}>
        <style>{CSS}</style>
        <NovexaMark size={42} busy />
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className={`nx-root${theme === "dark" ? " dark" : ""}`}>
        <style>{CSS}</style>
        <div className="nx-auth-wrap">
          <button className="nx-btn-icon nx-lang-toggle-corner" onClick={() => setLang(lang === "en" ? "hi" : "en")} title="Language">
            <Globe size={18} />
          </button>
          <div className="nx-auth-card">
            <div className="nx-auth-brand">
              <NovexaMark size={36} />
              <span className="nx-display nx-brandname" style={{ fontSize: 22 }}>Novexa AI</span>
            </div>
            <p className="nx-auth-tagline">{t.tagline}</p>

            <div className="nx-tabs">
              <div className={`nx-tab${authTab === "signin" ? " active" : ""}`} onClick={() => { setAuthTab("signin"); resetAuthForm(); }}>{t.signIn}</div>
              <div className={`nx-tab${authTab === "signup" ? " active" : ""}`} onClick={() => { setAuthTab("signup"); resetAuthForm(); }}>{t.createAccount}</div>
            </div>

            {authTab === "signup" && (
              <div className="nx-field">
                <label>{t.name}</label>
                <input className="nx-input" value={authForm.name} onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })} />
              </div>
            )}
            <div className="nx-field">
              <label>{t.email}</label>
              <input className="nx-input" type="email" value={authForm.email} onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })} />
            </div>
            <div className="nx-field">
              <label>{t.password}</label>
              <div className="nx-input-row">
                <input className="nx-input" type={showPw ? "text" : "password"} value={authForm.password} onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })} />
                <button type="button" onClick={() => setShowPw((s) => !s)}>{showPw ? <EyeOff size={16} /> : <Eye size={16} />}</button>
              </div>
            </div>

            {authError && (
              <div className="nx-banner"><AlertCircle size={15} style={{ flexShrink: 0, marginTop: 1 }} /><span>{authError}</span></div>
            )}

            <button className="nx-btn nx-btn-primary" style={{ width: "100%", justifyContent: "center", marginTop: 8 }}
              disabled={authBusy} onClick={authTab === "signin" ? handleSignin : handleSignup}>
              {authTab === "signin" ? t.signIn : t.createAccount}
            </button>

            <div className="nx-divider">{t.or}</div>
            <button className="nx-btn nx-btn-ghost nx-google-btn" onClick={handleGoogleLogin}>
              <span className="nx-google-badge">G</span> {t.continueGoogle}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`nx-root${theme === "dark" ? " dark" : ""}`}>
      <style>{CSS}</style>
      <div className="nx-app">
        <div className={`nx-backdrop${sidebarOpen ? " show" : ""}`} onClick={() => setSidebarOpen(false)} />

        {/* ===================== SIDEBAR ===================== */}
        <aside className={`nx-sidebar${sidebarOpen ? " open" : ""}`}>
          <div className="nx-sidebar-head">
            <NovexaMark size={26} />
            <span className="nx-display nx-brandname">Novexa AI</span>
            <button className="nx-btn-icon" style={{ marginLeft: "auto" }} onClick={() => setSidebarOpen(false)}>
              <X size={18} />
            </button>
          </div>

          <div className="nx-nav-switch">
            <button className={view === "chat" ? "active" : ""} onClick={() => setView("chat")}>
              <MessageSquare size={14} /> {t.navChat}
            </button>
            <button className={view === "study" ? "active" : ""} onClick={() => setView("study")}>
              <GraduationCap size={14} /> {t.navStudy}
            </button>
            <button className={view === "coding" ? "active" : ""} onClick={() => setView("coding")}>
              <Code2 size={14} /> {t.navCoding}
            </button>
            <button className={view === "writing" ? "active" : ""} onClick={() => setView("writing")}>
              <PenLine size={14} /> {t.navWriting}
            </button>
            <button className={view === "intel" ? "active" : ""} onClick={() => setView("intel")}>
              <Search size={14} /> {t.navIntel}
            </button>
            <button className={view === "filechat" ? "active" : ""} onClick={() => setView("filechat")}>
              <FilePlus2 size={14} /> {t.navFiles}
            </button>
            <button className={view === "voicecall" ? "active" : ""} onClick={() => setView("voicecall")} style={{background: view === "voicecall" ? "var(--brand)" : "", color: view === "voicecall" ? "#fff" : ""}}>
              <Phone size={14} /> {t.navVoiceCall}
            </button>
            <button className={view === "imagegen" ? "active" : ""} onClick={() => setView("imagegen")}
              style={{background: view === "imagegen" ? "linear-gradient(135deg,#7B2FBE,var(--brand))" : "", color: view === "imagegen" ? "#fff" : "", borderColor: view === "imagegen" ? "transparent" : ""}}>
              <Image size={14} /> {t.navImageGen}
            </button>
            <button className={view === "imageeditor" ? "active" : ""} onClick={() => setView("imageeditor")}
              style={{background: view === "imageeditor" ? "linear-gradient(135deg,#E0658A,var(--brand))" : "", color: view === "imageeditor" ? "#fff" : "", borderColor: view === "imageeditor" ? "transparent" : ""}}>
              <Crop size={14} /> {t.navImageEditor}
            </button>
            <button className={view === "video" ? "active" : ""} onClick={() => setView("video")}
              style={{background: view === "video" ? "linear-gradient(135deg,#2F8FBE,var(--brand))" : "", color: view === "video" ? "#fff" : "", borderColor: view === "video" ? "transparent" : ""}}>
              <Clapperboard size={14} /> {t.navVideoGen}
            </button>
            <button className={view === "gallery" ? "active" : ""} onClick={() => setView("gallery")}
              style={{background: view === "gallery" ? "linear-gradient(135deg,#3FAE6B,var(--brand))" : "", color: view === "gallery" ? "#fff" : "", borderColor: view === "gallery" ? "transparent" : ""}}>
              <Grid3x3 size={14} /> {t.navGallery}
            </button>
            <button className={view === "dream11" ? "active" : ""} onClick={() => setView("dream11")}
              style={{background: view === "dream11" ? "linear-gradient(135deg,#16a34a,#15803d)" : "", color: view === "dream11" ? "#fff" : "", borderColor: view === "dream11" ? "transparent" : ""}}>
              🏏 Dream11 AI
            </button>
          </div>

          <button className="nx-btn nx-btn-primary nx-newchat" onClick={createNewChat}>
            <Plus size={16} /> {t.newChat}
          </button>

          <div className="nx-chatlist">
            {chats.length === 0 && <div className="nx-empty-chats">{t.noChats}</div>}
            {chats.map((c) => (
              <div key={c.id} className={`nx-chat-item${c.id === currentChatId ? " active" : ""}`} onClick={() => selectChat(c.id)}>
                {editingChatId === c.id ? (
                  <input
                    className="nx-chat-rename-input" autoFocus value={editingValue}
                    onChange={(e) => setEditingValue(e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    onBlur={commitRename}
                    onKeyDown={(e) => { if (e.key === "Enter") commitRename(); if (e.key === "Escape") setEditingChatId(null); }}
                  />
                ) : confirmDeleteId === c.id ? (
                  <div className="nx-confirm-row" onClick={(e) => e.stopPropagation()}>
                    <span>{t.confirmDelete}</span>
                    <button className="nx-btn-icon" onClick={() => deleteChat(c.id)}><Check size={14} /></button>
                    <button className="nx-btn-icon" onClick={() => setConfirmDeleteId(null)}><X size={14} /></button>
                  </div>
                ) : (
                  <>
                    <span className="nx-chat-title">{c.title}</span>
                    <div className="nx-chat-actions">
                      <button className="nx-btn-icon" title={t.rename} onClick={(e) => { e.stopPropagation(); startRename(c); }}><Pencil size={13} /></button>
                      <button className="nx-btn-icon" title={t.del} onClick={(e) => { e.stopPropagation(); setConfirmDeleteId(c.id); }}><Trash2 size={13} /></button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>

          <div className="nx-sidebar-foot">
            {/* Plan badge */}
            <div style={{padding:"8px 14px 4px", display:"flex", alignItems:"center", justifyContent:"space-between"}}>
              <span className="nx-plan-badge" style={{background: PLANS[userPlan].color, fontSize:"11px"}}>
                {PLANS[userPlan].badge}
              </span>
              {userPlan === "free" && (
                <button onClick={() => setModal("plans")} style={{fontSize:"11px", fontWeight:600, color:"#7c3aed", background:"rgba(124,58,237,.1)", border:"none", borderRadius:"8px", padding:"3px 10px", cursor:"pointer"}}>
                  ⚡ Upgrade
                </button>
              )}
            </div>
            <div className="nx-user-row" onClick={() => setModal("profile")}>
              <div className="nx-avatar">{initials(currentUser.name)}</div>
              <div className="nx-user-meta">
                <div className="nx-user-name">{currentUser.name}</div>
                <div className="nx-user-email">{currentUser.email}</div>
              </div>
            </div>
            <div className="nx-icon-row">
              <button className="nx-btn-icon" title={t.appearance} onClick={() => setTheme(theme === "light" ? "dark" : "light")}>
                {theme === "light" ? <Moon size={17} /> : <Sun size={17} />}
              </button>
              <button className="nx-btn-icon" title={t.language} onClick={() => setLang(lang === "en" ? "hi" : "en")}>
                <Globe size={17} />
              </button>
              <button className="nx-btn-icon" title={t.settings} onClick={() => setModal("settings")}>
                <SettingsIcon size={17} />
              </button>
              <button className="nx-btn-icon" title={t.logout} onClick={handleLogout}>
                <LogOut size={17} />
              </button>
            </div>
          </div>
        </aside>

        {/* ===================== MAIN ===================== */}
        <main className="nx-main">
        {view === "study" ? (
          <StudyDashboard
            t={t} documents={documents} activeDocId={activeDocId} setActiveDocId={setActiveDocId}
            onFilesAdded={handleFilesAdded} onRemoveDoc={removeDocument}
            uploadBusy={uploadBusy} uploadError={uploadError} setUploadError={setUploadError}
            runDocAI={runDocAI} callAI={callAI} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}
          />
        ) : view === "coding" ? (
          <CodingDashboard t={t} callAI={callAI} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
        ) : view === "writing" ? (
          <WritingDashboard t={t} callAI={callAI} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
        ) : view === "intel" ? (
          <IntelDashboard t={t} callAI={callAI} searchApiKey={searchApiKey} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
        ) : view === "filechat" ? (
          <FileChatDashboard t={t} callAI={callAI} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
        ) : view === "voicecall" ? (
          <VoiceCallDashboard t={t} callAI={callAI} voiceGender={voiceGender} voiceLangPref={voiceLangPref} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
        ) : view === "imagegen" ? (
          <ImageGenDashboard
            t={t} callAI={callAI} imageApiKey={imageApiKey} imageModel={imageModel}
            imageHistory={imageHistory} setImageHistory={setImageHistory}
            sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}
            analyzeImage={callImageVision} galleryCloudSync={galleryCloudSync}
            onSendToChat={(prompt) => { setView("chat"); if (!currentChat) createNewChat(); setDraftMsg(prompt); }}
          />
        ) : view === "imageeditor" ? (
          <ImageEditorDashboard
            t={t} callAI={callAI} imageApiKey={imageApiKey} imageModel={imageModel}
            imageHistory={imageHistory} setImageHistory={setImageHistory}
            sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}
            analyzeImage={callImageVision} galleryCloudSync={galleryCloudSync}
          />
        ) : view === "video" ? (
          <VideoGenDashboard
            t={t} callAI={callAI} imageApiKey={imageApiKey} videoModel={videoModel}
            videoHistory={videoHistory} setVideoHistory={setVideoHistory}
            sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}
            galleryCloudSync={galleryCloudSync}
          />
        ) : view === "gallery" ? (
          <MediaGalleryDashboard
            t={t} imageHistory={imageHistory} setImageHistory={setImageHistory}
            videoHistory={videoHistory} setVideoHistory={setVideoHistory}
            galleryCloudSync={galleryCloudSync} setGalleryCloudSync={setGalleryCloudSync}
            sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}
          />
        ) : view === "dream11" ? (
          <Dream11Panel callAI={callAI} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} lang={lang} />
        ) : (
        <>
          {/* Topbar */}
          <div className="nx-topbar">
            <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="nx-topbar-title">{currentChat ? currentChat.title : t.emptyTitle}</div>
              <div className="nx-topbar-sub">
                {provider === "groq" ? "Groq" : provider === "openrouter" ? "OpenRouter" : "Claude (Demo)"} · {activeModel}
              </div>
            </div>
            {/* Feature 25 & 26: export + share buttons + v1.5 voice call */}
            <div className="nx-topbar-actions">
              {/* v1.5: Quick Voice Call shortcut */}
              <button className="nx-btn-icon" title={t.navVoiceCall} onClick={() => setView("voicecall")}
                style={{ color: "var(--brand)", background: "var(--brand-soft)" }}>
                <Phone size={16} />
              </button>
              {/* v1.6: Quick Image AI shortcut */}
              <button className="nx-btn-icon" title={t.navImageGen} onClick={() => setView("imagegen")}
                style={{ color: "#7B2FBE", background: "rgba(123,47,190,.1)" }}>
                <Image size={16} />
              </button>
              {/* v1.8: Quick Media Gallery shortcut */}
              <button className="nx-btn-icon" title={t.navGallery} onClick={() => setView("gallery")}
                style={{ color: "#3FAE6B", background: "rgba(63,174,107,.1)" }}>
                <Grid3x3 size={16} />
              </button>
              {currentChat && currentChat.messages.length > 0 && <>
                <button className="nx-btn-icon" title={t.exportChat} onClick={exportChat}>
                  <Download size={16} />
                </button>
                <button className="nx-btn-icon" title={t.exportPdf} onClick={exportChatPDF}>
                  <FileDown size={16} />
                </button>
                <button className="nx-btn-icon" title={t.shareChat} onClick={shareChat}>
                  <Share2 size={16} />
                </button>
              </>}
            </div>
          </div>

          {/* Messages / Empty State */}
          {!currentChat || currentChat.messages.length === 0 ? (
            <div className="nx-empty-state">
              <NovexaMark size={48} />
              <h2 className="nx-display">{t.emptyTitle}</h2>
              <p>{t.emptySubtitle}</p>
              {/* Feature 28: Prompt Suggestions */}
              <div className="nx-suggestions">
                {t.suggestions.map((s, i) => (
                  <button key={i} className="nx-suggestion-chip" onClick={() => handleSuggestion(s)}>
                    <ChevronRight size={13} />
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="nx-messages">
              {currentChat.messages.map((m) => (
                <div key={m.id} className={`nx-msg-row ${m.role === "user" ? "user" : ""}`}>
                  <div>
                    {m.attachments && m.attachments.length > 0 && (
                      <div className="nx-msg-attachments">
                        {m.attachments.map((a) => a.kind === "image" ? (
                          <img key={a.id} src={a.previewUrl} alt={a.name} className="nx-msg-attach-img" />
                        ) : (
                          <div key={a.id} className="nx-msg-attach-file">
                            <FileText size={14} />
                            <span>{a.name}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    {m.content && <div className={`nx-msg-bubble ${m.role === "user" ? "user" : "ai"}`}>{m.content}</div>}
                    {/* Feature 23: TTS button on AI messages */}
                    {m.role === "assistant" && (
                      <div className="nx-msg-actions">
                        <button className="nx-msg-copy" onClick={() => copyMessage(m)}>
                          {copiedId === m.id ? <><Check size={12} /> {t.copied}</> : <><Copy size={12} /> {t.copy}</>}
                        </button>
                        <button className="nx-msg-copy" onClick={() => speakMessage(m)} title={speakingId === m.id ? "Stop" : "Read aloud"}>
                          {speakingId === m.id ? <VolumeX size={12} /> : <Volume2 size={12} />}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {/* Feature 27: Typing animation */}
              {sending && (
                <div className="nx-loading-row">
                  <div className="nx-loading-bubble">
                    <TypingDots />
                  </div>
                </div>
              )}
              {/* Feature 29: scroll anchor */}
              <div ref={messagesEndRef} />
            </div>
          )}

          {chatError && (
            <div className="nx-banner">
              <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>{chatError}</span>
            </div>
          )}

          {/* Composer */}
          <div className="nx-composer-wrap">
            {!activeKey && (
              <div className="nx-key-hint">
                <span>{t.needKey(provider === "groq" ? "Groq" : "OpenRouter")}</span>
                <button className="nx-chip" onClick={() => setModal("settings")}>{t.openSettings}</button>
              </div>
            )}
            {/* Feature 22: Recording indicator */}
            {isListening && (
              <div className="nx-voice-indicator">
                <span className="nx-recording-badge">
                  <span className="nx-recording-dot" />
                  {t.listening}
                </span>
              </div>
            )}
            {/* v1.9 Feature 78/79: attachment preview strip */}
            {chatAttachments.length > 0 && (
              <div className="nx-attach-strip">
                {chatAttachments.map((a) => (
                  <div key={a.id} className="nx-attach-chip">
                    {a.kind === "image" ? (
                      <img src={a.previewUrl} alt={a.name} />
                    ) : (
                      <div className="nx-attach-chip-file"><FileText size={16} /></div>
                    )}
                    <span className="nx-attach-chip-name">{a.name}</span>
                    <button onClick={() => removeChatAttachment(a.id)} title={t.removeAttachment}><X size={12} /></button>
                  </div>
                ))}
                {attachBusy && <span className="nx-attach-busy"><Loader2 size={14} className="nx-spin" /> {t.analyzingFiles}</span>}
              </div>
            )}
            <div
              className={`nx-composer${composerDragOver ? " nx-composer-dragover" : ""}`}
              onDragOver={(e) => { e.preventDefault(); setComposerDragOver(true); }}
              onDragLeave={() => setComposerDragOver(false)}
              onDrop={handleComposerDrop}
            >
              <textarea
                ref={textareaRef} rows={1} placeholder={chatAttachments.length ? t.composerPlaceholderAttach : t.placeholder} value={draftMsg}
                onChange={(e) => setDraftMsg(e.target.value)}
                onKeyDown={handleComposerKey}
              />
              <div className="nx-composer-btns">
                {/* Feature 78: photo upload */}
                <input ref={chatImageInputRef} type="file" accept="image/jpeg,image/png,image/webp" multiple hidden
                  onChange={(e) => { handleChatFilesAdded(e.target.files); e.target.value = ""; }} />
                <button className="nx-btn-icon" title={t.attachImage} onClick={() => chatImageInputRef.current?.click()}>
                  <ImagePlus size={17} />
                </button>
                {/* Feature 79: file upload */}
                <input ref={chatFileInputRef} type="file" accept=".pdf,.doc,.docx,.txt,.xls,.xlsx" multiple hidden
                  onChange={(e) => { handleChatFilesAdded(e.target.files); e.target.value = ""; }} />
                <button className="nx-btn-icon" title={t.attachFile} onClick={() => chatFileInputRef.current?.click()}>
                  <Paperclip size={17} />
                </button>
                {/* Feature 80: camera capture */}
                <button className="nx-btn-icon" title={t.openCamera} onClick={() => setCameraOpen(true)}>
                  <Camera size={17} />
                </button>
                {/* Feature 21: Mic button */}
                <button
                  className={`nx-btn-icon${isListening ? " recording" : ""}`}
                  onClick={startListening}
                  title={isListening ? "Stop listening" : "Voice input"}
                >
                  {isListening ? <MicOff size={17} /> : <Mic size={17} />}
                </button>
                <button className="nx-send-btn" onClick={() => sendMessage()} disabled={(!draftMsg.trim() && !chatAttachments.length) || sending || attachBusy}>
                  {sending ? <Loader2 size={17} className="nx-spin" /> : <Send size={17} />}
                </button>
              </div>
            </div>
          </div>
        </>
        )}
        </main>
      </div>

      {/* v1.9 Feature 80: Camera Capture Modal */}
      {cameraOpen && (
        <CameraCaptureModal t={t} onCapture={handleCameraCapture} onClose={() => setCameraOpen(false)} />
      )}

      {/* Settings Modal */}
      {modal === "settings" && (
        <SettingsModal
          t={t} provider={provider} setProvider={setProvider}
          groqKey={groqKey} setGroqKey={setGroqKey}
          openrouterKey={openrouterKey} setOpenrouterKey={setOpenrouterKey}
          groqModel={groqModel} setGroqModel={setGroqModel}
          openrouterModel={openrouterModel} setOpenrouterModel={setOpenrouterModel}
          theme={theme} setTheme={setTheme} lang={lang} setLang={setLang}
          voiceGender={voiceGender} setVoiceGender={setVoiceGender}
          voiceLangPref={voiceLangPref} setVoiceLangPref={setVoiceLangPref}
          searchApiKey={searchApiKey} setSearchApiKey={setSearchApiKey}
          imageApiKey={imageApiKey} setImageApiKey={setImageApiKey}
          imageModel={imageModel} setImageModel={setImageModel}
          videoModel={videoModel} setVideoModel={setVideoModel}
          galleryCloudSync={galleryCloudSync} setGalleryCloudSync={setGalleryCloudSync}
          onClose={() => setModal(null)}
        />
      )}
      {modal === "profile" && (
        <ProfileModal
          t={t} user={currentUser}
          onSave={(name) => setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? { ...u, name } : u)))}
          onLogout={handleLogout}
          onClose={() => setModal(null)}
        />
      )}
      {modal === "plans" && (
        <PlansModal
          userPlan={userPlan}
          usageToday={usageToday}
          onUpgrade={(plan) => { setUserPlan(plan); setModal(null); }}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}

/* ============================ Settings Modal ============================ */
function SettingsModal({
  t, provider, setProvider, groqKey, setGroqKey, openrouterKey, setOpenrouterKey,
  groqModel, setGroqModel, openrouterModel, setOpenrouterModel,
  theme, setTheme, lang, setLang,
  voiceGender, setVoiceGender, voiceLangPref, setVoiceLangPref,
  searchApiKey, setSearchApiKey,
  imageApiKey, setImageApiKey, imageModel, setImageModel,
  videoModel, setVideoModel, galleryCloudSync, setGalleryCloudSync,
  onClose,
}) {
  const [draft, setDraft] = useState({ provider, groqKey, openrouterKey, groqModel, openrouterModel });
  const [draftVoiceGender, setDraftVoiceGender] = useState(voiceGender);
  const [draftVoiceLang, setDraftVoiceLang] = useState(voiceLangPref);
  const [draftSearchKey, setDraftSearchKey] = useState(searchApiKey || "");
  const [draftImageKey, setDraftImageKey] = useState(imageApiKey || "");
  const [draftImageModel, setDraftImageModel] = useState(imageModel || HF_MODELS[0]);
  const [draftVideoModel, setDraftVideoModel] = useState(videoModel || HF_VIDEO_MODELS[0]);
  const [draftCloudSync, setDraftCloudSync] = useState(!!galleryCloudSync);
  const [showG, setShowG] = useState(false);
  const [showO, setShowO] = useState(false);
  const [showS, setShowS] = useState(false);
  const [showI, setShowI] = useState(false);
  const [saved, setSaved] = useState(false);

  function save() {
    setProvider(draft.provider);
    setGroqKey(draft.groqKey);
    setOpenrouterKey(draft.openrouterKey);
    setGroqModel(draft.groqModel || GROQ_MODELS[0]);
    setOpenrouterModel(draft.openrouterModel || OR_MODELS[0]);
    setVoiceGender(draftVoiceGender);
    setVoiceLangPref(draftVoiceLang);
    setSearchApiKey(draftSearchKey);
    setImageApiKey(draftImageKey);
    setImageModel(draftImageModel);
    setVideoModel(draftVideoModel);
    setGalleryCloudSync(draftCloudSync);
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  }

  return (
    <div className="nx-modal-overlay" onClick={onClose}>
      <div className="nx-modal" onClick={(e) => e.stopPropagation()}>
        <div className="nx-modal-head">
          <h3 className="nx-display">{t.settings}</h3>
          <button className="nx-btn-icon" onClick={onClose}><X size={18} /></button>
        </div>

        <div className="nx-section-label">{t.activeProvider}</div>
        <div className="nx-provider-switch">
          {["groq", "openrouter"].map((p) => (
            <button key={p} className={`nx-chip${draft.provider === p ? " active" : ""}`}
              onClick={() => setDraft({ ...draft, provider: p })}>
              {p === "groq" ? "Groq" : "OpenRouter"}
            </button>
          ))}
        </div>

        <div className="nx-section-label">Groq</div>
        <div className="nx-field">
          <label>{t.apiKey}</label>
          <div className="nx-input-row">
            <input className="nx-input" type={showG ? "text" : "password"} placeholder="gsk_..."
              value={draft.groqKey} onChange={(e) => setDraft({ ...draft, groqKey: e.target.value })} />
            <button type="button" onClick={() => setShowG((s) => !s)}>{showG ? <EyeOff size={16} /> : <Eye size={16} />}</button>
          </div>
          <span className="nx-link-hint">{t.getKeyAt} <a href="https://console.groq.com/keys" target="_blank" rel="noreferrer">console.groq.com/keys</a></span>
        </div>
        <div className="nx-field">
          <label>{t.modelId}</label>
          <input className="nx-input" value={draft.groqModel} onChange={(e) => setDraft({ ...draft, groqModel: e.target.value })} />
          <div className="nx-chip-row" style={{ marginTop: 6 }}>
            {GROQ_MODELS.map((m) => (
              <button key={m} className={`nx-chip${draft.groqModel === m ? " active" : ""}`}
                onClick={() => setDraft({ ...draft, groqModel: m })}>{m}</button>
            ))}
          </div>
        </div>

        <div className="nx-section-label">OpenRouter</div>
        <div className="nx-field">
          <label>{t.apiKey}</label>
          <div className="nx-input-row">
            <input className="nx-input" type={showO ? "text" : "password"} placeholder="sk-or-..."
              value={draft.openrouterKey} onChange={(e) => setDraft({ ...draft, openrouterKey: e.target.value })} />
            <button type="button" onClick={() => setShowO((s) => !s)}>{showO ? <EyeOff size={16} /> : <Eye size={16} />}</button>
          </div>
          <span className="nx-link-hint">{t.getKeyAt} <a href="https://openrouter.ai/keys" target="_blank" rel="noreferrer">openrouter.ai/keys</a></span>
        </div>
        <div className="nx-field">
          <label>{t.modelId}</label>
          <input className="nx-input" value={draft.openrouterModel} onChange={(e) => setDraft({ ...draft, openrouterModel: e.target.value })} />
          <div className="nx-chip-row" style={{ marginTop: 6 }}>
            {OR_MODELS.map((m) => (
              <button key={m} className={`nx-chip${draft.openrouterModel === m ? " active" : ""}`}
                onClick={() => setDraft({ ...draft, openrouterModel: m })}>{m}</button>
            ))}
          </div>
        </div>

        {/* v1.4: Web Search API key */}
        <div className="nx-section-label">{t.toolWebSearch} ({t.optional})</div>
        <div className="nx-field">
          <label>{t.searchApiKeyLabel}</label>
          <div className="nx-input-row">
            <input className="nx-input" type={showS ? "text" : "password"} placeholder="tvly-..."
              value={draftSearchKey} onChange={(e) => setDraftSearchKey(e.target.value)} />
            <button type="button" onClick={() => setShowS((s) => !s)}>{showS ? <EyeOff size={16} /> : <Eye size={16} />}</button>
          </div>
          <span className="nx-link-hint">{t.getKeyAt} <a href="https://tavily.com" target="_blank" rel="noreferrer">tavily.com</a></span>
        </div>

        {/* v1.6: Image AI API key */}
        <div className="nx-section-label">🎨 {t.navImageGen} ({t.optional})</div>
        <div className="nx-field">
          <label>{t.imgSettingsLabel}</label>
          <div className="nx-input-row">
            <input className="nx-input" type={showI ? "text" : "password"} placeholder="hf_..."
              value={draftImageKey} onChange={(e) => setDraftImageKey(e.target.value)} />
            <button type="button" onClick={() => setShowI((s) => !s)}>{showI ? <EyeOff size={16} /> : <Eye size={16} />}</button>
          </div>
          <span className="nx-link-hint">{t.getKeyAt} <a href="https://huggingface.co/settings/tokens" target="_blank" rel="noreferrer">huggingface.co</a></span>
        </div>
        <div className="nx-field">
          <label>{t.imgModelLabel}</label>
          <select className="nx-input" value={draftImageModel} onChange={(e) => setDraftImageModel(e.target.value)}>
            {HF_MODELS.map(m => <option key={m} value={m}>{m.split("/")[1]}</option>)}
          </select>
        </div>

        {/* v1.8: Text-to-Video model (Feature 76) */}
        <div className="nx-field">
          <label>{t.navVideoGen} — {t.imgModelLabel}</label>
          <select className="nx-input" value={draftVideoModel} onChange={(e) => setDraftVideoModel(e.target.value)}>
            {HF_VIDEO_MODELS.map(m => <option key={m} value={m}>{m.split("/")[1]}</option>)}
          </select>
        </div>

        {/* v1.8: AI Media Gallery — Cloud Sync (Feature 78) */}
        <div className="nx-section-label">🗂️ {t.navGallery} ({t.optional})</div>
        <div className="nx-toggle-row">
          <span>{t.galleryCloudSyncLabel}</span>
          <div className="nx-pill-group">
            <button className={`nx-pill${!draftCloudSync ? " active" : ""}`} onClick={() => setDraftCloudSync(false)}>{t.galleryCloudSyncOff}</button>
            <button className={`nx-pill${draftCloudSync ? " active" : ""}`} onClick={() => setDraftCloudSync(true)}>{t.galleryCloudSyncOn}</button>
          </div>
        </div>
        <p className="nx-demo-note" style={{ marginTop: -4 }}>{t.galleryCloudSyncHint}</p>

        {/* Feature 24: Voice Settings */}
        <div className="nx-section-label">{t.voiceSettings}</div>
        <div className="nx-toggle-row">
          <span>{t.voiceGender}</span>
          <div className="nx-pill-group">
            <button className={`nx-pill${draftVoiceGender === "female" ? " active" : ""}`} onClick={() => setDraftVoiceGender("female")}>{t.female}</button>
            <button className={`nx-pill${draftVoiceGender === "male" ? " active" : ""}`} onClick={() => setDraftVoiceGender("male")}>{t.male}</button>
          </div>
        </div>
        <div className="nx-toggle-row">
          <span>{t.voiceLang}</span>
          <div className="nx-pill-group">
            <button className={`nx-pill${draftVoiceLang === "en" ? " active" : ""}`} onClick={() => setDraftVoiceLang("en")}>English</button>
            <button className={`nx-pill${draftVoiceLang === "hi" ? " active" : ""}`} onClick={() => setDraftVoiceLang("hi")}>हिंदी</button>
          </div>
        </div>

        <div className="nx-section-label">{t.appearance} / {t.language}</div>
        <div className="nx-toggle-row">
          <span>{t.appearance}</span>
          <div className="nx-pill-group">
            <button className={`nx-pill${theme === "light" ? " active" : ""}`} onClick={() => setTheme("light")}>{t.light}</button>
            <button className={`nx-pill${theme === "dark" ? " active" : ""}`} onClick={() => setTheme("dark")}>{t.dark}</button>
          </div>
        </div>
        <div className="nx-toggle-row">
          <span>{t.language}</span>
          <div className="nx-pill-group">
            <button className={`nx-pill${lang === "en" ? " active" : ""}`} onClick={() => setLang("en")}>English</button>
            <button className={`nx-pill${lang === "hi" ? " active" : ""}`} onClick={() => setLang("hi")}>हिंदी</button>
          </div>
        </div>

        <div className="nx-save-row">
          <button className="nx-btn nx-btn-primary" onClick={save}>{t.save}</button>
          {saved && <span className="nx-saved-flag">{t.saved}</span>}
        </div>
      </div>
    </div>
  );
}

/* ============================= Profile Modal ============================= */
/* ============================ v1.9 Feature 80: Camera Capture Modal ============================ */
function CameraCaptureModal({ t, onCapture, onClose }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [facing, setFacing] = useState("user");
  const [error, setError] = useState("");
  const [captured, setCaptured] = useState(null);

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((tr) => tr.stop());
      streamRef.current = null;
    }
  }, []);

  const startStream = useCallback(async () => {
    setError("");
    stopStream();
    if (!navigator.mediaDevices?.getUserMedia) {
      setError(t.cameraNotSupported);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing }, audio: false });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (e) {
      setError(e?.name === "NotAllowedError" ? t.cameraPermissionDenied : t.cameraNotSupported);
    }
  }, [facing, stopStream, t]);

  useEffect(() => {
    if (!captured) startStream();
    return () => stopStream();
  }, [facing, captured]); // eslint-disable-line react-hooks/exhaustive-deps

  function capture() {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 720;
    canvas.height = video.videoHeight || 1280;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    setCaptured(canvas.toDataURL("image/jpeg", 0.92));
    stopStream();
  }

  function retake() {
    setCaptured(null);
  }

  function confirm() {
    if (captured) onCapture(captured);
  }

  return (
    <div className="nx-modal-overlay" onClick={onClose}>
      <div className="nx-camera-modal" onClick={(e) => e.stopPropagation()}>
        <div className="nx-camera-header">
          <span>{t.openCamera}</span>
          <button className="nx-btn-icon" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="nx-camera-body">
          {error ? (
            <div className="nx-banner"><AlertCircle size={15} /><span>{error}</span></div>
          ) : captured ? (
            <img src={captured} alt="captured" className="nx-camera-preview" />
          ) : (
            <video ref={videoRef} autoPlay playsInline muted className="nx-camera-preview" />
          )}
        </div>
        <div className="nx-camera-controls">
          {captured ? (
            <>
              <button className="nx-btn nx-btn-secondary" onClick={retake}>{t.retakePhoto}</button>
              <button className="nx-btn nx-btn-primary" onClick={confirm}>{t.usePhoto}</button>
            </>
          ) : (
            <>
              <button className="nx-btn-icon" title={t.switchCamera} onClick={() => setFacing((f) => (f === "user" ? "environment" : "user"))} disabled={!!error}>
                <SwitchCamera size={20} />
              </button>
              <button className="nx-camera-shutter" onClick={capture} disabled={!!error} title={t.capturePhoto} />
              <button className="nx-btn nx-btn-secondary" onClick={onClose}>{t.cancelCamera}</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function ProfileModal({ t, user, onSave, onLogout, onClose }) {
  const [name, setName] = useState(user.name);
  const [saved, setSaved] = useState(false);
  return (
    <div className="nx-modal-overlay" onClick={onClose}>
      <div className="nx-modal" style={{ maxWidth: 390 }} onClick={(e) => e.stopPropagation()}>
        <div className="nx-modal-head">
          <h3 className="nx-display">{t.profile}</h3>
          <button className="nx-btn-icon" onClick={onClose}><X size={18} /></button>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 22 }}>
          <div className="nx-avatar" style={{ width: 54, height: 54, fontSize: 17 }}>{initials(name)}</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>{name}</div>
            <div style={{ fontSize: 12.5, color: "var(--text-muted)" }}>{user.email}</div>
          </div>
        </div>

        <div className="nx-section-label">{t.account}</div>
        <div className="nx-field">
          <label>{t.editName}</label>
          <input className="nx-input" value={name} onChange={(e) => setName(e.target.value)} />
        </div>

        <div className="nx-save-row">
          <button className="nx-btn nx-btn-primary" onClick={() => {
            onSave(name.trim() || user.name);
            setSaved(true);
            setTimeout(() => setSaved(false), 1500);
          }}>{t.save}</button>
          {saved && <span className="nx-saved-flag">{t.saved}</span>}
          <button className="nx-btn nx-btn-ghost" style={{ marginLeft: "auto" }} onClick={onLogout}>
            <LogOut size={15} /> {t.logout}
          </button>
        </div>
        <p className="nx-demo-note"><UserIcon size={11} style={{ verticalAlign: "-1px" }} /> {t.demoNote}</p>
      </div>
    </div>
  );
}

/* ============================ Features 31-40: Study AI Dashboard ============================ */
function fmtSize(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

function docIcon(kind) {
  if (kind === "pdf") return <FileText size={15} />;
  if (kind === "docx") return <FileType2 size={15} />;
  return <FileSpreadsheet size={15} />;
}

function parseJSONLoose(text) {
  if (!text) return null;
  let s = text.trim().replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
  const start = s.indexOf("[") === -1 ? s.indexOf("{") : (s.indexOf("{") === -1 ? s.indexOf("[") : Math.min(s.indexOf("{"), s.indexOf("[")));
  const endBrace = s.lastIndexOf("}");
  const endBracket = s.lastIndexOf("]");
  const end = Math.max(endBrace, endBracket);
  if (start !== -1 && end !== -1) s = s.slice(start, end + 1);
  try { return JSON.parse(s); } catch { return null; }
}

function StudyDashboard({
  t, documents, activeDocId, setActiveDocId, onFilesAdded, onRemoveDoc,
  uploadBusy, uploadError, setUploadError, runDocAI, callAI, sidebarOpen, setSidebarOpen,
}) {
  const [studyTab, setStudyTab] = useState("upload");
  const activeDoc = documents.find((d) => d.id === activeDocId) || null;

  const tabs = [
    { id: "upload", label: t.studyDocs, icon: <UploadCloud size={16} /> },
    { id: "summary", label: t.studySummary, icon: <NotebookPen size={16} /> },
    { id: "chat", label: t.studyChat, icon: <MessageSquare size={16} /> },
    { id: "notes", label: t.studyNotes, icon: <BookOpenCheck size={16} /> },
    { id: "quiz", label: t.studyQuiz, icon: <ListChecks size={16} /> },
    { id: "flash", label: t.studyFlash, icon: <Layers size={16} /> },
    { id: "homework", label: t.studyHomework, icon: <GraduationCap size={16} /> },
    { id: "math", label: t.studyMath, icon: <Calculator size={16} /> },
  ];

  return (
    <>
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.studyTitle}</div>
          <div className="nx-topbar-sub">{activeDoc ? activeDoc.name : t.selectDoc}</div>
        </div>
      </div>

      <div className="nx-study-layout">
        <nav className="nx-study-side">
          <div className="nx-study-side-title">{t.studyTitle}</div>
          {tabs.map((tb) => (
            <div key={tb.id} className={`nx-study-tab${studyTab === tb.id ? " active" : ""}`} onClick={() => setStudyTab(tb.id)}>
              {tb.icon} {tb.label}
            </div>
          ))}
        </nav>

        <div className="nx-study-main">
          {studyTab === "upload" && (
            <UploadPanel t={t} documents={documents} activeDocId={activeDocId} setActiveDocId={setActiveDocId}
              onFilesAdded={onFilesAdded} onRemoveDoc={onRemoveDoc} uploadBusy={uploadBusy}
              uploadError={uploadError} setUploadError={setUploadError} />
          )}
          {studyTab !== "upload" && studyTab !== "homework" && studyTab !== "math" && !activeDoc && (
            <div className="nx-study-empty"><FileText size={34} /><p>{t.needDocFirst}</p></div>
          )}
          {studyTab === "summary" && activeDoc && <SummaryPanel t={t} doc={activeDoc} runDocAI={runDocAI} />}
          {studyTab === "chat" && activeDoc && <DocChatPanel t={t} doc={activeDoc} runDocAI={runDocAI} />}
          {studyTab === "notes" && activeDoc && <NotesPanel t={t} doc={activeDoc} runDocAI={runDocAI} />}
          {studyTab === "quiz" && activeDoc && <QuizPanel t={t} doc={activeDoc} runDocAI={runDocAI} />}
          {studyTab === "flash" && activeDoc && <FlashcardsPanel t={t} doc={activeDoc} runDocAI={runDocAI} />}
          {studyTab === "homework" && <HomeworkPanel t={t} callAI={callAI} />}
          {studyTab === "math" && <MathPanel t={t} callAI={callAI} />}
        </div>
      </div>
    </>
  );
}

/* ---- Feature 31: Upload Panel ---- */
function UploadPanel({ t, documents, activeDocId, setActiveDocId, onFilesAdded, onRemoveDoc, uploadBusy, uploadError, setUploadError }) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef(null);

  function handleDrop(e) {
    e.preventDefault();
    setDragging(false);
    onFilesAdded(e.dataTransfer.files);
  }

  return (
    <div>
      <div
        className={`nx-upload-zone${dragging ? " drag" : ""}`}
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
      >
        {uploadBusy ? <Loader2 size={30} className="nx-spin" /> : <UploadCloud size={30} />}
        <h4 className="nx-display">{uploadBusy ? t.processing : t.uploadTitle}</h4>
        <p>{t.uploadSub}</p>
        <p style={{ marginTop: 6, fontSize: 11 }}>{t.uploadHint}</p>
        <input ref={inputRef} type="file" multiple hidden accept=".pdf,.doc,.docx,.xls,.xlsx"
          onChange={(e) => { onFilesAdded(e.target.files); e.target.value = ""; }} />
      </div>

      {uploadError && (
        <div className="nx-banner" style={{ margin: "12px 0 0" }}>
          <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 1 }} />
          <span>{uploadError}</span>
          <button className="nx-btn-icon" style={{ marginLeft: "auto" }} onClick={() => setUploadError("")}><X size={13} /></button>
        </div>
      )}

      <div className="nx-study-side-title" style={{ marginTop: 18 }}>{t.studyDocs}</div>
      {documents.length === 0 ? (
        <p style={{ color: "var(--text-muted)", fontSize: 13 }}>{t.noDocs}</p>
      ) : (
        <div className="nx-study-doclist">
          {documents.map((d) => (
            <div key={d.id} className={`nx-doc-chip${d.id === activeDocId ? " active" : ""}`} onClick={() => setActiveDocId(d.id)}>
              {docIcon(d.kind)}
              <span className="nx-doc-chip-name">{d.name}</span>
              <span style={{ fontSize: 11, color: "var(--text-muted)", flexShrink: 0 }}>{fmtSize(d.size)}</span>
              <button className="nx-doc-chip-del" title={t.removeDoc} onClick={(e) => { e.stopPropagation(); onRemoveDoc(d.id); }}>
                <Trash size={13} />
              </button>
            </div>
          ))}
        </div>
      )}

      {documents.find((d) => d.id === activeDocId)?.kind === "xlsx" && (
        <ExcelPreview doc={documents.find((d) => d.id === activeDocId)} />
      )}
    </div>
  );
}

function ExcelPreview({ doc }) {
  if (!doc?.sheets?.length) return null;
  const sheet = doc.sheets[0];
  const rows = sheet.rows.slice(0, 25);
  return (
    <div style={{ marginTop: 18 }}>
      <div className="nx-study-side-title">{sheet.name}</div>
      <div className="nx-table-wrap">
        <table className="nx-data-table">
          <tbody>
            {rows.map((row, i) => (
              <tr key={i}>
                {row.map((cell, j) => (i === 0 ? <th key={j}>{String(cell)}</th> : <td key={j}>{String(cell)}</td>))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---- Feature 32: Summarizer ---- */
function SummaryPanel({ t, doc, runDocAI }) {
  const [mode, setMode] = useState("short");
  const [results, setResults] = useState({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const prompts = {
    short: "Write a short summary of this document in 3-5 sentences.",
    detailed: "Write a detailed, well-structured summary of this document, covering all major sections.",
    keypoints: "Extract the key points of this document as a clear bullet list.",
  };

  async function generate() {
    setBusy(true); setError("");
    try {
      const out = await runDocAI(doc, prompts[mode]);
      setResults((prev) => ({ ...prev, [mode]: out }));
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.studySummary} — {doc.name}</h4>
      <div className="nx-mode-row">
        <button className={`nx-chip${mode === "short" ? " active" : ""}`} onClick={() => setMode("short")}>{t.shortSummary}</button>
        <button className={`nx-chip${mode === "detailed" ? " active" : ""}`} onClick={() => setMode("detailed")}>{t.detailedSummary}</button>
        <button className={`nx-chip${mode === "keypoints" ? " active" : ""}`} onClick={() => setMode("keypoints")}>{t.keyPoints}</button>
      </div>
      <button className="nx-btn nx-btn-primary" onClick={generate} disabled={busy}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Sparkles size={15} />} {results[mode] ? t.regenerate : t.generate}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {results[mode] && <div className="nx-result-box" style={{ marginTop: 12 }}>{results[mode]}</div>}
    </div>
  );
}

/* ---- Feature 35: Document Q&A ---- */
function DocChatPanel({ t, doc, runDocAI }) {
  const [thread, setThread] = useState([]);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [thread, busy]);

  async function ask() {
    const q = draft.trim();
    if (!q || busy) return;
    setThread((p) => [...p, { role: "user", content: q }]);
    setDraft("");
    setBusy(true);
    try {
      const answer = await runDocAI(doc, `Question: ${q}\n\nAnswer using only the document's content. If the answer isn't in the document, say so.`);
      setThread((p) => [...p, { role: "ai", content: answer }]);
    } catch (e) {
      setThread((p) => [...p, { role: "ai", content: "⚠️ " + (e.message || "Error") }]);
    }
    setBusy(false);
  }

  return (
    <div className="nx-study-card" style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 360 }}>
      <h4>{t.studyChat} — {doc.name}</h4>
      <div className="nx-docchat-thread">
        {thread.map((m, i) => (
          <div key={i} className={`nx-docchat-row ${m.role}`}>
            <div className={`nx-docchat-bubble ${m.role}`}>{m.content}</div>
          </div>
        ))}
        {busy && <div className="nx-docchat-row"><div className="nx-docchat-bubble ai"><TypingDots /></div></div>}
        <div ref={endRef} />
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
        <input className="nx-input" placeholder={t.askAboutDoc} value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") ask(); }} />
        <button className="nx-send-btn" onClick={ask} disabled={!draft.trim() || busy}><Send size={16} /></button>
      </div>
    </div>
  );
}

/* ---- Feature 36: Notes Generator ---- */
function NotesPanel({ t, doc, runDocAI }) {
  const [mode, setMode] = useState("short");
  const [results, setResults] = useState({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const prompts = {
    short: "Generate short, clean study notes from this document.",
    detailed: "Generate detailed, well-organized study notes from this document, with headings.",
    bullets: "Generate study notes from this document as concise bullet points only.",
  };

  async function generate() {
    setBusy(true); setError("");
    try {
      const out = await runDocAI(doc, prompts[mode]);
      setResults((prev) => ({ ...prev, [mode]: out }));
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.studyNotes} — {doc.name}</h4>
      <div className="nx-mode-row">
        <button className={`nx-chip${mode === "short" ? " active" : ""}`} onClick={() => setMode("short")}>{t.notesShort}</button>
        <button className={`nx-chip${mode === "detailed" ? " active" : ""}`} onClick={() => setMode("detailed")}>{t.notesDetailed}</button>
        <button className={`nx-chip${mode === "bullets" ? " active" : ""}`} onClick={() => setMode("bullets")}>{t.notesBullets}</button>
      </div>
      <button className="nx-btn nx-btn-primary" onClick={generate} disabled={busy}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Sparkles size={15} />} {results[mode] ? t.regenerate : t.generate}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {results[mode] && <div className="nx-result-box" style={{ marginTop: 12 }}>{results[mode]}</div>}
    </div>
  );
}

/* ---- Feature 39: Quiz Generator ---- */
function QuizPanel({ t, doc, runDocAI }) {
  const [quizType, setQuizType] = useState("mcq");
  const [questions, setQuestions] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    setBusy(true); setError(""); setSubmitted(false); setAnswers({});
    const typePrompt = quizType === "mcq"
      ? `Create 5 multiple-choice questions. Return ONLY JSON: [{"question":"...","options":["A","B","C","D"],"answer":"A"}]`
      : quizType === "tf"
      ? `Create 5 true/false questions. Return ONLY JSON: [{"question":"...","answer":"True"}]`
      : `Create 5 short-answer questions. Return ONLY JSON: [{"question":"...","answer":"..."}]`;
    try {
      const out = await runDocAI(doc, `${typePrompt}\nBase the questions strictly on the document content. Do not include any text outside the JSON array.`);
      const parsed = parseJSONLoose(out);
      if (!Array.isArray(parsed)) throw new Error("Could not generate quiz, please try again.");
      setQuestions(parsed);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.studyQuiz} — {doc.name}</h4>
      <div className="nx-mode-row">
        <button className={`nx-chip${quizType === "mcq" ? " active" : ""}`} onClick={() => { setQuizType("mcq"); setQuestions(null); }}>{t.quizMCQ}</button>
        <button className={`nx-chip${quizType === "tf" ? " active" : ""}`} onClick={() => { setQuizType("tf"); setQuestions(null); }}>{t.quizTF}</button>
        <button className={`nx-chip${quizType === "short" ? " active" : ""}`} onClick={() => { setQuizType("short"); setQuestions(null); }}>{t.quizShort}</button>
      </div>
      <button className="nx-btn nx-btn-primary" onClick={generate} disabled={busy}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Sparkles size={15} />} {t.generateQuiz}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}

      {questions && (
        <div style={{ marginTop: 16 }}>
          {questions.map((q, i) => (
            <div key={i} className="nx-quiz-q">
              <div className="nx-quiz-q-title">{i + 1}. {q.question}</div>
              {quizType === "mcq" && (q.options || []).map((opt, j) => {
                const isSelected = answers[i] === opt;
                const isCorrect = submitted && opt.trim().toLowerCase() === (q.answer || "").trim().toLowerCase();
                const isWrongPick = submitted && isSelected && !isCorrect;
                return (
                  <div key={j}
                    className={`nx-quiz-opt${isSelected ? " selected" : ""}${isCorrect ? " correct" : ""}${isWrongPick ? " incorrect" : ""}`}
                    onClick={() => !submitted && setAnswers((p) => ({ ...p, [i]: opt }))}>
                    {opt}
                  </div>
                );
              })}
              {quizType === "tf" && ["True", "False"].map((opt) => {
                const isSelected = answers[i] === opt;
                const isCorrect = submitted && opt === q.answer;
                const isWrongPick = submitted && isSelected && !isCorrect;
                return (
                  <div key={opt}
                    className={`nx-quiz-opt${isSelected ? " selected" : ""}${isCorrect ? " correct" : ""}${isWrongPick ? " incorrect" : ""}`}
                    onClick={() => !submitted && setAnswers((p) => ({ ...p, [i]: opt }))}>
                    {opt}
                  </div>
                );
              })}
              {quizType === "short" && (
                <input className="nx-quiz-short-input" disabled={submitted} value={answers[i] || ""}
                  onChange={(e) => setAnswers((p) => ({ ...p, [i]: e.target.value }))} />
              )}
              {submitted && quizType === "short" && (
                <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 6 }}>{t.showAnswer}: {q.answer}</div>
              )}
            </div>
          ))}
          {!submitted ? (
            <button className="nx-btn nx-btn-ghost" onClick={() => setSubmitted(true)}>{t.submitQuiz}</button>
          ) : (
            <div className="nx-quiz-score">{t.yourScore}: {questions.reduce((acc, q, i) => {
              const a = (answers[i] || "").toString().trim().toLowerCase();
              const correct = (q.answer || "").toString().trim().toLowerCase();
              const ok = quizType === "short" ? (a && correct.includes(a)) : a === correct;
              return acc + (ok ? 1 : 0);
            }, 0)} / {questions.length}</div>
          )}
        </div>
      )}
    </div>
  );
}

/* ---- Feature 40: Flashcards Maker ---- */
function FlashcardsPanel({ t, doc, runDocAI }) {
  const [cards, setCards] = useState(null);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    setBusy(true); setError(""); setIndex(0); setFlipped(false);
    try {
      const out = await runDocAI(doc, `Create 10 flashcards from this document. Return ONLY JSON: [{"front":"question","back":"answer"}]. No text outside the JSON array.`);
      const parsed = parseJSONLoose(out);
      if (!Array.isArray(parsed)) throw new Error("Could not generate flashcards, please try again.");
      setCards(parsed);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  const card = cards?.[index];

  return (
    <div className="nx-study-card">
      <h4>{t.studyFlash} — {doc.name}</h4>
      <button className="nx-btn nx-btn-primary" onClick={generate} disabled={busy}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Sparkles size={15} />} {t.generateFlash}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}

      {card && (
        <div style={{ marginTop: 18 }}>
          <div className="nx-flash-card" onClick={() => setFlipped((f) => !f)}>
            <div className={`nx-flash-inner${flipped ? " flipped" : ""}`}>
              <div className="nx-flash-face front">{card.front}</div>
              <div className="nx-flash-face back">{card.back}</div>
            </div>
          </div>
          <p className="nx-flash-hint">{t.flipCard} · {t.cardOf} {index + 1}/{cards.length}</p>
          <div className="nx-flash-nav">
            <button className="nx-btn-icon" onClick={() => { setIndex((i) => Math.max(0, i - 1)); setFlipped(false); }}><ChevronLeft size={18} /></button>
            <button className="nx-btn-icon" onClick={() => { setFlipped(false); }}><RotateCcw size={16} /></button>
            <button className="nx-btn-icon" onClick={() => { setIndex((i) => Math.min(cards.length - 1, i + 1)); setFlipped(false); }}><ChevronRight size={18} /></button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---- Feature 37: Homework Helper ---- */
function HomeworkPanel({ t, callAI }) {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function solve() {
    if (!question.trim() || busy) return;
    setBusy(true); setError(""); setAnswer("");
    try {
      const out = await callAI([
        { role: "system", content: "You are a patient homework tutor for school and college students. Cover science, history, geography, and general subjects. Always explain the answer step-by-step in a clear, structured way before giving the final answer." },
        { role: "user", content: question },
      ]);
      setAnswer(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.studyHomework}</h4>
      <textarea className="nx-textarea-box" placeholder={t.homeworkPlaceholder} value={question} onChange={(e) => setQuestion(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={solve} disabled={busy || !question.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <GraduationCap size={15} />} {t.explain}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {answer && <div className="nx-result-box" style={{ marginTop: 12 }}>{answer}</div>}
    </div>
  );
}

/* ---- Feature 38: Math Solver ---- */
function MathPanel({ t, callAI }) {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function solve() {
    if (!question.trim() || busy) return;
    setBusy(true); setError(""); setAnswer("");
    try {
      const out = await callAI([
        { role: "system", content: "You are a math tutor. Solve the given problem (arithmetic, algebra, geometry, trigonometry, or basic calculus) showing clear step-by-step working, and state the final answer clearly at the end." },
        { role: "user", content: question },
      ]);
      setAnswer(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.studyMath}</h4>
      <textarea className="nx-textarea-box" placeholder={t.mathPlaceholder} value={question} onChange={(e) => setQuestion(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={solve} disabled={busy || !question.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Calculator size={15} />} {t.solve}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {answer && <div className="nx-result-box" style={{ marginTop: 12 }}>{answer}</div>}
    </div>
  );
}

/* ============================ Features 41-50: Coding + Writing AI ============================ */

/* ---- Feature 41/42/44: lightweight built-in syntax highlighter (no external deps) ---- */
const JS_KEYWORDS = ["const","let","var","function","return","if","else","for","while","do","switch","case","break","continue","class","extends","super","new","this","import","export","default","from","as","async","await","try","catch","finally","throw","typeof","instanceof","of","in","null","undefined","true","false","static","get","set","yield","void","delete"];
const PY_KEYWORDS = ["def","return","if","elif","else","for","while","class","import","from","as","try","except","finally","with","lambda","not","and","or","in","is","None","True","False","pass","break","continue","yield","global","nonlocal","raise","assert","del","async","await","print"];

function tokenizeCode(code, regex, classes) {
  const out = [];
  let lastIndex = 0;
  let match;
  regex.lastIndex = 0;
  while ((match = regex.exec(code))) {
    if (match.index > lastIndex) out.push({ text: code.slice(lastIndex, match.index), cls: null });
    let cls = null;
    for (let i = 1; i < match.length; i++) {
      if (match[i] !== undefined) { cls = classes[i - 1]; break; }
    }
    out.push({ text: match[0], cls });
    lastIndex = match.index + match[0].length;
    if (match[0].length === 0) regex.lastIndex++;
  }
  if (lastIndex < code.length) out.push({ text: code.slice(lastIndex), cls: null });
  return out;
}

function highlightCode(code, lang) {
  const safeCode = code || "";
  const l = (lang || "").toLowerCase();
  let regex, classes;
  if (l.includes("html") || l.includes("xml")) {
    regex = /(<!--[\s\S]*?-->)|(<\/?[a-zA-Z][\w-]*)|([a-zA-Z-]+(?==))|("[^"]*"|'[^']*')/g;
    classes = ["nx-tok-comment", "nx-tok-tag", "nx-tok-attr", "nx-tok-string"];
  } else if (l === "css") {
    regex = /(\/\*[\s\S]*?\*\/)|([.#]?[a-zA-Z][\w-]*(?=\s*\{))|([a-zA-Z-]+(?=\s*:))|("[^"]*"|'[^']*')|(#[0-9a-fA-F]{3,8}\b|\b\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms)?\b)/g;
    classes = ["nx-tok-comment", "nx-tok-tag", "nx-tok-prop", "nx-tok-string", "nx-tok-number"];
  } else {
    const keywords = l.includes("py") ? PY_KEYWORDS : JS_KEYWORDS;
    regex = new RegExp(
      '(\\/\\/.*|#.*)|("(?:[^"\\\\]|\\\\.)*"|\'(?:[^\'\\\\]|\\\\.)*\'|`(?:[^`\\\\]|\\\\.)*`)|(\\b(?:' +
        keywords.join('|') +
        ')\\b)|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b[a-zA-Z_]\\w*(?=\\())',
      'g'
    );
    classes = ["nx-tok-comment", "nx-tok-string", "nx-tok-keyword", "nx-tok-number", "nx-tok-func"];
  }
  return tokenizeCode(safeCode, regex, classes);
}

/* ---- Code block with syntax highlighting + copy-to-clipboard (Features 41/42/43/44) ---- */
function CodeBlock({ code, lang = "", t }) {
  const [copied, setCopied] = useState(false);
  const tokens = highlightCode(code, lang);

  function doCopy() {
    navigator.clipboard?.writeText(code || "").then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }).catch(() => {});
  }

  return (
    <div className="nx-codeblock">
      <div className="nx-codeblock-bar">
        <span className="nx-codeblock-lang">{lang || "code"}</span>
        <button className="nx-codeblock-copy" onClick={doCopy}>
          {copied ? <><Check size={13} /> {t?.copied || "Copied"}</> : <><Copy size={13} /> {t?.copy || "Copy"}</>}
        </button>
      </div>
      <pre><code>
        {tokens.map((tok, i) => (tok.cls ? <span key={i} className={tok.cls}>{tok.text}</span> : <span key={i}>{tok.text}</span>))}
      </code></pre>
    </div>
  );
}

/* Splits an AI response into alternating plain-text and fenced-code segments so that
   generated code is always rendered through CodeBlock (with highlighting + copy button)
   while any surrounding explanation stays as normal text. */
function splitCodeBlocks(text) {
  const src = text || "";
  const regex = /```(\w[\w+-]*)?\n?([\s\S]*?)```/g;
  const parts = [];
  let lastIndex = 0;
  let match;
  while ((match = regex.exec(src))) {
    if (match.index > lastIndex) parts.push({ type: "text", content: src.slice(lastIndex, match.index) });
    parts.push({ type: "code", lang: match[1] || "", content: match[2].replace(/\n$/, "") });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < src.length) parts.push({ type: "text", content: src.slice(lastIndex) });
  return parts;
}

function AIResponseRenderer({ text, t }) {
  const parts = splitCodeBlocks(text);
  return (
    <>
      {parts.map((p, i) => {
        if (p.type === "code") return <CodeBlock key={i} code={p.content} lang={p.lang} t={t} />;
        const trimmed = p.content.trim();
        if (!trimmed) return null;
        return <div key={i} className="nx-ai-text-block">{trimmed}</div>;
      })}
    </>
  );
}

/* Small reusable copy button for plain-text results (Features 45-50) */
function CopyResultButton({ text, label, t }) {
  const [copied, setCopied] = useState(false);
  if (!text) return null;
  function doCopy() {
    navigator.clipboard?.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }).catch(() => {});
  }
  return (
    <button className="nx-copy-result-btn" onClick={doCopy}>
      {copied ? <><Check size={13} /> {t.copied}</> : <><Copy size={13} /> {label || t.copy}</>}
    </button>
  );
}

/* ============================ Coding Tools Dashboard ============================ */
function CodingDashboard({ t, callAI, sidebarOpen, setSidebarOpen }) {
  const [tab, setTab] = useState("codegen");
  const tabs = [
    { id: "codegen", label: t.toolCodeGen, icon: <Code2 size={16} /> },
    { id: "debug", label: t.toolCodeDebug, icon: <Bug size={16} /> },
    { id: "webgen", label: t.toolWebGen, icon: <FileCode2 size={16} /> },
    { id: "python", label: t.toolPyHelper, icon: <Terminal size={16} /> },
  ];

  return (
    <>
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.codingTitle}</div>
          <div className="nx-topbar-sub">{tabs.find((tb) => tb.id === tab)?.label}</div>
        </div>
      </div>

      <div className="nx-study-layout">
        <nav className="nx-study-side">
          <div className="nx-study-side-title">{t.codingTitle}</div>
          {tabs.map((tb) => (
            <div key={tb.id} className={`nx-study-tab${tab === tb.id ? " active" : ""}`} onClick={() => setTab(tb.id)}>
              {tb.icon} {tb.label}
            </div>
          ))}
        </nav>
        <div className="nx-study-main">
          {tab === "codegen" && <CodeGeneratorPanel t={t} callAI={callAI} />}
          {tab === "debug" && <CodeDebuggerPanel t={t} callAI={callAI} />}
          {tab === "webgen" && <WebsiteGeneratorPanel t={t} callAI={callAI} />}
          {tab === "python" && <PythonHelperPanel t={t} callAI={callAI} />}
        </div>
      </div>
    </>
  );
}

/* ---- Feature 41: Code Generator ---- */
function CodeGeneratorPanel({ t, callAI }) {
  const [lang, setLang] = useState(CODE_LANGUAGES[0]);
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    if (!prompt.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        {
          role: "system",
          content: `You are an expert ${lang} developer. Generate clean, correct, well-commented, production-quality ${lang} code for the user's request. Respond with the code in a single fenced markdown code block (\`\`\`${lang.toLowerCase()} ... \`\`\`). You may add a short explanation after the code block, but keep the code itself complete and runnable.`,
        },
        { role: "user", content: prompt },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolCodeGen}</h4>
      <div className="nx-section-label">{t.selectLanguage}</div>
      <div className="nx-mode-row">
        {CODE_LANGUAGES.map((l) => (
          <button key={l} className={`nx-chip${lang === l ? " active" : ""}`} onClick={() => setLang(l)}>{l}</button>
        ))}
      </div>
      <textarea className="nx-textarea-box" placeholder={t.codePromptPlaceholder} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={generate} disabled={busy || !prompt.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Code2 size={15} />} {t.generateCode}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {result && <div style={{ marginTop: 14 }}><AIResponseRenderer text={result} t={t} /></div>}
    </div>
  );
}

/* ---- Feature 42: Code Debugger ---- */
function CodeDebuggerPanel({ t, callAI }) {
  const [code, setCode] = useState("");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function analyze() {
    if (!code.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        {
          role: "system",
          content: "You are an expert code reviewer and debugger. Analyze the user's code, detect any errors or bugs, explain each issue clearly in plain language, suggest fixes, and then provide the complete corrected code in a single fenced markdown code block. Structure your answer as: 1) Issues Found (bullet list), 2) a brief explanation, 3) the corrected code in a fenced code block.",
        },
        { role: "user", content: code },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolCodeDebug}</h4>
      <textarea
        className="nx-textarea-box" style={{ minHeight: 160, fontFamily: "Menlo,Consolas,monospace", fontSize: 12.8 }}
        placeholder={t.debugCodePlaceholder} value={code} onChange={(e) => setCode(e.target.value)}
      />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={analyze} disabled={busy || !code.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Bug size={15} />} {t.analyzeDebug}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {result && <div style={{ marginTop: 14 }}><AIResponseRenderer text={result} t={t} /></div>}
    </div>
  );
}

/* ---- Feature 43: HTML/CSS/JS Website Generator ---- */
function WebsiteGeneratorPanel({ t, callAI }) {
  const [prompt, setPrompt] = useState("");
  const [site, setSite] = useState(null);
  const [activeTab, setActiveTab] = useState("preview");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    if (!prompt.trim() || busy) return;
    setBusy(true); setError(""); setSite(null);
    try {
      const out = await callAI([
        {
          role: "system",
          content: 'You are an expert front-end developer. Build a complete, responsive website based on the user\'s description, using semantic HTML5, modern CSS (flexbox/grid, mobile-first responsive breakpoints) and vanilla JavaScript only if needed for interactivity. Respond with ONLY a single valid JSON object, no markdown fences, no extra text: {"html":"...","css":"...","js":"..."}. The html field must contain only the body markup (no <html>, <head> or <body> tags). Properly escape quotes and newlines so the JSON parses correctly.',
        },
        { role: "user", content: prompt },
      ]);
      const parsed = parseJSONLoose(out);
      if (!parsed || typeof parsed.html !== "string") throw new Error("Could not generate the website, please try again.");
      setSite({ html: parsed.html || "", css: parsed.css || "", js: parsed.js || "" });
      setActiveTab("preview");
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  const srcDoc = site
    ? `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">` +
      `<style>${site.css}</style></head><body>${site.html}<script>${site.js}</script></body></html>`
    : "";

  const tabs = [
    { id: "preview", label: t.previewLabel, icon: <Play size={13} /> },
    { id: "html", label: t.htmlLabel, icon: <Code size={13} /> },
    { id: "css", label: t.cssLabel, icon: <Code size={13} /> },
    { id: "js", label: t.jsLabel, icon: <Code size={13} /> },
  ];

  return (
    <div className="nx-study-card">
      <h4>{t.toolWebGen}</h4>
      <textarea className="nx-textarea-box" placeholder={t.webPromptPlaceholder} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={generate} disabled={busy || !prompt.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <FileCode2 size={15} />} {t.generateWebsite}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}

      {site && (
        <div style={{ marginTop: 16 }}>
          <div className="nx-code-tabs">
            {tabs.map((tb) => (
              <button key={tb.id} className={`nx-chip${activeTab === tb.id ? " active" : ""}`} onClick={() => setActiveTab(tb.id)}>
                {tb.icon} {tb.label}
              </button>
            ))}
          </div>
          {activeTab === "preview" && (
            <div className="nx-preview-frame-wrap">
              <div className="nx-preview-toolbar"><Play size={12} /> {t.previewLabel}</div>
              <iframe title="preview" srcDoc={srcDoc} sandbox="allow-scripts" />
            </div>
          )}
          {activeTab === "html" && <CodeBlock code={site.html} lang="html" t={t} />}
          {activeTab === "css" && <CodeBlock code={site.css} lang="css" t={t} />}
          {activeTab === "js" && <CodeBlock code={site.js || "/* no JavaScript generated */"} lang="javascript" t={t} />}
        </div>
      )}
    </div>
  );
}

/* ---- Feature 44: Python Helper ---- */
function PythonHelperPanel({ t, callAI }) {
  const [mode, setMode] = useState("generate");
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const modes = [
    { id: "generate", label: t.pyModeGenerate },
    { id: "explain", label: t.pyModeExplain },
    { id: "debug", label: t.pyModeDebug },
    { id: "optimize", label: t.pyModeOptimize },
  ];

  const SYS = {
    generate: "You are an expert Python developer. Write a clean, correct, well-commented Python script for the user's request, and include a short usage example. Respond with the code in a fenced ```python code block, followed by a brief explanation.",
    explain: "You are an expert Python tutor. Explain the given Python code clearly and step by step, in plain language a beginner can follow.",
    debug: "You are an expert Python debugger. Find and explain any errors or bugs in the given Python code, then provide the complete corrected version in a fenced ```python code block.",
    optimize: "You are an expert Python performance engineer. Review the given Python code, explain how it can be optimized for performance, readability and Pythonic style, then provide the optimized version in a fenced ```python code block.",
  };

  async function run() {
    if (!input.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        { role: "system", content: SYS[mode] },
        { role: "user", content: input },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolPyHelper}</h4>
      <div className="nx-mode-row">
        {modes.map((m) => (
          <button key={m.id} className={`nx-chip${mode === m.id ? " active" : ""}`} onClick={() => setMode(m.id)}>{m.label}</button>
        ))}
      </div>
      <textarea
        className="nx-textarea-box" style={{ minHeight: 140, fontFamily: "Menlo,Consolas,monospace", fontSize: 12.8 }}
        placeholder={t.pyPromptPlaceholder} value={input} onChange={(e) => setInput(e.target.value)}
      />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={run} disabled={busy || !input.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Terminal size={15} />} {modes.find((m) => m.id === mode)?.label}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {result && <div style={{ marginTop: 14 }}><AIResponseRenderer text={result} t={t} /></div>}
    </div>
  );
}

/* ============================ Writing Tools Dashboard ============================ */
function WritingDashboard({ t, callAI, sidebarOpen, setSidebarOpen }) {
  const [tab, setTab] = useState("essay");
  const tabs = [
    { id: "essay", label: t.toolEssay, icon: <PenLine size={16} /> },
    { id: "blog", label: t.toolBlog, icon: <Newspaper size={16} /> },
    { id: "email", label: t.toolEmail, icon: <Mail size={16} /> },
    { id: "resume", label: t.toolResume, icon: <Briefcase size={16} /> },
    { id: "grammar", label: t.toolGrammar, icon: <SpellCheck size={16} /> },
    { id: "paraphrase", label: t.toolParaphrase, icon: <Wand2 size={16} /> },
  ];

  return (
    <>
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.writingTitle}</div>
          <div className="nx-topbar-sub">{tabs.find((tb) => tb.id === tab)?.label}</div>
        </div>
      </div>

      <div className="nx-study-layout">
        <nav className="nx-study-side">
          <div className="nx-study-side-title">{t.writingTitle}</div>
          {tabs.map((tb) => (
            <div key={tb.id} className={`nx-study-tab${tab === tb.id ? " active" : ""}`} onClick={() => setTab(tb.id)}>
              {tb.icon} {tb.label}
            </div>
          ))}
        </nav>
        <div className="nx-study-main">
          {tab === "essay" && <EssayWriterPanel t={t} callAI={callAI} />}
          {tab === "blog" && <BlogWriterPanel t={t} callAI={callAI} />}
          {tab === "email" && <EmailWriterPanel t={t} callAI={callAI} />}
          {tab === "resume" && <ResumeBuilderPanel t={t} callAI={callAI} />}
          {tab === "grammar" && <GrammarFixerPanel t={t} callAI={callAI} />}
          {tab === "paraphrase" && <ParaphraserPanel t={t} callAI={callAI} />}
        </div>
      </div>
    </>
  );
}

/* ---- Feature 45: Essay Writer ---- */
function EssayWriterPanel({ t, callAI }) {
  const [topic, setTopic] = useState("");
  const [mode, setMode] = useState("medium");
  const [words, setWords] = useState(600);
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const presets = { short: 300, medium: 600, long: 1000 };

  function pickMode(m) {
    setMode(m);
    setWords(presets[m]);
  }

  async function generate() {
    if (!topic.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        {
          role: "system",
          content: `You are an academic essay writer. Write a well-structured essay in formal academic writing format (a clear introduction with a thesis, body paragraphs with topic sentences and supporting evidence, and a conclusion) of approximately ${words} words on the given topic.`,
        },
        { role: "user", content: topic },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolEssay}</h4>
      <div className="nx-mode-row">
        <button className={`nx-chip${mode === "short" ? " active" : ""}`} onClick={() => pickMode("short")}>{t.essayShort}</button>
        <button className={`nx-chip${mode === "medium" ? " active" : ""}`} onClick={() => pickMode("medium")}>{t.essayMedium}</button>
        <button className={`nx-chip${mode === "long" ? " active" : ""}`} onClick={() => pickMode("long")}>{t.essayLong}</button>
      </div>
      <div className="nx-field" style={{ maxWidth: 220 }}>
        <label>{t.wordsApprox}</label>
        <input
          className="nx-input" type="number" min={100} max={3000} step={50} value={words}
          onChange={(e) => setWords(Number(e.target.value) || presets[mode])}
        />
      </div>
      <textarea className="nx-textarea-box" placeholder={t.essayTopicPlaceholder} value={topic} onChange={(e) => setTopic(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={generate} disabled={busy || !topic.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <PenLine size={15} />} {t.generateEssay}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {result && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head"><h5>{t.resultLabel}</h5><CopyResultButton text={result} t={t} /></div>
          <div className="nx-result-box">{result}</div>
        </div>
      )}
    </div>
  );
}

/* ---- Feature 46: Blog Writer ---- */
function BlogWriterPanel({ t, callAI }) {
  const [topic, setTopic] = useState("");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    if (!topic.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        {
          role: "system",
          content: "You are an expert SEO content writer. Write a complete, SEO-friendly blog article on the given topic. Start with 3 catchy blog title suggestions, then write the full article with a clear, automatically structured set of headings and subheadings, an engaging introduction, and a strong conclusion.",
        },
        { role: "user", content: topic },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolBlog}</h4>
      <textarea className="nx-textarea-box" placeholder={t.blogTopicPlaceholder} value={topic} onChange={(e) => setTopic(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={generate} disabled={busy || !topic.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Newspaper size={15} />} {t.generateBlog}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {result && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head"><h5>{t.resultLabel}</h5><CopyResultButton text={result} t={t} /></div>
          <div className="nx-result-box">{result}</div>
        </div>
      )}
    </div>
  );
}

/* ---- Feature 47: Email Writer ---- */
function EmailWriterPanel({ t, callAI }) {
  const [mode, setMode] = useState("formal");
  const [purpose, setPurpose] = useState("");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const styleDesc = {
    formal: "a polite, formal tone suitable for official or academic correspondence",
    informal: "a friendly, casual, conversational tone suitable for friends or peers",
    business: "a professional business tone suitable for clients, colleagues or partners",
  };

  async function generate() {
    if (!purpose.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        {
          role: "system",
          content: `You are a professional email writer. Write a complete, well-structured email (including a subject line, greeting, body and sign-off) using ${styleDesc[mode]}.`,
        },
        { role: "user", content: purpose },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolEmail}</h4>
      <div className="nx-mode-row">
        <button className={`nx-chip${mode === "formal" ? " active" : ""}`} onClick={() => setMode("formal")}>{t.emailFormal}</button>
        <button className={`nx-chip${mode === "informal" ? " active" : ""}`} onClick={() => setMode("informal")}>{t.emailInformal}</button>
        <button className={`nx-chip${mode === "business" ? " active" : ""}`} onClick={() => setMode("business")}>{t.emailBusiness}</button>
      </div>
      <textarea className="nx-textarea-box" placeholder={t.emailPurposePlaceholder} value={purpose} onChange={(e) => setPurpose(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={generate} disabled={busy || !purpose.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Mail size={15} />} {t.generateEmail}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {result && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head"><h5>{t.resultLabel}</h5><CopyResultButton text={result} label={t.copyEmail} t={t} /></div>
          <div className="nx-result-box">{result}</div>
        </div>
      )}
    </div>
  );
}

/* ---- Feature 48: Resume Builder ---- */
function ResumeBuilderPanel({ t, callAI }) {
  const [form, setForm] = useState({ name: "", contact: "", skills: "", education: "", experience: "" });
  const [template, setTemplate] = useState("modern");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  function update(field, val) { setForm((p) => ({ ...p, [field]: val })); }

  async function generate() {
    if (!form.name.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        {
          role: "system",
          content: "You are a professional resume writer. Using the details provided, write a complete, well-organized, professional resume in plain text with clear sections: Header (name + contact), Professional Summary, Skills, Experience, and Education. Use concise, achievement-oriented bullet points where appropriate. Do not use markdown symbols like # or **.",
        },
        {
          role: "user",
          content: `Name: ${form.name}\nContact: ${form.contact}\nSkills: ${form.skills}\nEducation: ${form.education}\nExperience: ${form.experience}`,
        },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  function download() {
    const blob = new Blob([result], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(form.name || "resume").trim().replace(/\s+/g, "-") || "resume"}-resume.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function printResume() {
    const w = window.open("", "_blank");
    if (!w) return;
    const safe = (result || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    w.document.write(
      `<html><head><title>${form.name || "Resume"}</title></head><body>` +
      `<pre style="font-family:Inter,Arial,sans-serif;font-size:14px;white-space:pre-wrap;max-width:680px;margin:40px auto;">${safe}</pre>` +
      `</body></html>`
    );
    w.document.close();
    w.focus();
    w.print();
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolResume}</h4>
      <div className="nx-resume-grid">
        <div className="nx-field">
          <label>{t.resumeFullName}</label>
          <input className="nx-input" value={form.name} onChange={(e) => update("name", e.target.value)} />
        </div>
        <div className="nx-field">
          <label>{t.resumeContact}</label>
          <input className="nx-input" value={form.contact} onChange={(e) => update("contact", e.target.value)} />
        </div>
        <div className="nx-field full">
          <label>{t.resumeSkills}</label>
          <textarea className="nx-textarea-box" style={{ minHeight: 60 }} value={form.skills} onChange={(e) => update("skills", e.target.value)} />
        </div>
        <div className="nx-field full">
          <label>{t.resumeEducation}</label>
          <textarea className="nx-textarea-box" style={{ minHeight: 60 }} value={form.education} onChange={(e) => update("education", e.target.value)} />
        </div>
        <div className="nx-field full">
          <label>{t.resumeExperience}</label>
          <textarea className="nx-textarea-box" style={{ minHeight: 80 }} value={form.experience} onChange={(e) => update("experience", e.target.value)} />
        </div>
      </div>

      <div className="nx-section-label" style={{ marginTop: 4 }}>{t.resumeTemplate}</div>
      <div className="nx-mode-row">
        <button className={`nx-chip${template === "modern" ? " active" : ""}`} onClick={() => setTemplate("modern")}>{t.templateModern}</button>
        <button className={`nx-chip${template === "classic" ? " active" : ""}`} onClick={() => setTemplate("classic")}>{t.templateClassic}</button>
        <button className={`nx-chip${template === "minimal" ? " active" : ""}`} onClick={() => setTemplate("minimal")}>{t.templateMinimal}</button>
      </div>

      <button className="nx-btn nx-btn-primary" style={{ marginTop: 6 }} onClick={generate} disabled={busy || !form.name.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Briefcase size={15} />} {t.generateResume}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}

      <div className="nx-section-label" style={{ marginTop: 18 }}>{t.resumePreview}</div>
      {!result ? (
        <p style={{ color: "var(--text-muted)", fontSize: 13 }}>{t.fillResumeFirst}</p>
      ) : (
        <>
          <div className={`nx-resume-preview tpl-${template}`}>{result}</div>
          <div className="nx-resume-actions">
            <button className="nx-btn nx-btn-ghost" onClick={download}><Download size={15} /> {t.downloadResume}</button>
            <button className="nx-btn nx-btn-ghost" onClick={printResume}><FileText size={15} /> {t.printResume}</button>
          </div>
        </>
      )}
    </div>
  );
}

/* ---- Feature 49: Grammar Fixer ---- */
function GrammarFixerPanel({ t, callAI }) {
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function fix() {
    if (!input.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        {
          role: "system",
          content: "You are an expert proofreader and editor. Correct grammar mistakes, improve sentence structure and overall readability in the given text, while strictly preserving the original meaning and intent. Return only the corrected text, with no extra commentary.",
        },
        { role: "user", content: input },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolGrammar}</h4>
      <textarea className="nx-textarea-box" style={{ minHeight: 140 }} placeholder={t.grammarPlaceholder} value={input} onChange={(e) => setInput(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={fix} disabled={busy || !input.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <SpellCheck size={15} />} {t.fixGrammarBtn}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {result && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head"><h5>{t.resultLabel}</h5><CopyResultButton text={result} t={t} /></div>
          <div className="nx-result-box">{result}</div>
        </div>
      )}
    </div>
  );
}

/* ---- Feature 50: Paraphraser ---- */
function ParaphraserPanel({ t, callAI }) {
  const [mode, setMode] = useState("simple");
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const styleDesc = {
    simple: "simple, plain, easy-to-understand language",
    professional: "a polished, professional tone suitable for formal writing",
    creative: "a creative, expressive tone with varied sentence structure and vivid word choice",
  };

  async function paraphrase() {
    if (!input.trim() || busy) return;
    setBusy(true); setError(""); setResult("");
    try {
      const out = await callAI([
        {
          role: "system",
          content: `You are an expert paraphrasing assistant. Rewrite the given text using ${styleDesc[mode]}, while strictly maintaining the original context and meaning. Return only the rewritten text, with no extra commentary.`,
        },
        { role: "user", content: input },
      ]);
      setResult(out);
    } catch (e) { setError(e.message || "Error"); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolParaphrase}</h4>
      <div className="nx-mode-row">
        <button className={`nx-chip${mode === "simple" ? " active" : ""}`} onClick={() => setMode("simple")}>{t.paraphraseSimple}</button>
        <button className={`nx-chip${mode === "professional" ? " active" : ""}`} onClick={() => setMode("professional")}>{t.paraphraseProfessional}</button>
        <button className={`nx-chip${mode === "creative" ? " active" : ""}`} onClick={() => setMode("creative")}>{t.paraphraseCreative}</button>
      </div>
      <textarea className="nx-textarea-box" style={{ minHeight: 140 }} placeholder={t.paraphrasePlaceholder} value={input} onChange={(e) => setInput(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={paraphrase} disabled={busy || !input.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Wand2 size={15} />} {t.paraphraseBtn}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {result && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head"><h5>{t.resultLabel}</h5><CopyResultButton text={result} t={t} /></div>
          <div className="nx-result-box">{result}</div>
        </div>
      )}
    </div>
  );
}

/* ===================================================================== */
/* ===================== v1.4: WEB INTELLIGENCE HUB ===================== */
/* ===================================================================== */

/* Generic Tavily-backed web search. Falls back to AI-only knowledge if no key. */
async function tavilySearch(query, apiKey, { topic = "general", maxResults = 6 } = {}) {
  if (!apiKey) return { live: false, results: [], answer: "" };
  let res;
  try {
    res = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: apiKey,
        query,
        topic,
        search_depth: "basic",
        max_results: maxResults,
        include_answer: true,
      }),
    });
  } catch {
    throw new Error("Network error while searching the web — check your connection.");
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error || body?.detail || `Search error (${res.status})`);
  }
  const data = await res.json();
  return {
    live: true,
    results: (data.results || []).map((r) => ({ title: r.title, url: r.url, content: r.content })),
    answer: data.answer || "",
  };
}

function IntelDashboard({ t, callAI, searchApiKey, sidebarOpen, setSidebarOpen }) {
  const [tab, setTab] = useState("search");
  const [sharedDataset, setSharedDataset] = useState(null); // { headers, rows } shared between Data Analysis + Charts

  const tabs = [
    { id: "search", label: t.toolWebSearch, icon: <Search size={16} /> },
    { id: "news", label: t.toolNews, icon: <Newspaper size={16} /> },
    { id: "weather", label: t.toolWeather, icon: <Cloud size={16} /> },
    { id: "factcheck", label: t.toolFactCheck, icon: <ShieldCheck size={16} /> },
    { id: "data", label: t.toolDataAnalysis, icon: <Database size={16} /> },
    { id: "charts", label: t.toolCharts, icon: <BarChart3 size={16} /> },
  ];

  return (
    <>
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.intelTitle}</div>
          <div className="nx-topbar-sub">{tabs.find((tb) => tb.id === tab)?.label}</div>
        </div>
      </div>

      <div className="nx-study-layout">
        <nav className="nx-study-side">
          <div className="nx-study-side-title">{t.intelTitle}</div>
          {tabs.map((tb) => (
            <div key={tb.id} className={`nx-study-tab${tab === tb.id ? " active" : ""}`} onClick={() => setTab(tb.id)}>
              {tb.icon} {tb.label}
            </div>
          ))}
        </nav>
        <div className="nx-study-main">
          {tab === "search" && <WebSearchPanel t={t} callAI={callAI} searchApiKey={searchApiKey} />}
          {tab === "news" && <NewsPanel t={t} callAI={callAI} searchApiKey={searchApiKey} />}
          {tab === "weather" && <WeatherPanel t={t} />}
          {tab === "factcheck" && <FactCheckPanel t={t} callAI={callAI} searchApiKey={searchApiKey} />}
          {tab === "data" && <DataAnalysisPanel t={t} callAI={callAI} dataset={sharedDataset} setDataset={setSharedDataset} />}
          {tab === "charts" && <ChartGeneratorPanel t={t} dataset={sharedDataset} />}
        </div>
      </div>
    </>
  );
}

/* ---- Feature: Web Search Integration ---- */
function WebSearchPanel({ t, callAI, searchApiKey }) {
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [answer, setAnswer] = useState("");
  const [results, setResults] = useState([]);
  const [isLive, setIsLive] = useState(false);

  async function runSearch() {
    if (!query.trim() || busy) return;
    setBusy(true); setError(""); setAnswer(""); setResults([]);
    try {
      const sr = await tavilySearch(query, searchApiKey, { topic: "general", maxResults: 6 });
      if (sr.live) {
        setIsLive(true);
        setResults(sr.results);
        const context = sr.results.map((r, i) => `[${i + 1}] ${r.title}\n${r.content}\nURL: ${r.url}`).join("\n\n");
        const summary = await callAI([
          { role: "system", content: "You are Novexa AI's web research assistant. Summarize the given live search results clearly and accurately in the user's language (English or Hinglish), citing source numbers like [1], [2] where relevant. Keep it concise and well structured." },
          { role: "user", content: `Search query: ${query}\n\nSearch results:\n${context}\n\nGive a clear, well-organized summary of these results.` },
        ]);
        setAnswer(summary);
      } else {
        setIsLive(false);
        const out = await callAI([
          { role: "system", content: "You are Novexa AI. The user wants a web search but no live search key is configured, so answer from your own knowledge as best you can, and clearly note that this is not a live web result." },
          { role: "user", content: query },
        ]);
        setAnswer(out);
      }
    } catch (e) { setError(e.message || t.networkErr); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolWebSearch}</h4>
      <p style={{ color: "var(--text-muted)", fontSize: 12.5, marginTop: -4 }}>{t.searchKeyNote}</p>
      <div className="nx-input-row">
        <input className="nx-input" placeholder={t.searchPlaceholder} value={query}
          onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === "Enter" && runSearch()} />
      </div>
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={runSearch} disabled={busy || !query.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Search size={15} />} {t.searchBtn}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}

      {answer && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head">
            <h5>{t.resultLabel}</h5>
            <span className="nx-chip" style={{ pointerEvents: "none" }}>{isLive ? t.liveData : t.aiKnowledge}</span>
          </div>
          <div className="nx-result-box">{answer}</div>
        </div>
      )}
      {results.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-section-label">{t.sources}</div>
          {results.map((r, i) => (
            <a key={i} href={r.url} target="_blank" rel="noreferrer" className="nx-source-link">
              <span className="nx-source-idx">{i + 1}</span>
              <span>{r.title || r.url}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---- Feature: News Fetch System ---- */
function NewsPanel({ t, callAI, searchApiKey }) {
  const [topic, setTopic] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [summary, setSummary] = useState("");
  const [results, setResults] = useState([]);
  const [isLive, setIsLive] = useState(false);

  async function fetchNews() {
    if (!topic.trim() || busy) return;
    setBusy(true); setError(""); setSummary(""); setResults([]);
    try {
      const sr = await tavilySearch(`latest news ${topic}`, searchApiKey, { topic: "news", maxResults: 6 });
      if (sr.live) {
        setIsLive(true);
        setResults(sr.results);
        const context = sr.results.map((r, i) => `[${i + 1}] ${r.title}\n${r.content}\nURL: ${r.url}`).join("\n\n");
        const out = await callAI([
          { role: "system", content: "You are Novexa AI's news desk. Turn the given live news search results into a short, well-organized news briefing with bullet points, citing source numbers like [1], [2]. Match the user's language style." },
          { role: "user", content: `Topic: ${topic}\n\nResults:\n${context}` },
        ]);
        setSummary(out);
      } else {
        setIsLive(false);
        const out = await callAI([
          { role: "system", content: "You are Novexa AI. No live news search key is configured. Give a brief, honest answer from your own knowledge about this topic, and clearly note this may not reflect today's latest news." },
          { role: "user", content: `What's happening with: ${topic}` },
        ]);
        setSummary(out);
      }
    } catch (e) { setError(e.message || t.networkErr); }
    setBusy(false);
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolNews}</h4>
      <p style={{ color: "var(--text-muted)", fontSize: 12.5, marginTop: -4 }}>{t.searchKeyNote}</p>
      <div className="nx-input-row">
        <input className="nx-input" placeholder={t.newsTopicPlaceholder} value={topic}
          onChange={(e) => setTopic(e.target.value)} onKeyDown={(e) => e.key === "Enter" && fetchNews()} />
      </div>
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={fetchNews} disabled={busy || !topic.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <Newspaper size={15} />} {t.getNews}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {summary && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head">
            <h5>{t.resultLabel}</h5>
            <span className="nx-chip" style={{ pointerEvents: "none" }}>{isLive ? t.liveData : t.aiKnowledge}</span>
          </div>
          <div className="nx-result-box">{summary}</div>
        </div>
      )}
      {results.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-section-label">{t.sources}</div>
          {results.map((r, i) => (
            <a key={i} href={r.url} target="_blank" rel="noreferrer" className="nx-source-link">
              <span className="nx-source-idx">{i + 1}</span>
              <span>{r.title || r.url}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---- Feature: Weather Information System (location-based, Open-Meteo, no key required) ---- */
function WeatherPanel({ t }) {
  const [city, setCity] = useState("");
  const [busy, setBusy] = useState(false);
  const [locating, setLocating] = useState(false);
  const [error, setError] = useState("");
  const [weather, setWeather] = useState(null);

  const WEATHER_CODES = {
    0: "Clear sky", 1: "Mostly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog", 51: "Light drizzle", 53: "Drizzle", 55: "Dense drizzle",
    61: "Light rain", 63: "Rain", 65: "Heavy rain", 71: "Light snow", 73: "Snow", 75: "Heavy snow",
    80: "Rain showers", 81: "Rain showers", 82: "Violent rain showers",
    95: "Thunderstorm", 96: "Thunderstorm w/ hail", 99: "Severe thunderstorm",
  };

  async function fetchByCoords(lat, lon, label) {
    setBusy(true); setError(""); setWeather(null);
    try {
      const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code&timezone=auto`);
      if (!res.ok) throw new Error(`Weather error (${res.status})`);
      const data = await res.json();
      const c = data.current || {};
      setWeather({
        place: label,
        temp: c.temperature_2m, feels: c.apparent_temperature,
        humidity: c.relative_humidity_2m, wind: c.wind_speed_10m,
        condition: WEATHER_CODES[c.weather_code] || "—",
      });
    } catch (e) { setError(e.message || t.networkErr); }
    setBusy(false);
  }

  async function searchCity() {
    if (!city.trim() || busy) return;
    setBusy(true); setError(""); setWeather(null);
    try {
      const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`);
      if (!geoRes.ok) throw new Error(`Location error (${geoRes.status})`);
      const geo = await geoRes.json();
      const loc = geo.results && geo.results[0];
      if (!loc) { setError(t.noResultsFound); setBusy(false); return; }
      setBusy(false);
      await fetchByCoords(loc.latitude, loc.longitude, `${loc.name}${loc.country ? ", " + loc.country : ""}`);
    } catch (e) { setError(e.message || t.networkErr); setBusy(false); }
  }

  function useMyLocation() {
    if (!navigator.geolocation) { setError("Geolocation not supported in this browser."); return; }
    setLocating(true); setError("");
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        setLocating(false);
        await fetchByCoords(pos.coords.latitude, pos.coords.longitude, t.useMyLocation);
      },
      () => { setLocating(false); setError("Couldn't access your location."); },
      { timeout: 8000 }
    );
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolWeather}</h4>
      <div className="nx-input-row">
        <input className="nx-input" placeholder={t.weatherCityPlaceholder} value={city}
          onChange={(e) => setCity(e.target.value)} onKeyDown={(e) => e.key === "Enter" && searchCity()} />
      </div>
      <div className="nx-mode-row" style={{ marginTop: 10 }}>
        <button className="nx-btn nx-btn-primary" onClick={searchCity} disabled={busy || !city.trim()}>
          {busy ? <Loader2 size={15} className="nx-spin" /> : <Cloud size={15} />} {t.getWeather}
        </button>
        <button className="nx-btn nx-btn-ghost" onClick={useMyLocation} disabled={locating}>
          {locating ? <Loader2 size={15} className="nx-spin" /> : <MapPin size={15} />} {locating ? t.locating : t.useMyLocation}
        </button>
      </div>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {weather && (
        <div className="nx-weather-card">
          <div className="nx-weather-place"><MapPin size={14} /> {weather.place}</div>
          <div className="nx-weather-temp">{Math.round(weather.temp)}°C</div>
          <div className="nx-weather-cond">{weather.condition}</div>
          <div className="nx-weather-grid">
            <div><span>{t.feelsLike}</span><b>{Math.round(weather.feels)}°C</b></div>
            <div><span>{t.humidity}</span><b>{weather.humidity}%</b></div>
            <div><span>{t.wind}</span><b>{weather.wind} km/h</b></div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---- Feature: Fact Checking using web data ---- */
function FactCheckPanel({ t, callAI, searchApiKey }) {
  const [claim, setClaim] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [verdict, setVerdict] = useState(null); // { label, explanation }
  const [results, setResults] = useState([]);
  const [isLive, setIsLive] = useState(false);

  async function check() {
    if (!claim.trim() || busy) return;
    setBusy(true); setError(""); setVerdict(null); setResults([]);
    try {
      const sr = await tavilySearch(claim, searchApiKey, { topic: "general", maxResults: 6 });
      let context = "";
      if (sr.live) {
        setIsLive(true);
        setResults(sr.results);
        context = sr.results.map((r, i) => `[${i + 1}] ${r.title}\n${r.content}\nURL: ${r.url}`).join("\n\n");
      } else {
        setIsLive(false);
      }
      const sys = "You are Novexa AI's fact-checking assistant. Evaluate the claim using the provided web evidence (if any) or your own knowledge. " +
        "Respond in this exact format on the first line: VERDICT: TRUE or VERDICT: FALSE or VERDICT: UNCLEAR — then a blank line, then a concise explanation citing source numbers like [1] where applicable.";
      const userMsg = context
        ? `Claim: "${claim}"\n\nWeb evidence:\n${context}`
        : `Claim: "${claim}"\n\n(No live web evidence available — use your own knowledge and be explicit about uncertainty.)`;
      const out = await callAI([{ role: "system", content: sys }, { role: "user", content: userMsg }]);
      const m = out.match(/VERDICT:\s*(TRUE|FALSE|UNCLEAR)/i);
      const label = m ? m[1].toUpperCase() : "UNCLEAR";
      const explanation = out.replace(/VERDICT:\s*(TRUE|FALSE|UNCLEAR)/i, "").trim();
      setVerdict({ label, explanation });
    } catch (e) { setError(e.message || t.networkErr); }
    setBusy(false);
  }

  const verdictLabel = verdict?.label === "TRUE" ? t.trueLabel : verdict?.label === "FALSE" ? t.falseLabel : t.unclearLabel;
  const verdictColor = verdict?.label === "TRUE" ? "#16a085" : verdict?.label === "FALSE" ? "#e74c3c" : "#f39c12";

  return (
    <div className="nx-study-card">
      <h4>{t.toolFactCheck}</h4>
      <p style={{ color: "var(--text-muted)", fontSize: 12.5, marginTop: -4 }}>{t.searchKeyNote}</p>
      <textarea className="nx-textarea-box" style={{ minHeight: 100 }} placeholder={t.factCheckPlaceholder} value={claim} onChange={(e) => setClaim(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={check} disabled={busy || !claim.trim()}>
        {busy ? <Loader2 size={15} className="nx-spin" /> : <ShieldCheck size={15} />} {t.checkFact}
      </button>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}
      {verdict && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head">
            <h5>{t.verdict}: <span style={{ color: verdictColor }}>{verdictLabel}</span></h5>
            <span className="nx-chip" style={{ pointerEvents: "none" }}>{isLive ? t.liveData : t.aiKnowledge}</span>
          </div>
          <div className="nx-result-box">{verdict.explanation}</div>
        </div>
      )}
      {results.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-section-label">{t.sources}</div>
          {results.map((r, i) => (
            <a key={i} href={r.url} target="_blank" rel="noreferrer" className="nx-source-link">
              <span className="nx-source-idx">{i + 1}</span>
              <span>{r.title || r.url}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---- Feature: Data Analysis Tool ---- */
function parseDelimited(text) {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (!lines.length) return null;
  const headers = lines[0].split(",").map((h) => h.trim());
  const rows = lines.slice(1).map((l) => l.split(",").map((c) => c.trim()));
  return { headers, rows };
}

function DataAnalysisPanel({ t, callAI, dataset, setDataset }) {
  const [raw, setRaw] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [insights, setInsights] = useState("");
  const fileInputRef = useRef(null);

  function loadDataset(parsed) {
    setDataset(parsed);
    setInsights("");
  }

  function handlePaste() {
    setError("");
    const parsed = parseDelimited(raw);
    if (!parsed) { setError(t.noResultsFound); return; }
    loadDataset(parsed);
  }

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setError("");
    try {
      const ext = file.name.split(".").pop().toLowerCase();
      if (ext === "csv" || ext === "txt") {
        const text = await file.text();
        const parsed = parseDelimited(text);
        if (!parsed) { setError(t.noResultsFound); return; }
        loadDataset(parsed);
      } else if (ext === "json") {
        const text = await file.text();
        const json = JSON.parse(text);
        const arr = Array.isArray(json) ? json : [json];
        const headers = Object.keys(arr[0] || {});
        const rows = arr.map((o) => headers.map((h) => String(o[h] ?? "")));
        loadDataset({ headers, rows });
      } else if (ext === "xlsx" || ext === "xls") {
        const arrayBuffer = await file.arrayBuffer();
        const wb = XLSX.read(arrayBuffer, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" });
        const headers = (json[0] || []).map((h) => String(h));
        const rows = json.slice(1).map((r) => r.map((c) => String(c)));
        loadDataset({ headers, rows });
      } else {
        setError(t.unsupportedFile);
      }
    } catch (e2) { setError(e2.message || t.unsupportedFile); }
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  function computeStats() {
    if (!dataset) return null;
    const { headers, rows } = dataset;
    return headers.map((h, idx) => {
      const colVals = rows.map((r) => r[idx]).filter((v) => v !== undefined && v !== "");
      const numeric = colVals.map((v) => parseFloat(v)).filter((v) => !isNaN(v));
      if (numeric.length > 0 && numeric.length === colVals.length) {
        const sum = numeric.reduce((a, b) => a + b, 0);
        return { name: h, type: "number", count: numeric.length, min: Math.min(...numeric), max: Math.max(...numeric), avg: (sum / numeric.length).toFixed(2) };
      }
      return { name: h, type: "text", count: colVals.length, unique: new Set(colVals).size };
    });
  }

  async function analyze() {
    if (!dataset || busy) return;
    setBusy(true); setError(""); setInsights("");
    try {
      const stats = computeStats();
      const sample = dataset.rows.slice(0, 12).map((r) => r.join(", ")).join("\n");
      const out = await callAI([
        { role: "system", content: "You are Novexa AI's data analyst. Given column statistics and a data sample, provide clear, actionable insights: trends, outliers, correlations worth investigating, and a short recommendation. Be concise and use bullet points." },
        { role: "user", content: `Columns: ${dataset.headers.join(", ")}\n\nStats:\n${JSON.stringify(stats, null, 2)}\n\nSample rows:\n${sample}` },
      ]);
      setInsights(out);
    } catch (e) { setError(e.message || t.networkErr); }
    setBusy(false);
  }

  const stats = computeStats();

  return (
    <div className="nx-study-card">
      <h4>{t.toolDataAnalysis}</h4>
      <p style={{ color: "var(--text-muted)", fontSize: 12.5, marginTop: -4 }}>{t.dataInputCsv}</p>
      <textarea className="nx-textarea-box" style={{ minHeight: 110, fontFamily: "monospace", fontSize: 12.5 }}
        placeholder={"name,age,city\nAman,28,Delhi\nRiya,24,Mumbai"} value={raw} onChange={(e) => setRaw(e.target.value)} />
      <div className="nx-mode-row" style={{ marginTop: 10 }}>
        <button className="nx-btn nx-btn-ghost" onClick={handlePaste} disabled={!raw.trim()}>
          <Database size={15} /> {t.uploadData.replace(t.uploadData.split(" ")[0], "Load")}
        </button>
        <button className="nx-btn nx-btn-ghost" onClick={() => fileInputRef.current?.click()}>
          <UploadCloud size={15} /> {t.uploadData}
        </button>
        <input ref={fileInputRef} type="file" accept=".csv,.txt,.json,.xlsx,.xls" hidden onChange={handleFile} />
      </div>
      {error && <div className="nx-banner" style={{ marginTop: 10 }}><AlertCircle size={14} /><span>{error}</span></div>}

      {dataset && (
        <>
          <div className="nx-section-label" style={{ marginTop: 16 }}>{t.dataSummary} · {t.rowsLabel}: {dataset.rows.length} · {t.colsLabel}: {dataset.headers.length}</div>
          <div className="nx-table-wrap">
            <table className="nx-data-table">
              <thead><tr>{dataset.headers.map((h) => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>
                {dataset.rows.slice(0, 8).map((r, i) => (
                  <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="nx-stat-grid">
            {stats.map((s) => (
              <div key={s.name} className="nx-stat-card">
                <div className="nx-stat-name">{s.name}</div>
                {s.type === "number" ? (
                  <div className="nx-stat-vals">min {s.min} · max {s.max} · avg {s.avg}</div>
                ) : (
                  <div className="nx-stat-vals">{s.unique} unique values</div>
                )}
              </div>
            ))}
          </div>
          <button className="nx-btn nx-btn-primary" style={{ marginTop: 12 }} onClick={analyze} disabled={busy}>
            {busy ? <Loader2 size={15} className="nx-spin" /> : <TrendingUp size={15} />} {t.analyzeData}
          </button>
        </>
      )}

      {insights && (
        <div style={{ marginTop: 14 }}>
          <div className="nx-result-head"><h5>{t.aiInsights}</h5><CopyResultButton text={insights} t={t} /></div>
          <div className="nx-result-box">{insights}</div>
        </div>
      )}
    </div>
  );
}

/* ---- Feature: Charts & Graph Generator (lightweight inline SVG, no extra deps) ---- */
function SvgChart({ type, labels, values }) {
  const W = 560, H = 280, PAD = 36;
  const max = Math.max(...values, 1);
  const colors = ["#6d4dfb", "#16a085", "#f39c12", "#e74c3c", "#3498db", "#9b59b6", "#1abc9c", "#e67e22"];

  if (type === "pie") {
    const total = values.reduce((a, b) => a + b, 0) || 1;
    let angle = 0;
    const cx = W / 2, cy = H / 2, r = Math.min(W, H) / 2 - 20;
    const slices = values.map((v, i) => {
      const frac = v / total;
      const start = angle;
      const end = angle + frac * Math.PI * 2;
      angle = end;
      const x1 = cx + r * Math.cos(start), y1 = cy + r * Math.sin(start);
      const x2 = cx + r * Math.cos(end), y2 = cy + r * Math.sin(end);
      const large = end - start > Math.PI ? 1 : 0;
      return { d: `M${cx},${cy} L${x1},${y1} A${r},${r} 0 ${large} 1 ${x2},${y2} Z`, color: colors[i % colors.length] };
    });
    return (
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H}>
        {slices.map((s, i) => <path key={i} d={s.d} fill={s.color} stroke="var(--surface)" strokeWidth="1.5" />)}
      </svg>
    );
  }

  const barW = (W - PAD * 2) / values.length;
  if (type === "line") {
    const pts = values.map((v, i) => {
      const x = PAD + i * barW + barW / 2;
      const y = H - PAD - (v / max) * (H - PAD * 2);
      return `${x},${y}`;
    });
    return (
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H}>
        <line x1={PAD} y1={H - PAD} x2={W - PAD} y2={H - PAD} stroke="var(--border)" />
        <polyline points={pts.join(" ")} fill="none" stroke="#6d4dfb" strokeWidth="2.5" />
        {values.map((v, i) => {
          const [x, y] = pts[i].split(",");
          return <circle key={i} cx={x} cy={y} r="4" fill="#6d4dfb" />;
        })}
        {labels.map((l, i) => (
          <text key={i} x={PAD + i * barW + barW / 2} y={H - 10} fontSize="10" textAnchor="middle" fill="var(--text-muted)">{l}</text>
        ))}
      </svg>
    );
  }

  // bar (default)
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H}>
      <line x1={PAD} y1={H - PAD} x2={W - PAD} y2={H - PAD} stroke="var(--border)" />
      {values.map((v, i) => {
        const h = (v / max) * (H - PAD * 2);
        const x = PAD + i * barW + barW * 0.15;
        const y = H - PAD - h;
        return <rect key={i} x={x} y={y} width={barW * 0.7} height={h} fill={colors[i % colors.length]} rx="3" />;
      })}
      {labels.map((l, i) => (
        <text key={i} x={PAD + i * barW + barW / 2} y={H - 10} fontSize="10" textAnchor="middle" fill="var(--text-muted)">{l}</text>
      ))}
    </svg>
  );
}

function ChartGeneratorPanel({ t, dataset }) {
  const [chartType, setChartType] = useState("bar");
  const [manual, setManual] = useState("");
  const [chartData, setChartData] = useState(null);

  function buildFromDataset() {
    if (!dataset || dataset.headers.length < 2) return;
    const labels = dataset.rows.slice(0, 10).map((r) => r[0]);
    const values = dataset.rows.slice(0, 10).map((r) => parseFloat(r[1]) || 0);
    setChartData({ labels, values });
  }

  function buildFromManual() {
    const parsed = parseDelimited(manual);
    if (!parsed) return;
    const labels = parsed.rows.map((r) => r[0]);
    const values = parsed.rows.map((r) => parseFloat(r[1]) || 0);
    setChartData({ labels, values });
  }

  return (
    <div className="nx-study-card">
      <h4>{t.toolCharts}</h4>
      <p style={{ color: "var(--text-muted)", fontSize: 12.5, marginTop: -4 }}>{t.chartFromData}</p>

      <div className="nx-section-label">{t.chartType}</div>
      <div className="nx-mode-row">
        <button className={`nx-chip${chartType === "bar" ? " active" : ""}`} onClick={() => setChartType("bar")}>{t.barChart}</button>
        <button className={`nx-chip${chartType === "line" ? " active" : ""}`} onClick={() => setChartType("line")}>{t.lineChart}</button>
        <button className={`nx-chip${chartType === "pie" ? " active" : ""}`} onClick={() => setChartType("pie")}>{t.pieChart}</button>
      </div>

      <div className="nx-mode-row" style={{ marginTop: 10 }}>
        <button className="nx-btn nx-btn-ghost" onClick={buildFromDataset} disabled={!dataset}>
          <Database size={15} /> {t.toolDataAnalysis}
        </button>
      </div>

      <textarea className="nx-textarea-box" style={{ minHeight: 90, fontFamily: "monospace", fontSize: 12.5, marginTop: 10 }}
        placeholder={t.chartDataPlaceholder} value={manual} onChange={(e) => setManual(e.target.value)} />
      <button className="nx-btn nx-btn-primary" style={{ marginTop: 10 }} onClick={buildFromManual} disabled={!manual.trim()}>
        <BarChart3 size={15} /> {t.generateChart}
      </button>

      {chartData && (
        <div className="nx-chart-box">
          <SvgChart type={chartType} labels={chartData.labels} values={chartData.values} />
        </div>
      )}
    </div>
  );
}

/* ===================================================================== */
/* ========================= v1.4: FILE CHAT ========================== */
/* ===================================================================== */

function FileChatDashboard({ t, callAI, sidebarOpen, setSidebarOpen }) {
  const [files, setFiles] = useState([]); // { id, name, kind, textContent }
  const [uploadBusy, setUploadBusy] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [messages, setMessages] = useState([]); // { id, role, content }
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const fileInputRef = useRef(null);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, sending]);

  async function handleFiles(fileList) {
    const list = Array.from(fileList || []);
    setUploadError("");
    for (const file of list) {
      if (file.size > 15 * 1024 * 1024) { setUploadError(t.fileTooLarge); continue; }
      const ext = file.name.split(".").pop().toLowerCase();
      let kind = null;
      if (ext === "pdf") kind = "pdf";
      else if (ext === "doc" || ext === "docx") kind = "docx";
      else if (ext === "txt") kind = "txt";
      if (!kind) { setUploadError(t.unsupportedFile); continue; }

      setUploadBusy(true);
      try {
        const doc = { id: uid(), name: file.name, kind, textContent: "" };
        if (kind === "pdf") {
          doc.textContent = await extractPdfText(file);
        } else if (kind === "docx") {
          const arrayBuffer = await file.arrayBuffer();
          const result = await mammoth.extractRawText({ arrayBuffer });
          doc.textContent = result.value || "";
        } else if (kind === "txt") {
          doc.textContent = await file.text();
        }
        setFiles((prev) => [...prev, doc]);
      } catch (e) {
        setUploadError(e.message || t.unsupportedFile);
      } finally {
        setUploadBusy(false);
      }
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  function removeFile(id) { setFiles((prev) => prev.filter((f) => f.id !== id)); }
  function clearAll() { setFiles([]); setMessages([]); }

  async function send() {
    const text = draft.trim();
    if (!text || sending || files.length === 0) return;
    const userMsg = { id: uid(), role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setDraft("");
    setSending(true);
    try {
      const sys = "You are Novexa AI's File Chat assistant. Answer the user's question using ONLY the content of the uploaded files provided below. " +
        "If multiple files are present, synthesize across all of them and mention which file information came from when relevant. Be clear, accurate and well structured. Reply in the user's language (English/Hindi/Hinglish).";
      const textBlock = files.map((f) => `--- File: ${f.name} ---\n${(f.textContent || "").slice(0, 9000)}`).join("\n\n");

      const reply = await callAI([
        { role: "system", content: `${sys}\n\nUploaded files:\n${textBlock}` },
        ...messages.map((m) => ({ role: m.role, content: m.content })),
        { role: "user", content: text },
      ]);
      setMessages((prev) => [...prev, { id: uid(), role: "assistant", content: reply || "…" }]);
    } catch (e) {
      setMessages((prev) => [...prev, { id: uid(), role: "assistant", content: `⚠️ ${e.message || "Error"}` }]);
    }
    setSending(false);
  }

  function kindIcon(kind) {
    if (kind === "pdf") return <FileText size={14} />;
    if (kind === "docx") return <FileType2 size={14} />;
    return <FileText size={14} />;
  }

  return (
    <>
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.filesTitle}</div>
          <div className="nx-topbar-sub">{files.length} {t.filesSelected}</div>
        </div>
        {files.length > 0 && (
          <button className="nx-btn-icon" title={t.clearAll} onClick={clearAll}><Trash size={16} /></button>
        )}
      </div>

      <div className="nx-filechat-layout">
        <div className="nx-filechat-side">
          <p style={{ color: "var(--text-muted)", fontSize: 12.5 }}>{t.uploadMultiHint}</p>
          <button className="nx-upload-zone" onClick={() => fileInputRef.current?.click()}>
            <UploadCloud size={22} />
            <span>{t.uploadData}</span>
          </button>
          <input ref={fileInputRef} type="file" accept=".pdf,.doc,.docx,.txt" multiple hidden
            onChange={(e) => handleFiles(e.target.files)} />
          {uploadBusy && <div className="nx-uploading"><Loader2 size={14} className="nx-spin" /> {t.processing}</div>}
          {uploadError && <div className="nx-banner" style={{ marginTop: 8 }}><AlertCircle size={14} /><span>{uploadError}</span></div>}

          <div className="nx-filechat-list">
            {files.length === 0 && <div className="nx-empty-chats">{t.noFilesYet}</div>}
            {files.map((f) => (
              <div key={f.id} className="nx-filechat-item">
                {kindIcon(f.kind)}
                <span className="nx-filechat-name">{f.name}</span>
                <button className="nx-btn-icon" onClick={() => removeFile(f.id)}><X size={13} /></button>
              </div>
            ))}
          </div>
        </div>

        <div className="nx-filechat-main">
          <div className="nx-filechat-messages">
            {messages.length === 0 && (
              <div className="nx-empty-state">
                <FilePlus2 size={40} />
                <h2>{t.filesChatTitle}</h2>
                <p>{t.uploadMultiHint}</p>
              </div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={`nx-msg-row ${m.role === "user" ? "user" : ""}`}>
                <div className={`nx-msg-bubble ${m.role === "user" ? "user" : "ai"}`}>{m.content}</div>
              </div>
            ))}
            {sending && (
              <div className="nx-msg-row">
                <div className="nx-msg-bubble ai"><Loader2 size={14} className="nx-spin" /> {t.thinking}…</div>
              </div>
            )}
            <div ref={endRef} />
          </div>
          <div className="nx-composer">
            <textarea
              className="nx-composer-input"
              placeholder={files.length === 0 ? t.noFilesYet : t.askAboutFiles}
              value={draft}
              disabled={files.length === 0}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            />
            <button className="nx-btn-icon nx-send-btn" onClick={send} disabled={sending || !draft.trim() || files.length === 0}>
              {sending ? <Loader2 size={17} className="nx-spin" /> : <Send size={17} />}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

/* ============================== v1.5: AI Voice Call Dashboard (Features 61-70) ============================== */
function VoiceCallDashboard({ t, callAI, voiceGender, voiceLangPref, sidebarOpen, setSidebarOpen }) {
  const [callTab, setCallTab] = useState("call");     // "call" | "history"
  const [callState, setCallState] = useState("idle"); // "idle" | "connecting" | "active" | "ended"
  const [aiState, setAiState] = useState("idle");     // "idle" | "speaking" | "listening"
  const [transcript, setTranscript] = useState([]);   // {role, text, ts}
  const [liveText, setLiveText] = useState("");        // currently spoken/heard text
  const [callTimer, setCallTimer] = useState(0);
  const [callHistory, setCallHistory] = useState([]);
  const [callError, setCallError] = useState("");
  const [continuousMode, setContinuousMode] = useState(true);
  const [callLang, setCallLang] = useState(voiceLangPref === "hi" ? "hi" : "en"); // "en"|"hi"|"hinglish"
  const [voiceSpeed, setVoiceSpeed] = useState("normal"); // "slow"|"normal"|"fast"
  const [voiceQuality, setVoiceQuality] = useState("normal"); // "normal"|"hd"
  const [isMuted, setIsMuted] = useState(false);

  const recognitionRef = useRef(null);
  const utteranceRef = useRef(null);
  const timerRef = useRef(null);
  const callStartRef = useRef(null);
  const isCallActiveRef = useRef(false);
  const continuousModeRef = useRef(continuousMode);
  const callLangRef = useRef(callLang);
  const voiceSpeedRef = useRef(voiceSpeed);
  const isMutedRef = useRef(isMuted);

  // Keep refs in sync
  useEffect(() => { continuousModeRef.current = continuousMode; }, [continuousMode]);
  useEffect(() => { callLangRef.current = callLang; }, [callLang]);
  useEffect(() => { voiceSpeedRef.current = voiceSpeed; }, [voiceSpeed]);
  useEffect(() => { isMutedRef.current = isMuted; }, [isMuted]);

  // Load call history from storage
  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("voice-call-history");
        if (res && res.value) setCallHistory(JSON.parse(res.value));
      } catch (e) {}
    })();
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopEverything();
    };
  }, []);

  function stopEverything() {
    recognitionRef.current?.stop();
    window.speechSynthesis?.cancel();
    clearInterval(timerRef.current);
    isCallActiveRef.current = false;
  }

  function getLangCode() {
    if (callLangRef.current === "hi") return "hi-IN";
    if (callLangRef.current === "hinglish") return "hi-IN";
    return "en-US";
  }

  function getRateForSpeed() {
    const s = voiceSpeedRef.current;
    if (s === "slow") return 0.75;
    if (s === "fast") return 1.35;
    return 1.0;
  }

  function speakText(text, onDone) {
    if (!window.speechSynthesis || isMutedRef.current) {
      onDone && onDone();
      return;
    }
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    const langCode = getLangCode();
    const voices = window.speechSynthesis.getVoices();
    const genderKw = voiceGender === "female"
      ? ["female", "zira", "samantha", "victoria", "karen", "moira", "veena"]
      : ["male", "david", "mark", "daniel", "alex", "jorge"];

    let chosen = voices.find(v => v.lang.startsWith(langCode.slice(0, 2)) && genderKw.some(k => v.name.toLowerCase().includes(k)));
    if (!chosen) chosen = voices.find(v => v.lang.startsWith(langCode.slice(0, 2)));
    if (chosen) utt.voice = chosen;

    utt.lang = langCode;
    utt.rate = getRateForSpeed();
    utt.pitch = voiceGender === "female" ? 1.1 : 0.9;

    utteranceRef.current = utt;
    utt.onend = () => { if (isCallActiveRef.current) onDone && onDone(); };
    utt.onerror = () => { if (isCallActiveRef.current) onDone && onDone(); };
    window.speechSynthesis.speak(utt);
  }

  function startListeningCycle() {
    if (!isCallActiveRef.current) return;
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setCallError(t.speechNotSupported); return; }

    const rec = new SR();
    recognitionRef.current = rec;
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = getLangCode();
    rec.maxAlternatives = 1;

    rec.onstart = () => {
      if (!isCallActiveRef.current) { rec.stop(); return; }
      setAiState("listening");
      setLiveText(t.aiListening);
    };

    rec.onresult = (e) => {
      let interim = "";
      let final = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript;
        else interim += e.results[i][0].transcript;
      }
      setLiveText(interim || final || t.aiListening);
      if (final) {
        const userText = final.trim();
        setTranscript(prev => [...prev, { role: "user", text: userText, ts: Date.now() }]);
        setLiveText("");
        rec.stop();
        handleUserSpeech(userText);
      }
    };

    rec.onerror = (e) => {
      if (e.error === "not-allowed") {
        setCallError(t.micPermissionErr);
        endCallFn();
        return;
      }
      // On no-speech or network error, retry if still active
      if (isCallActiveRef.current && continuousModeRef.current) {
        setTimeout(() => startListeningCycle(), 800);
      } else {
        setAiState("idle");
        setLiveText(t.tapToSpeak);
      }
    };

    rec.onend = () => {
      // If no result was captured and call is still active but NOT in a speech cycle,
      // restart in continuous mode
    };

    rec.start();
  }

  async function handleUserSpeech(text) {
    if (!isCallActiveRef.current || !text) return;
    setAiState("speaking");
    setLiveText(t.aiSpeaking);

    const langInstr = callLangRef.current === "hi"
      ? " Always reply in Hindi only."
      : callLangRef.current === "hinglish"
      ? " Reply in Hinglish (mix of Hindi and English naturally)."
      : " Reply in English.";

    const sysMsgs = [
      {
        role: "system",
        content: "You are Novexa AI in voice call mode. Give short, conversational, natural-sounding responses of 1-3 sentences. No bullet points, no markdown, no lists — just natural speech." + langInstr,
      },
    ];
    const convo = transcript
      .slice(-10)
      .map(m => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
    convo.push({ role: "user", content: text });

    try {
      const reply = await callAI([...sysMsgs, ...convo]);
      const aiText = (reply || "").trim();
      setTranscript(prev => [...prev, { role: "assistant", text: aiText, ts: Date.now() }]);
      setLiveText(aiText);

      speakText(aiText, () => {
        if (!isCallActiveRef.current) return;
        setLiveText("");
        if (continuousModeRef.current) {
          setTimeout(() => startListeningCycle(), 400);
        } else {
          setAiState("idle");
          setLiveText(t.tapToSpeak);
        }
      });
    } catch (err) {
      setCallError(err.message || "Error getting AI response");
      setAiState("idle");
      setLiveText(t.tapToSpeak);
    }
  }

  function startCall() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setCallError(t.speechNotSupported); return; }

    setCallError("");
    setCallState("connecting");
    setTranscript([]);
    setLiveText(t.connecting);

    setTimeout(() => {
      if (!isCallActiveRef.current) {
        isCallActiveRef.current = true;
        setCallState("active");
        callStartRef.current = Date.now();
        setCallTimer(0);

        timerRef.current = setInterval(() => {
          setCallTimer(Math.floor((Date.now() - callStartRef.current) / 1000));
        }, 1000);

        const greeting = callLangRef.current === "hi"
          ? "नमस्ते! मैं Novexa AI हूं। आज आपकी कैसे मदद करूं?"
          : callLangRef.current === "hinglish"
          ? "Hello! Main Novexa AI hun. Aaj main aapki kaise help kar sakta hun?"
          : "Hello! I'm Novexa AI. How can I help you today?";

        const greetMsg = { role: "assistant", text: greeting, ts: Date.now() };
        setTranscript([greetMsg]);
        setAiState("speaking");
        setLiveText(greeting);

        speakText(greeting, () => {
          if (!isCallActiveRef.current) return;
          if (continuousModeRef.current) {
            setTimeout(() => startListeningCycle(), 300);
          } else {
            setAiState("idle");
            setLiveText(t.tapToSpeak);
          }
        });
      }
    }, 900);
  }

  function endCallFn() {
    if (!isCallActiveRef.current && callState === "idle") return;
    stopEverything();

    const duration = callStartRef.current ? Math.floor((Date.now() - callStartRef.current) / 1000) : 0;
    const currentTranscript = transcript;

    if (duration > 3 && currentTranscript.length > 0) {
      const session = {
        id: uid(),
        date: new Date().toLocaleString(),
        duration,
        turns: currentTranscript.length,
        preview: currentTranscript.slice(-1)[0]?.text || "",
        transcript: currentTranscript,
        lang: callLangRef.current,
      };
      setCallHistory(prev => {
        const updated = [session, ...prev].slice(0, 20);
        window.storage.set("voice-call-history", JSON.stringify(updated)).catch(() => {});
        return updated;
      });
    }

    setCallState("ended");
    setAiState("idle");
    setLiveText(t.callEnded);
    setCallTimer(0);

    setTimeout(() => {
      setCallState("idle");
      setLiveText("");
    }, 2500);
  }

  function interruptAI() {
    window.speechSynthesis?.cancel();
    recognitionRef.current?.stop();
    setAiState("idle");
    setLiveText(t.tapToSpeak);
  }

  function manualListen() {
    if (aiState === "speaking") { interruptAI(); return; }
    if (aiState === "listening") { recognitionRef.current?.stop(); setAiState("idle"); setLiveText(t.tapToSpeak); return; }
    startListeningCycle();
  }

  function clearHistory() {
    setCallHistory([]);
    window.storage.set("voice-call-history", "[]").catch(() => {});
  }

  function fmtDuration(secs) {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return m > 0 ? `${m}m ${s}s` : `${s}s`;
  }

  return (
    <>
      {/* Topbar */}
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.voiceCallTitle}</div>
          <div className="nx-topbar-sub">{callState === "active" ? t.callActive : t.voiceCallSubtitle}</div>
        </div>
        {callState === "active" && (
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <Signal size={14} style={{ color: "var(--brand)" }} />
            <span style={{ fontSize: 12, color: "var(--brand)", fontWeight: 700 }}>{fmtDuration(callTimer)}</span>
          </div>
        )}
      </div>

      {/* Tab Row */}
      {callState === "idle" && (
        <div className="nx-call-tab-row">
          <button className={`nx-call-tab${callTab === "call" ? " active" : ""}`} onClick={() => setCallTab("call")}>
            <PhoneCall size={14} /> {t.voiceCallTitle}
          </button>
          <button className={`nx-call-tab${callTab === "history" ? " active" : ""}`} onClick={() => setCallTab("history")}>
            <History size={14} /> {t.callHistory}
          </button>
        </div>
      )}

      {/* ---- CALL SCREEN (active) ---- */}
      {callState !== "idle" ? (
        <div className="nx-call-screen">
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "16px 24px", gap: 0 }}>
            {/* Orb */}
            <div className="nx-call-orb-wrap">
              {callState === "active" && <>
                <div className="nx-call-orb-ring" />
                <div className="nx-call-orb-ring" />
                <div className="nx-call-orb-ring" />
              </>}
              <div className={`nx-call-orb ${aiState === "speaking" ? "speaking" : aiState === "listening" ? "listening" : "idle"}`}>
                <NovexaMark size={52} />
              </div>
            </div>

            {/* Name + Timer */}
            <div className="nx-call-name">Novexa AI</div>
            {callState === "active" && (
              <div className="nx-call-timer">{fmtDuration(callTimer)}</div>
            )}
            {callState === "connecting" && (
              <div className="nx-call-status-label" style={{ marginTop: 4 }}>
                <Loader2 size={13} className="nx-spin" style={{ display: "inline", verticalAlign: "middle", marginRight: 4 }} />
                {t.connecting}
              </div>
            )}
            {callState === "ended" && (
              <div className="nx-call-status-label" style={{ marginTop: 4 }}>{t.callEnded}</div>
            )}

            {/* Live transcript bubble */}
            {callState === "active" && (
              <div className={`nx-call-transcript-live${aiState === "speaking" ? " speaking" : aiState === "listening" ? " listening" : ""}`}>
                {aiState === "speaking" && (
                  <div className="nx-waveform" style={{ marginBottom: 6 }}>
                    <span /><span /><span /><span /><span /><span /><span />
                  </div>
                )}
                {aiState === "listening" && (
                  <div className="nx-waveform mic" style={{ marginBottom: 6 }}>
                    <span /><span /><span /><span /><span /><span /><span />
                  </div>
                )}
                <div style={{ fontSize: 13, lineHeight: 1.5 }}>
                  {liveText || (aiState === "idle" ? t.tapToSpeak : "")}
                </div>
              </div>
            )}

            {/* Error */}
            {callError && (
              <div className="nx-call-error">
                <AlertCircle size={14} /> <span>{callError}</span>
              </div>
            )}

            {/* Recent turn previews */}
            {callState === "active" && transcript.length > 1 && (
              <div style={{ width: "100%", maxWidth: 420, maxHeight: 120, overflowY: "auto", display: "flex", flexDirection: "column", gap: 4, marginTop: 8 }}>
                {transcript.slice(-4).map((m, i) => (
                  <div key={i} style={{
                    fontSize: 11.5, color: m.role === "user" ? "var(--text-muted)" : "var(--brand)",
                    textAlign: m.role === "user" ? "right" : "left",
                    padding: "3px 8px",
                    background: m.role === "user" ? "var(--surface-2)" : "var(--brand-soft)",
                    borderRadius: 8, maxWidth: "80%",
                    alignSelf: m.role === "user" ? "flex-end" : "flex-start",
                  }}>
                    <strong>{m.role === "user" ? t.youSpoke : t.aiResponded}:</strong> {m.text.slice(0, 80)}{m.text.length > 80 ? "…" : ""}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="nx-call-controls">
            {callState === "active" && (
              <>
                {/* Mute */}
                <button
                  className={`nx-call-btn secondary${isMuted ? " active" : ""}`}
                  onClick={() => setIsMuted(m => !m)}
                  title={isMuted ? "Unmute" : "Mute speaker"}
                  style={{ position: "relative" }}
                >
                  {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
                </button>

                {/* Mic / Listen button */}
                <button
                  className={`nx-call-btn${aiState === "listening" ? " active-mic" : " secondary"}`}
                  onClick={manualListen}
                  title={aiState === "listening" ? "Stop listening" : aiState === "speaking" ? "Interrupt AI" : "Speak"}
                >
                  {aiState === "listening" ? <MicOff size={22} /> : aiState === "speaking" ? <StopCircle size={22} /> : <Mic size={22} />}
                </button>

                {/* End Call */}
                <button className="nx-call-btn danger" onClick={endCallFn} title={t.endCall}>
                  <PhoneOff size={24} />
                </button>
              </>
            )}
            {callState === "connecting" && (
              <button className="nx-call-btn danger" onClick={endCallFn} title={t.endCall}>
                <PhoneOff size={24} />
              </button>
            )}
          </div>
        </div>
      ) : callTab === "history" ? (
        /* ---- CALL HISTORY TAB ---- */
        <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column", padding: "16px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <span style={{ fontSize: 13, fontWeight: 700 }}>{t.callHistory}</span>
            {callHistory.length > 0 && (
              <button className="nx-btn nx-btn-ghost" style={{ fontSize: 12, padding: "6px 12px" }} onClick={clearHistory}>
                <Trash2 size={13} /> {t.clearHistory}
              </button>
            )}
          </div>
          <div className="nx-call-history-list">
            {callHistory.length === 0 ? (
              <div className="nx-study-empty">
                <History size={36} />
                <p>{t.callHistoryEmpty}</p>
              </div>
            ) : callHistory.map(session => (
              <div key={session.id} className="nx-call-history-item">
                <div className="nx-call-history-header">
                  <span className="nx-call-history-date">{session.date}</span>
                  <span className="nx-call-history-dur">{fmtDuration(session.duration)}</span>
                </div>
                <div className="nx-call-history-turns">{session.turns} exchanges · {session.lang || "en"}</div>
                {session.transcript && session.transcript.length > 0 && (
                  <div className="nx-call-history-preview">
                    {session.transcript.slice(-2).map((m, i) => (
                      <span key={i} style={{ color: m.role === "user" ? "var(--text-muted)" : "var(--brand)" }}>
                        {m.role === "user" ? "You" : "AI"}: {m.text.slice(0, 60)}… 
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* ---- PRE-CALL SETUP ---- */
        <div className="nx-call-pre">
          <div className="nx-call-orb-wrap" style={{ marginBottom: 0 }}>
            <div className="nx-call-orb idle">
              <NovexaMark size={52} />
            </div>
          </div>

          <h2>{t.voiceCallTitle}</h2>
          <p>{t.voiceCallSubtitle}</p>

          {callError && (
            <div className="nx-call-error">
              <AlertCircle size={14} /> <span>{callError}</span>
            </div>
          )}

          {/* Options */}
          <div className="nx-call-options">
            {/* Language */}
            <div className="nx-call-option-row">
              <span className="nx-call-option-label"><Languages size={14} /> {t.voiceCallLang}</span>
              <div className="nx-pill-group">
                {[
                  { v: "en", label: t.callLangEnglish },
                  { v: "hi", label: t.callLangHindi },
                  { v: "hinglish", label: t.callLangHinglish },
                ].map(({ v, label }) => (
                  <button key={v} className={`nx-pill${callLang === v ? " active" : ""}`} onClick={() => setCallLang(v)}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Voice Speed */}
            <div className="nx-call-option-row" style={{ marginTop: 8 }}>
              <span className="nx-call-option-label"><Gauge size={14} /> {t.voiceSpeed}</span>
              <div className="nx-pill-group">
                {[
                  { v: "slow", label: t.speedSlow },
                  { v: "normal", label: t.speedNormal },
                  { v: "fast", label: t.speedFast },
                ].map(({ v, label }) => (
                  <button key={v} className={`nx-pill${voiceSpeed === v ? " active" : ""}`} onClick={() => setVoiceSpeed(v)}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Hands-free Mode */}
            <div className="nx-call-option-row" style={{ marginTop: 8 }}>
              <span className="nx-call-option-label" style={{ flexDirection: "column", alignItems: "flex-start", gap: 2 }}>
                <span style={{ display: "flex", alignItems: "center", gap: 6 }}><Radio size={14} /> {t.continuousMode}</span>
                <span style={{ fontSize: 11, color: "var(--text-muted)", fontWeight: 400 }}>{t.continuousModeHint}</span>
              </span>
              <label className="nx-toggle-switch">
                <input type="checkbox" checked={continuousMode} onChange={e => setContinuousMode(e.target.checked)} />
                <span className="nx-toggle-slider" />
              </label>
            </div>
          </div>

          {/* Start Call Button */}
          <button className="nx-call-start-btn" onClick={startCall}>
            <Phone size={28} />
            {t.startCall}
          </button>
        </div>
      )}
    </>
  );
}

/* ============================== v1.6: AI Image Generation Dashboard (Features 71-80) ============================== */
function ImageGenDashboard({ t, callAI, imageApiKey, imageModel, imageHistory, setImageHistory, sidebarOpen, setSidebarOpen, onSendToChat, analyzeImage, galleryCloudSync }) {
  const [prompt, setPrompt] = useState("");
  const [enhancedPrompt, setEnhancedPrompt] = useState("");
  const [activeStyle, setActiveStyle] = useState(IMAGE_STYLES[0].id);
  const [activeSize, setActiveSize] = useState(IMAGE_SIZES[0].id);
  const [activeCount, setActiveCount] = useState(1);
  const [generating, setGenerating] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [error, setError] = useState("");
  const [currentResult, setCurrentResult] = useState(null); // {prompt, style, size, images:[], mode, sourceThumb?}
  const [lightbox, setLightbox] = useState(null); // image object
  const promptRef = useRef(null);

  /* v1.7 Feature 71/72/73: which generator is active */
  const [genMode, setGenMode] = useState("text"); // "text" | "image" | "audio"

  /* v1.7 Feature 72: Image-to-Image state */
  const [uploadedImage, setUploadedImage] = useState(null); // {base64, mediaType, previewUrl, name}
  const [i2iStrength, setI2iStrength] = useState(0.65); // 0.1 (subtle) - 0.95 (dramatic)
  const [i2iDragging, setI2iDragging] = useState(false);
  const i2iInputRef = useRef(null);

  /* v1.7 Feature 73: Audio-to-Image state */
  const [audioLang, setAudioLang] = useState("en"); // "en" | "hi" | "hinglish"
  const [isRecording, setIsRecording] = useState(false);
  const [audioTranscript, setAudioTranscript] = useState("");
  const [optimizingVoice, setOptimizingVoice] = useState(false);
  const a2iRecognitionRef = useRef(null);

  /* v1.8 Feature 77: Advanced Image Generator — quality, negative prompt, speed mode, upscale */
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [negativePrompt, setNegativePrompt] = useState("");
  const [activeQuality, setActiveQuality] = useState(IMAGE_QUALITIES[0].id);
  const [speedMode, setSpeedMode] = useState("quality"); // "fast" | "quality"
  const [upscalingIdx, setUpscalingIdx] = useState(null);

  const displayPrompt = enhancedPrompt || prompt;
  const styleObj = IMAGE_STYLES.find(s => s.id === activeStyle) || IMAGE_STYLES[0];
  const baseSizeObj = IMAGE_SIZES.find(s => s.id === activeSize) || IMAGE_SIZES[0];
  const qualityObj = IMAGE_QUALITIES.find(q => q.id === activeQuality) || IMAGE_QUALITIES[0];
  const sizeObj = { ...baseSizeObj, w: Math.round(baseSizeObj.w * qualityObj.mult / 8) * 8, h: Math.round(baseSizeObj.h * qualityObj.mult / 8) * 8 };
  const speedObj = GEN_SPEED_MODES.find(s => s.id === speedMode) || GEN_SPEED_MODES[1];

  /* v1.7: stop any in-progress recording if the user navigates away */
  useEffect(() => {
    return () => { a2iRecognitionRef.current?.stop(); };
  }, []);

  /* Feature 78: Prompt Enhancement AI */
  async function enhancePrompt() {
    if (!displayPrompt.trim()) return;
    setEnhancing(true);
    setError("");
    try {
      const result = await callAI([{
        role: "user",
        content: `You are an expert AI image prompt engineer. Enhance the following image prompt to be more vivid, descriptive, and effective for AI image generation. Add specific visual details, lighting, composition, and artistic direction. Keep it under 100 words. Return ONLY the enhanced prompt, nothing else.\n\nOriginal: ${displayPrompt.trim()}`
      }]);
      setEnhancedPrompt(result.trim());
    } catch (e) {
      setError("Could not enhance prompt. Try again.");
    } finally {
      setEnhancing(false);
    }
  }

  /* Feature 71: Generate Images with HF Stable Diffusion API */
  async function generateImages() {
    const finalPrompt = displayPrompt.trim();
    if (!finalPrompt) { setError("Please describe the image you want."); return; }
    setGenerating(true);
    setError("");
    setCurrentResult(null);

    const fullPrompt = `${finalPrompt}, ${styleObj.suffix}`;
    const images = [];

    if (imageApiKey) {
      // Real API: Hugging Face Inference API
      for (let i = 0; i < activeCount; i++) {
        try {
          const params = {
            width: sizeObj.w,
            height: sizeObj.h,
            num_inference_steps: speedObj.steps,
            guidance_scale: speedObj.guidance,
            seed: Math.floor(Math.random() * 2147483647),
          };
          if (negativePrompt.trim()) params.negative_prompt = negativePrompt.trim();
          const response = await fetch(`https://api-inference.huggingface.co/models/${imageModel}`, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${imageApiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ inputs: fullPrompt, parameters: params })
          });

          if (!response.ok) {
            const errBody = await response.text();
            // Model loading — retry once
            if (response.status === 503) {
              await new Promise(r => setTimeout(r, 4000));
              const retry = await fetch(`https://api-inference.huggingface.co/models/${imageModel}`, {
                method: "POST",
                headers: { "Authorization": `Bearer ${imageApiKey}`, "Content-Type": "application/json" },
                body: JSON.stringify({ inputs: fullPrompt, parameters: { width: sizeObj.w, height: sizeObj.h } })
              });
              if (!retry.ok) throw new Error("Model still loading. Please try again in a minute.");
              const blob2 = await retry.blob();
              const url2 = URL.createObjectURL(blob2);
              const img2 = { url: url2, isDemo: false, desc: "" };
              if (galleryCloudSync) { try { const d = await blobToDataURL(blob2); if (d.length <= GALLERY_SYNC_MAX_BYTES) img2.persisted = d; } catch {} }
              images.push(img2);
            } else {
              throw new Error(`API error ${response.status}: ${errBody.slice(0, 120)}`);
            }
          } else {
            const blob = await response.blob();
            const url = URL.createObjectURL(blob);
            const img = { url, isDemo: false, desc: "" };
            if (galleryCloudSync) { try { const d = await blobToDataURL(blob); if (d.length <= GALLERY_SYNC_MAX_BYTES) img.persisted = d; } catch {} }
            images.push(img);
          }
        } catch (e) {
          setError(e.message || t.imgErrorTryAgain);
          setGenerating(false);
          return;
        }
      }
    } else {
      // Demo mode: AI describes what the image would look like
      try {
        const negNote = negativePrompt.trim() ? ` Avoid including: ${negativePrompt.trim()}.` : "";
        const descriptions = await callAI([{
          role: "user",
          content: `You are an AI image generation simulator. For the following image prompt, create ${activeCount} distinct visual description(s) of what each generated image would look like. Each description should be 2-3 sentences, vivid, and specific.${negNote} Number each one. Format: just the numbered descriptions.\n\nPrompt: "${fullPrompt}"\nStyle: ${styleObj.label}\nSize: ${sizeObj.label} (${sizeObj.w}x${sizeObj.h}, ${qualityObj.label} quality)`
        }]);
        const parts = descriptions.split(/\d+\.\s+/).filter(Boolean).slice(0, activeCount);
        for (let i = 0; i < activeCount; i++) {
          images.push({ url: null, isDemo: true, desc: parts[i] || descriptions });
        }
      } catch (e) {
        setError(t.imgErrorTryAgain);
        setGenerating(false);
        return;
      }
    }

    const result = { id: Date.now().toString(36), prompt: finalPrompt, style: activeStyle, size: activeSize, images, ts: Date.now(), mode: "text" };
    setCurrentResult(result);
    setImageHistory(prev => [result, ...prev.slice(0, 99)]);
    setGenerating(false);
  }

  /* v1.7 Feature 72: Image-to-Image — transform an uploaded photo with HF img2img, or
     fall back to a Claude-vision description of the transformation when no key is set. */
  async function generateImageToImage() {
    if (!uploadedImage) { setError(t.i2iNeedImage); return; }
    const instruction = displayPrompt.trim() || "Enhance this image with richer detail, color, and lighting";
    setGenerating(true);
    setError("");
    setCurrentResult(null);

    const fullInstruction = `${instruction}, ${styleObj.suffix}`;
    const images = [];

    if (imageApiKey) {
      // Real API: HF img2img-capable pipeline — source image + text instruction + strength
      for (let i = 0; i < activeCount; i++) {
        try {
          const i2iParams = {
            prompt: fullInstruction,
            strength: i2iStrength,
            guidance_scale: speedObj.guidance,
            seed: Math.floor(Math.random() * 2147483647),
          };
          if (negativePrompt.trim()) i2iParams.negative_prompt = negativePrompt.trim();
          const body = JSON.stringify({ inputs: uploadedImage.base64, parameters: i2iParams });
          const response = await fetch(`https://api-inference.huggingface.co/models/${imageModel}`, {
            method: "POST",
            headers: { "Authorization": `Bearer ${imageApiKey}`, "Content-Type": "application/json" },
            body,
          });

          if (!response.ok) {
            const errBody = await response.text();
            if (response.status === 503) {
              await new Promise(r => setTimeout(r, 4000));
              const retry = await fetch(`https://api-inference.huggingface.co/models/${imageModel}`, {
                method: "POST",
                headers: { "Authorization": `Bearer ${imageApiKey}`, "Content-Type": "application/json" },
                body,
              });
              if (!retry.ok) throw new Error("Model still loading. Please try again in a minute.");
              const blob2 = await retry.blob();
              const img2 = { url: URL.createObjectURL(blob2), isDemo: false, desc: "" };
              if (galleryCloudSync) { try { const d = await blobToDataURL(blob2); if (d.length <= GALLERY_SYNC_MAX_BYTES) img2.persisted = d; } catch {} }
              images.push(img2);
            } else {
              throw new Error(`API error ${response.status}: ${errBody.slice(0, 120)}`);
            }
          } else {
            const blob = await response.blob();
            const img = { url: URL.createObjectURL(blob), isDemo: false, desc: "" };
            if (galleryCloudSync) { try { const d = await blobToDataURL(blob); if (d.length <= GALLERY_SYNC_MAX_BYTES) img.persisted = d; } catch {} }
            images.push(img);
          }
        } catch (e) {
          setError(e.message || t.imgErrorTryAgain);
          setGenerating(false);
          return;
        }
      }
    } else {
      // Demo mode: Claude vision looks at the uploaded photo and describes the transformed result
      try {
        const visionPrompt = `You are an AI image transformation simulator. Look closely at this image, then imagine applying this transformation: "${fullInstruction}" (style: ${styleObj.label}). Preserve the main subject and composition unless the instruction says otherwise. Write ${activeCount} distinct visual description(s) of the result, each 2-3 sentences, vivid and specific. Number each one.`;
        const descriptions = await analyzeImage(uploadedImage.base64, uploadedImage.mediaType, visionPrompt);
        const parts = descriptions.split(/\d+\.\s+/).filter(Boolean).slice(0, activeCount);
        for (let i = 0; i < activeCount; i++) {
          images.push({ url: null, isDemo: true, desc: parts[i] || descriptions });
        }
      } catch (e) {
        setError(t.imgErrorTryAgain);
        setGenerating(false);
        return;
      }
    }

    const result = {
      id: Date.now().toString(36), prompt: instruction, style: activeStyle, size: activeSize,
      images, ts: Date.now(), mode: "image", sourceThumb: uploadedImage.previewUrl,
    };
    setCurrentResult(result);
    setImageHistory(prev => [result, ...prev.slice(0, 99)]);
    setGenerating(false);
  }

  /* v1.7 Feature 72: validate + read the uploaded image into base64 for upload/preview */
  function handleI2IFile(file) {
    if (!file) return;
    if (!I2I_ACCEPTED_TYPES.includes(file.type)) { setError(t.i2iUnsupportedFile); return; }
    if (file.size > I2I_MAX_BYTES) { setError(t.i2iFileTooLarge); return; }
    setError("");
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      const base64 = dataUrl.split(",")[1];
      setUploadedImage({ base64, mediaType: file.type, previewUrl: dataUrl, name: file.name });
      setCurrentResult(null);
    };
    reader.onerror = () => setError(t.i2iUnsupportedFile);
    reader.readAsDataURL(file);
  }
  function handleI2IDrop(e) {
    e.preventDefault();
    setI2iDragging(false);
    handleI2IFile(e.dataTransfer.files?.[0]);
  }

  /* v1.7 Feature 73: Speech-to-text recording for Audio-to-Image */
  function startA2IRecording() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setError(t.a2iNotSupported); return; }
    if (isRecording) { a2iRecognitionRef.current?.stop(); return; }
    const langInfo = AUDIO_LANGS.find(l => l.id === audioLang) || AUDIO_LANGS[0];
    const recognition = new SR();
    a2iRecognitionRef.current = recognition;
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = langInfo.code;

    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);
    recognition.onresult = (e) => {
      let finalText = "";
      let interim = "";
      for (let i = 0; i < e.results.length; i++) {
        const t2 = e.results[i][0].transcript;
        if (e.results[i].isFinal) finalText += t2 + " ";
        else interim += t2;
      }
      setAudioTranscript((finalText || interim).trim());
    };
    recognition.start();
  }
  function stopA2IRecording() {
    a2iRecognitionRef.current?.stop();
    setIsRecording(false);
  }

  /* v1.7 Feature 73: turn a raw spoken transcript into a clean, optimized image prompt */
  async function optimizeVoicePrompt() {
    if (!audioTranscript.trim()) return;
    setOptimizingVoice(true);
    setError("");
    try {
      const result = await callAI([{
        role: "user",
        content: `The following is a raw speech-to-text transcript (it may mix Hindi, English, or Hinglish, and may contain filler words or repeats). Turn it into a single clean, well-formed AI image generation prompt in English, capturing exactly what was described. Return ONLY the prompt, nothing else.\n\nTranscript: ${audioTranscript.trim()}`
      }]);
      setPrompt(result.trim());
      setEnhancedPrompt("");
    } catch (e) {
      setError("Could not build a prompt from your voice. Try again.");
    } finally {
      setOptimizingVoice(false);
    }
  }

  /* Feature 76: Download image */
  function downloadImage(img, idx) {
    if (img.isDemo) {
      const blob = new Blob([img.desc], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `novexa-image-${Date.now()}-${idx}.txt`; a.click();
      URL.revokeObjectURL(url);
    } else {
      const a = document.createElement("a");
      a.href = img.url; a.download = `novexa-image-${Date.now()}-${idx}.png`; a.click();
    }
  }

  /* Feature 79: Share image */
  async function shareImage(img) {
    if (!img.isDemo && img.url && navigator.share) {
      try {
        const resp = await fetch(img.url);
        const blob = await resp.blob();
        const file = new File([blob], "novexa-image.png", { type: "image/png" });
        await navigator.share({ files: [file], title: "Novexa AI Image" });
        return;
      } catch (e) {}
    }
    try {
      await navigator.clipboard.writeText(img.isDemo ? img.desc : `Generated: ${currentResult?.prompt}`);
    } catch (e) {}
    setError("Copied to clipboard!");
    setTimeout(() => setError(""), 1800);
  }

  function copyPrompt(p) {
    navigator.clipboard.writeText(p).catch(() => {});
  }

  /* v1.8 Feature 77: High-quality image upscaling — tries an HF upscaler model when a key is
     set, otherwise falls back to a real client-side canvas upscale + sharpen. */
  async function upscaleImage(idx) {
    if (!currentResult || currentResult.images[idx]?.isDemo) return;
    const img = currentResult.images[idx];
    setUpscalingIdx(idx);
    setError("");
    try {
      let blob = null;
      if (imageApiKey) {
        try {
          const resp = await fetch(img.url);
          const srcBlob = await resp.blob();
          const srcB64 = await blobToDataURL(srcBlob);
          const upRes = await fetch(`https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-x4-upscaler`, {
            method: "POST",
            headers: { "Authorization": `Bearer ${imageApiKey}`, "Content-Type": "application/json" },
            body: JSON.stringify({ inputs: srcB64.split(",")[1], parameters: { prompt: "high quality, ultra sharp, upscaled, detailed" } }),
          });
          if (upRes.ok) blob = await upRes.blob();
        } catch (e) { /* fall through to canvas upscale */ }
      }
      if (!blob) blob = await canvasUpscale(img.url, 2);
      const newUrl = URL.createObjectURL(blob);
      let persisted;
      if (galleryCloudSync) { try { const d = await blobToDataURL(blob); if (d.length <= GALLERY_SYNC_MAX_BYTES) persisted = d; } catch {} }
      const updatedImg = { ...img, url: newUrl, upscaled: true, persisted };
      setCurrentResult(prev => {
        const next = { ...prev, images: prev.images.map((im, i) => i === idx ? updatedImg : im) };
        setImageHistory(h => h.map(it => it.id === next.id ? next : it));
        return next;
      });
    } catch (e) {
      setError(t.imgErrorTryAgain);
    } finally {
      setUpscalingIdx(null);
    }
  }

  function loadFromHistory(item) {
    setPrompt(item.prompt);
    setEnhancedPrompt("");
    setActiveStyle(item.style);
    setActiveSize(item.size);
    setCurrentResult(item);
    if (item.mode === "image") {
      setGenMode("image");
      if (item.sourceThumb) setUploadedImage({ base64: "", mediaType: "image/png", previewUrl: item.sourceThumb, name: "" });
    } else if (item.mode === "audio") {
      setGenMode("audio");
    } else {
      setGenMode("text");
    }
  }

  function deleteFromHistory(id) {
    setImageHistory(prev => prev.filter(i => i.id !== id));
    if (currentResult?.id === id) setCurrentResult(null);
  }

  return (
    <>
      {/* Topbar */}
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(!sidebarOpen)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.imgGenTitle}</div>
          <div className="nx-topbar-sub">{t.imgGenSubtitle}</div>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div className="nx-img-lightbox" onClick={() => setLightbox(null)}>
          {lightbox.isDemo ? (
            <div style={{ maxWidth: 480, background: "var(--surface)", borderRadius: 16, padding: 32, color: "var(--text)" }}>
              <div style={{ fontSize: 36, marginBottom: 16, textAlign: "center" }}>{styleObj.icon}</div>
              <p style={{ margin: 0, lineHeight: 1.6 }}>{lightbox.desc}</p>
            </div>
          ) : (
            <img src={lightbox.url} alt="Generated" onClick={e => e.stopPropagation()} />
          )}
          <button className="nx-img-lightbox-close" onClick={() => setLightbox(null)}><X size={20} /></button>
        </div>
      )}

      <div className="nx-img-layout">
        {/* ---- LEFT PANEL: Controls ---- */}
        <div className="nx-img-panel">
          <div>
            <h2 className="nx-img-panel-title">✨ {t.imgGenTitle}</h2>
            <p className="nx-img-panel-sub">{t.imgGenSubtitle}</p>
          </div>

          {/* v1.7 Features 71-73: generator mode tabs */}
          <div className="nx-img-mode-tabs">
            <button className={`nx-img-mode-tab${genMode === "text" ? " active" : ""}`}
              onClick={() => { setGenMode("text"); setError(""); }}>
              <PenLine size={16} /> {t.imgTabText}
            </button>
            <button className={`nx-img-mode-tab${genMode === "image" ? " active" : ""}`}
              onClick={() => { setGenMode("image"); setError(""); }}>
              <ImagePlus size={16} /> {t.imgTabImage}
            </button>
            <button className={`nx-img-mode-tab${genMode === "audio" ? " active" : ""}`}
              onClick={() => { setGenMode("audio"); setError(""); }}>
              <Mic size={16} /> {t.imgTabAudio}
            </button>
          </div>

          {!imageApiKey && (
            <div className="nx-img-api-note">
              <Image size={14} style={{ flexShrink: 0, marginTop: 2 }} />
              <span>{t.imgNoKey}</span>
            </div>
          )}

          {/* v1.7 Feature 72: Image-to-Image — upload + strength */}
          {genMode === "image" && (
            <div>
              <div className="nx-section-label" style={{ margin: "0 0 6px" }}>{t.i2iUploadTitle}</div>
              {uploadedImage ? (
                <div className="nx-i2i-preview-wrap">
                  <img src={uploadedImage.previewUrl} alt="Uploaded source" />
                  <div className="nx-i2i-preview-actions">
                    <button className="nx-i2i-preview-btn" onClick={() => i2iInputRef.current?.click()}>
                      <RefreshCw size={12} /> {t.i2iChangeImage}
                    </button>
                    <button className="nx-i2i-preview-btn" onClick={() => { setUploadedImage(null); setCurrentResult(null); }}>
                      <Trash2 size={12} /> {t.i2iRemoveImage}
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  className={`nx-i2i-upload-zone${i2iDragging ? " drag" : ""}`}
                  onClick={() => i2iInputRef.current?.click()}
                  onDragOver={(e) => { e.preventDefault(); setI2iDragging(true); }}
                  onDragLeave={() => setI2iDragging(false)}
                  onDrop={handleI2IDrop}
                >
                  <UploadCloud size={26} />
                  <h4>{t.i2iUploadTitle}</h4>
                  <p>{t.i2iUploadSub}</p>
                  <p style={{ marginTop: 2, fontSize: 10.5 }}>{t.i2iUploadHint}</p>
                </div>
              )}
              <input ref={i2iInputRef} type="file" hidden accept="image/png,image/jpeg,image/webp"
                onChange={(e) => { handleI2IFile(e.target.files?.[0]); e.target.value = ""; }} />

              {uploadedImage && (
                <div style={{ marginTop: 12 }}>
                  <div className="nx-section-label" style={{ margin: "0 0 6px" }}>{t.i2iStrengthLabel}</div>
                  <div className="nx-i2i-strength-row">
                    <input
                      type="range" min="0.1" max="0.95" step="0.05" value={i2iStrength}
                      style={{ "--pct": Math.round(((i2iStrength - 0.1) / (0.95 - 0.1)) * 100) }}
                      onChange={(e) => setI2iStrength(parseFloat(e.target.value))}
                    />
                  </div>
                  <div className="nx-i2i-strength-labels"><span>{t.i2iStrengthSubtle}</span><span>{t.i2iStrengthDramatic}</span></div>
                  <p className="nx-i2i-note" style={{ marginTop: 8 }}>{t.i2iPreserveNote}</p>
                </div>
              )}
            </div>
          )}

          {/* v1.7 Feature 73: Audio-to-Image — voice recorder */}
          {genMode === "audio" && (
            <div>
              <div className="nx-section-label" style={{ margin: "0 0 6px" }}>{t.a2iLangLabel}</div>
              <div className="nx-a2i-lang-row">
                {AUDIO_LANGS.map(l => (
                  <button key={l.id} className={`nx-a2i-lang-btn${audioLang === l.id ? " active" : ""}`} onClick={() => setAudioLang(l.id)}>
                    {l.label}
                  </button>
                ))}
              </div>

              <div className="nx-a2i-mic-wrap">
                <button className={`nx-a2i-mic-btn${isRecording ? " recording" : ""}`}
                  onClick={isRecording ? stopA2IRecording : startA2IRecording}>
                  {isRecording ? <MicOff size={26} /> : <Mic size={26} />}
                </button>
                <span className="nx-a2i-mic-hint">{isRecording ? t.a2iListening : t.a2iRecordStart}</span>
              </div>

              <div className="nx-section-label" style={{ margin: "10px 0 6px" }}>{t.a2iTranscriptLabel}</div>
              <div className="nx-a2i-transcript-box">
                {audioTranscript ? audioTranscript : <span className="nx-a2i-transcript-empty">{t.a2iEmptyHint}</span>}
              </div>
              {audioTranscript && (
                <div className="nx-a2i-transcript-actions">
                  <button className="nx-btn nx-btn-ghost" style={{ fontSize: 11, padding: "5px 10px" }} onClick={() => setAudioTranscript("")}>
                    {t.a2iClear}
                  </button>
                  <button className="nx-img-enhance-btn" style={{ margin: 0, width: "auto", padding: "6px 12px" }}
                    onClick={optimizeVoicePrompt} disabled={optimizingVoice}>
                    {optimizingVoice ? <><Loader2 size={12} className="nx-spin" /> {t.a2iOptimizing}</> : <>{t.a2iOptimizeBtn}</>}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Prompt — shared across Text / Image / Audio modes */}
          <div>
            <div className="nx-section-label" style={{ margin: "0 0 6px" }}>
              {genMode === "image" ? t.i2iPromptLabel : t.imgPromptLabel}
            </div>
            <div className="nx-img-prompt-wrap">
              <textarea
                ref={promptRef}
                className="nx-img-prompt"
                placeholder={genMode === "image" ? t.i2iPromptPlaceholder : t.imgPromptPlaceholder}
                value={enhancedPrompt || prompt}
                onChange={(e) => {
                  if (enhancedPrompt) setEnhancedPrompt(e.target.value);
                  else setPrompt(e.target.value);
                }}
              />
            </div>
            <button className="nx-img-enhance-btn" onClick={enhancePrompt} disabled={enhancing || !displayPrompt.trim()}>
              {enhancing ? <><Loader2 size={13} className="nx-spin" /> {t.imgEnhancing}</> : <>{t.imgEnhanceBtn}</>}
            </button>
          </div>

          {/* Style */}
          <div>
            <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.imgStyleLabel}</div>
            <div className="nx-img-style-grid">
              {IMAGE_STYLES.map(s => (
                <button key={s.id} className={`nx-img-style-btn${activeStyle === s.id ? " active" : ""}`} onClick={() => setActiveStyle(s.id)}>
                  <span className="nx-img-style-icon">{s.icon}</span>
                  {t.imgStyles?.[s.id] || s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Size — not used for Image-to-Image, which preserves the source image's dimensions */}
          {genMode !== "image" && (
            <div>
              <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.imgSizeLabel}</div>
              <div className="nx-img-size-row">
                {IMAGE_SIZES.map(sz => (
                  <button key={sz.id} className={`nx-img-size-btn${activeSize === sz.id ? " active" : ""}`} onClick={() => setActiveSize(sz.id)}>
                    <div className="nx-img-size-preview" style={{
                      width: sz.id === "16:9" ? 36 : sz.id === "9:16" ? 18 : 28,
                      height: sz.id === "9:16" ? 36 : sz.id === "16:9" ? 18 : 28,
                    }} />
                    <div className="nx-img-size-label">{sz.label}</div>
                    <div className="nx-img-size-sub">{sz.sublabel}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Count */}
          <div>
            <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.imgCountLabel}</div>
            <div className="nx-img-count-row">
              {IMAGE_COUNTS.map(n => (
                <button key={n} className={`nx-img-count-btn${activeCount === n ? " active" : ""}`} onClick={() => setActiveCount(n)}>
                  {n}
                </button>
              ))}
            </div>
          </div>

          {/* v1.8 Feature 77: Quality (HD / Ultra HD) */}
          <div>
            <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.imgQualityLabel}</div>
            <div className="nx-img-count-row">
              {IMAGE_QUALITIES.map(q => (
                <button key={q.id} className={`nx-img-count-btn${activeQuality === q.id ? " active" : ""}`} onClick={() => setActiveQuality(q.id)}>
                  {t.imgQualities[q.id] || q.label}
                </button>
              ))}
            </div>
          </div>

          {/* v1.8 Feature 77: Fast vs Quality generation mode */}
          <div>
            <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.imgSpeedLabel}</div>
            <div className="nx-pill-group" style={{ width: "100%" }}>
              <button className={`nx-pill${speedMode === "fast" ? " active" : ""}`} style={{ flex: 1 }} onClick={() => setSpeedMode("fast")} title={t.imgSpeedFastHint}>
                <Zap size={12} style={{ marginRight: 4 }} />{t.imgSpeedFast}
              </button>
              <button className={`nx-pill${speedMode === "quality" ? " active" : ""}`} style={{ flex: 1 }} onClick={() => setSpeedMode("quality")} title={t.imgSpeedQualityHint}>
                <Star size={12} style={{ marginRight: 4 }} />{t.imgSpeedQuality}
              </button>
            </div>
          </div>

          {/* v1.8 Feature 77: Advanced — negative prompt */}
          <div>
            <button className="nx-img-enhance-btn" style={{ borderStyle: "solid" }} onClick={() => setShowAdvanced(s => !s)}>
              <SettingsIcon size={14} /> {t.imgAdvancedToggle} {showAdvanced ? <ChevronLeft size={14} style={{ transform: "rotate(-90deg)" }} /> : <ChevronRight size={14} />}
            </button>
            {showAdvanced && (
              <div style={{ marginTop: 8 }}>
                <div className="nx-section-label" style={{ margin: "0 0 6px" }}>{t.imgNegativeLabel} <span style={{ opacity: .6, fontWeight: 400 }}>{t.imgNegativeOptional}</span></div>
                <textarea className="nx-img-prompt" style={{ minHeight: 56 }} placeholder={t.imgNegativePlaceholder}
                  value={negativePrompt} onChange={(e) => setNegativePrompt(e.target.value)} />
              </div>
            )}
          </div>

          {/* Generate */}
          <button
            className="nx-img-gen-btn"
            onClick={genMode === "image" ? generateImageToImage : generateImages}
            disabled={generating || (genMode === "image" ? !uploadedImage : !displayPrompt.trim())}
          >
            {generating
              ? <><Loader2 size={18} className="nx-spin" /> {genMode === "image" ? t.i2iGenerating : t.imgGenerating}</>
              : <><ImagePlus size={18} /> {genMode === "image" ? t.i2iGenerateBtn : t.imgGenerateBtn}</>
            }
          </button>

          {error && (
            <div className="nx-banner" style={{ margin: 0 }}>
              <AlertCircle size={14} />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* ---- RIGHT: Results + History ---- */}
        <div className="nx-img-main">
          {generating ? (
            /* Loading shimmer */
            <div className="nx-img-loading">
              <div className="nx-img-shimmer-grid">
                {Array.from({ length: activeCount }).map((_, i) => (
                  <div key={i} className="nx-img-shimmer" style={{
                    width: activeSize === "16:9" ? 240 : activeSize === "9:16" ? 120 : 180,
                    height: activeSize === "9:16" ? 200 : activeSize === "16:9" ? 120 : 180,
                  }} />
                ))}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
                <Loader2 size={16} className="nx-spin" /> {t.imgGenerating}
              </div>
            </div>
          ) : currentResult ? (
            <>
              {currentResult.mode === "image" && currentResult.sourceThumb && (
                <div className="nx-img-source-row">
                  <img className="nx-img-source-thumb" src={currentResult.sourceThumb} alt={t.i2iOriginal} />
                  <span className="nx-img-source-label">{t.i2iOriginal} → {t.imgGenerated(currentResult.images.length)}</span>
                </div>
              )}
              <div className="nx-img-results-header">
                <span className="nx-img-results-title">
                  <Image size={13} style={{ marginRight: 5 }} />{t.imgGenerated(currentResult.images.length)}
                </span>
              </div>

              {/* Image grid */}
              <div className={`nx-img-grid count-${currentResult.images.length}`} style={{ paddingTop: 0 }}>
                {currentResult.images.map((img, i) => (
                  <div key={i} className="nx-img-card">
                    {img.isDemo ? (
                      <div className="nx-img-demo-placeholder">
                        <div className="nx-img-demo-icon">
                          {IMAGE_STYLES.find(s => s.id === currentResult.style)?.icon || "🎨"}
                        </div>
                        <div className="nx-img-demo-desc">{img.desc}</div>
                      </div>
                    ) : (
                      <img src={img.url} alt={`Generated ${i + 1}`} />
                    )}
                    {img.upscaled && <span className="nx-img-upscaled-badge">{t.imgUpscaledBadge}</span>}
                    <div className="nx-img-card-actions">
                      <button className="nx-img-action-btn" onClick={() => setLightbox(img)} title="Expand">
                        <ZoomIn size={12} /> View
                      </button>
                      {!img.isDemo && (
                        <button className="nx-img-action-btn" onClick={() => upscaleImage(i)} disabled={upscalingIdx === i} title={t.imgUpscaleBtn}>
                          {upscalingIdx === i ? <Loader2 size={12} className="nx-spin" /> : <Maximize2 size={12} />} {upscalingIdx === i ? t.imgUpscaling : t.imgUpscaleBtn}
                        </button>
                      )}
                      <button className="nx-img-action-btn" onClick={() => downloadImage(img, i)} title={t.imgDownload}>
                        <Download size={12} /> {t.imgDownload}
                      </button>
                      <button className="nx-img-action-btn" onClick={() => shareImage(img)} title={t.imgShare}>
                        <Share2 size={12} /> {t.imgShare}
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Used prompt + regenerate */}
              <div className="nx-img-used-prompt">
                <div className="nx-img-used-prompt-text">
                  <strong style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: ".05em" }}>Prompt: </strong>
                  {currentResult.prompt}
                </div>
                <button className="nx-img-regen-btn" onClick={() => {
                  setPrompt(currentResult.prompt); setEnhancedPrompt("");
                  if (currentResult.mode === "image" && uploadedImage) generateImageToImage();
                  else generateImages();
                }}>
                  <RefreshCw size={12} /> {t.imgRegenerateBtn}
                </button>
              </div>

              {/* Action row */}
              <div style={{ padding: "0 20px 20px", display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button className="nx-btn nx-btn-ghost" style={{ fontSize: 12, padding: "7px 12px" }}
                  onClick={() => copyPrompt(currentResult.prompt)}>
                  <Copy size={13} /> {t.imgCopyPrompt}
                </button>
                <button className="nx-btn nx-btn-ghost" style={{ fontSize: 12, padding: "7px 12px" }}
                  onClick={() => { setPrompt(currentResult.prompt); setEnhancedPrompt(""); }}>
                  <PencilIcon size={13} /> {t.imgEditPrompt}
                </button>
                <button className="nx-btn nx-btn-ghost" style={{ fontSize: 12, padding: "7px 12px" }}
                  onClick={() => onSendToChat?.(currentResult.prompt)}>
                  <MessageSquare size={13} /> {t.imgAddToChat}
                </button>
              </div>
            </>
          ) : (
            /* Empty state */
            <div className="nx-img-empty">
              <div className="nx-img-empty-icon">🎨</div>
              <h3>{t.imgGenTitle}</h3>
              <p>{t.imgApiKeyNote}</p>
            </div>
          )}

          {/* ---- History Gallery (Feature 77) ---- */}
          {imageHistory.length > 0 && (
            <div className="nx-img-history-section">
              <div className="nx-img-history-header">
                <span className="nx-img-history-title">
                  <History size={13} /> {t.imgHistory}
                </span>
                <button className="nx-btn nx-btn-ghost" style={{ fontSize: 11, padding: "5px 10px" }}
                  onClick={() => { setImageHistory([]); setCurrentResult(null); }}>
                  <Trash2 size={12} /> {t.imgClearHistory}
                </button>
              </div>
              <div className="nx-img-history-grid">
                {imageHistory.map(item => {
                  const firstImg = item.images?.[0];
                  const styleItem = IMAGE_STYLES.find(s => s.id === item.style);
                  return (
                    <div key={item.id} style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                      <div className="nx-img-history-thumb" onClick={() => loadFromHistory(item)}>
                        {firstImg?.isDemo ? (
                          <div className="nx-img-history-demo">
                            <div className="nx-img-history-demo-icon">{styleItem?.icon || "🎨"}</div>
                            <div className="nx-img-history-demo-style">{styleItem?.label || item.style}</div>
                          </div>
                        ) : firstImg?.url ? (
                          <img src={firstImg.url} alt={item.prompt} />
                        ) : (
                          <div className="nx-img-history-demo">
                            <div className="nx-img-history-demo-icon">🖼️</div>
                          </div>
                        )}
                        <div className="nx-img-history-overlay">
                          <button className="nx-img-hist-icon-btn" onClick={(e) => { e.stopPropagation(); loadFromHistory(item); }} title="Load">
                            <RefreshCw size={13} />
                          </button>
                          <button className="nx-img-hist-icon-btn" onClick={(e) => { e.stopPropagation(); deleteFromHistory(item.id); }} title={t.imgDeleteImage}>
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                      <div className="nx-img-history-prompt">{item.prompt}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

/* ============================== v1.8: AI Image Editor (Feature 75) ============================== */
function ImageEditorDashboard({ t, callAI, imageApiKey, imageModel, imageHistory, setImageHistory, sidebarOpen, setSidebarOpen, analyzeImage, galleryCloudSync }) {
  const [uploadedImage, setUploadedImage] = useState(null); // {base64, mediaType, previewUrl, name}
  const [workingUrl, setWorkingUrl] = useState(null);
  const [historyStack, setHistoryStack] = useState([]); // [url, url, ...]
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [naturalSize, setNaturalSize] = useState({ w: 0, h: 0 });
  const [dragging, setDragging] = useState(false);
  const [instruction, setInstruction] = useState("");
  const [applying, setApplying] = useState(false);
  const [busyTool, setBusyTool] = useState(null);
  const [error, setError] = useState("");
  const [demoDesc, setDemoDesc] = useState(""); // shown when no API key, describing what the edit would look like
  const [savedFlag, setSavedFlag] = useState(false);
  const fileInputRef = useRef(null);

  /* Transform panel */
  const [transformTab, setTransformTab] = useState("crop"); // "crop" | "resize" | "rotate"
  const [crop, setCrop] = useState({ x: 0.1, y: 0.1, w: 0.8, h: 0.8 });
  const cropBoxRef = useRef(null);
  const dragInfoRef = useRef(null);
  const [resizeW, setResizeW] = useState(0);
  const [resizeH, setResizeH] = useState(0);
  const [lockAspect, setLockAspect] = useState(true);
  const [rotatePreview, setRotatePreview] = useState(0);

  useEffect(() => {
    if (workingUrl) {
      loadImageEl(workingUrl).then(img => {
        setNaturalSize({ w: img.naturalWidth, h: img.naturalHeight });
        setResizeW(img.naturalWidth);
        setResizeH(img.naturalHeight);
      }).catch(() => {});
    }
  }, [workingUrl]);

  function pushHistory(newUrl) {
    setHistoryStack(prev => {
      const trimmed = prev.slice(0, historyIdx + 1);
      const next = [...trimmed, newUrl];
      setHistoryIdx(next.length - 1);
      return next;
    });
    setWorkingUrl(newUrl);
    setCrop({ x: 0.1, y: 0.1, w: 0.8, h: 0.8 });
    setRotatePreview(0);
    setDemoDesc("");
  }
  function undo() {
    if (historyIdx <= 0) return;
    const ni = historyIdx - 1;
    setHistoryIdx(ni);
    setWorkingUrl(historyStack[ni]);
  }
  function redo() {
    if (historyIdx >= historyStack.length - 1) return;
    const ni = historyIdx + 1;
    setHistoryIdx(ni);
    setWorkingUrl(historyStack[ni]);
  }
  function resetToOriginal() {
    if (!uploadedImage) return;
    setHistoryStack([uploadedImage.previewUrl]);
    setHistoryIdx(0);
    setWorkingUrl(uploadedImage.previewUrl);
    setDemoDesc("");
  }

  function handleFile(file) {
    if (!file) return;
    if (!EDIT_ACCEPTED_TYPES.includes(file.type)) { setError(t.editUnsupportedFile); return; }
    if (file.size > EDIT_MAX_BYTES) { setError(t.editFileTooLarge); return; }
    setError("");
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      const base64 = dataUrl.split(",")[1];
      setUploadedImage({ base64, mediaType: file.type, previewUrl: dataUrl, name: file.name });
      setHistoryStack([dataUrl]);
      setHistoryIdx(0);
      setWorkingUrl(dataUrl);
      setDemoDesc("");
      setSavedFlag(false);
    };
    reader.onerror = () => setError(t.editUnsupportedFile);
    reader.readAsDataURL(file);
  }
  function handleDrop(e) {
    e.preventDefault();
    setDragging(false);
    handleFile(e.dataTransfer.files?.[0]);
  }

  /* Convert the current working image (data: or blob: URL) into base64 + mediaType for API calls */
  async function workingToBase64() {
    const resp = await fetch(workingUrl);
    const blob = await resp.blob();
    const dataUrl = await blobToDataURL(blob);
    return { base64: dataUrl.split(",")[1], mediaType: blob.type || "image/png" };
  }

  /* v1.8 Feature 75: the shared AI-edit pipeline used by one-click tools and the instruction box.
     Replace objects, add objects, and recolor/restyle all flow through here as a single
     instruction-based edit against the uploaded photo. */
  async function applyAIEdit(rawInstruction, toolId) {
    if (!workingUrl) { setError(t.editNeedImage); return; }
    const text = (rawInstruction || "").trim();
    if (!text) return;
    setApplying(true);
    if (toolId) setBusyTool(toolId);
    setError("");
    try {
      if (imageApiKey) {
        const { base64 } = await workingToBase64();
        const body = JSON.stringify({
          inputs: base64,
          parameters: { prompt: text, strength: 0.55, guidance_scale: 7.5, seed: Math.floor(Math.random() * 2147483647) },
        });
        let response = await fetch(`https://api-inference.huggingface.co/models/${imageModel}`, {
          method: "POST",
          headers: { "Authorization": `Bearer ${imageApiKey}`, "Content-Type": "application/json" },
          body,
        });
        if (!response.ok && response.status === 503) {
          await new Promise(r => setTimeout(r, 4000));
          response = await fetch(`https://api-inference.huggingface.co/models/${imageModel}`, {
            method: "POST",
            headers: { "Authorization": `Bearer ${imageApiKey}`, "Content-Type": "application/json" },
            body,
          });
        }
        if (!response.ok) {
          const errBody = await response.text();
          throw new Error(`API error ${response.status}: ${errBody.slice(0, 120)}`);
        }
        const blob = await response.blob();
        pushHistory(URL.createObjectURL(blob));
      } else {
        const { base64, mediaType } = await workingToBase64();
        const visionPrompt = `You are an AI photo editing simulator. Look closely at this image, then imagine applying this edit: "${text}". Describe the resulting image in 2-3 vivid, specific sentences, focused on exactly what changed.`;
        const desc = await analyzeImage(base64, mediaType, visionPrompt);
        setDemoDesc(desc.trim());
      }
    } catch (e) {
      setError(e.message || t.editErrorTryAgain);
    } finally {
      setApplying(false);
      setBusyTool(null);
    }
  }

  function runOneClickTool(toolId) {
    if (toolId === "upscale") {
      // Always-real, no API key needed: client-side canvas upscale + sharpen
      if (!workingUrl) { setError(t.editNeedImage); return; }
      setBusyTool("upscale");
      setError("");
      canvasUpscale(workingUrl, 2)
        .then(blob => pushHistory(URL.createObjectURL(blob)))
        .catch(() => setError(t.editErrorTryAgain))
        .finally(() => setBusyTool(null));
      return;
    }
    const presets = {
      removebg: "Remove the background completely, leaving only the main subject crisply cut out on a plain white background",
      enhance: "Enhance and restore this photo: increase sharpness and clarity, balance colors and exposure, reduce noise and damage, make it look professionally retouched",
      recolor: "Recolor this image with a fresh, vibrant, harmonious color palette while preserving the subject and composition exactly",
    };
    applyAIEdit(presets[toolId], toolId);
  }

  /* ---- Crop ---- */
  function onCropPointerDown(e, mode) {
    e.preventDefault();
    const rect = cropBoxRef.current.getBoundingClientRect();
    dragInfoRef.current = { mode, startX: e.clientX, startY: e.clientY, rect, crop: { ...crop } };
    window.addEventListener("pointermove", onCropPointerMove);
    window.addEventListener("pointerup", onCropPointerUp);
  }
  function onCropPointerMove(e) {
    const info = dragInfoRef.current;
    if (!info) return;
    const dx = (e.clientX - info.startX) / info.rect.width;
    const dy = (e.clientY - info.startY) / info.rect.height;
    let { x, y, w, h } = info.crop;
    if (info.mode === "move") {
      x = clamp01(info.crop.x + dx, 0, 1 - info.crop.w);
      y = clamp01(info.crop.y + dy, 0, 1 - info.crop.h);
    } else if (info.mode === "se") {
      w = clamp01(info.crop.w + dx, 0.05, 1 - info.crop.x);
      h = clamp01(info.crop.h + dy, 0.05, 1 - info.crop.y);
    } else if (info.mode === "nw") {
      const newX = clamp01(info.crop.x + dx, 0, info.crop.x + info.crop.w - 0.05);
      const newY = clamp01(info.crop.y + dy, 0, info.crop.y + info.crop.h - 0.05);
      w = info.crop.x + info.crop.w - newX; h = info.crop.y + info.crop.h - newY;
      x = newX; y = newY;
    }
    setCrop({ x, y, w, h });
  }
  function onCropPointerUp() {
    dragInfoRef.current = null;
    window.removeEventListener("pointermove", onCropPointerMove);
    window.removeEventListener("pointerup", onCropPointerUp);
  }
  function clamp01(v, min, max) { return Math.min(max, Math.max(min, v)); }

  async function applyCrop() {
    if (!workingUrl) return;
    setBusyTool("crop");
    setError("");
    try {
      const blob = await canvasCrop(workingUrl, crop);
      pushHistory(URL.createObjectURL(blob));
    } catch { setError(t.editErrorTryAgain); }
    finally { setBusyTool(null); }
  }

  /* ---- Resize ---- */
  function onResizeWChange(v) {
    const w = Math.max(1, parseInt(v) || 0);
    setResizeW(w);
    if (lockAspect && naturalSize.w) setResizeH(Math.round(w * (naturalSize.h / naturalSize.w)));
  }
  function onResizeHChange(v) {
    const h = Math.max(1, parseInt(v) || 0);
    setResizeH(h);
    if (lockAspect && naturalSize.h) setResizeW(Math.round(h * (naturalSize.w / naturalSize.h)));
  }
  async function applyResize() {
    if (!workingUrl) return;
    setBusyTool("resize");
    setError("");
    try {
      const blob = await canvasResize(workingUrl, resizeW, resizeH);
      pushHistory(URL.createObjectURL(blob));
    } catch { setError(t.editErrorTryAgain); }
    finally { setBusyTool(null); }
  }

  /* ---- Rotate ---- */
  async function applyRotateBy(deg) {
    if (!workingUrl) return;
    setBusyTool("rotate");
    setError("");
    try {
      const blob = await canvasRotate(workingUrl, deg);
      pushHistory(URL.createObjectURL(blob));
    } catch { setError(t.editErrorTryAgain); }
    finally { setBusyTool(null); }
  }

  /* ---- Save / Download / Share ---- */
  async function saveToGallery() {
    if (!workingUrl) return;
    try {
      const resp = await fetch(workingUrl);
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const img = { url, isDemo: false, desc: "" };
      if (galleryCloudSync) {
        try { const d = await blobToDataURL(blob); if (d.length <= GALLERY_SYNC_MAX_BYTES) img.persisted = d; } catch {}
      }
      const result = {
        id: Date.now().toString(36),
        prompt: instruction.trim() || uploadedImage?.name || "Edited photo",
        style: "realistic", size: "1:1", images: [img], ts: Date.now(), mode: "edit",
      };
      setImageHistory(prev => [result, ...prev.slice(0, 99)]);
      setSavedFlag(true);
      setTimeout(() => setSavedFlag(false), 2000);
    } catch { setError(t.editErrorTryAgain); }
  }
  function downloadCurrent() {
    if (!workingUrl) return;
    const a = document.createElement("a");
    a.href = workingUrl; a.download = `novexa-edit-${Date.now()}.png`; a.click();
  }
  async function shareCurrent() {
    if (workingUrl && navigator.share) {
      try {
        const resp = await fetch(workingUrl);
        const blob = await resp.blob();
        const file = new File([blob], "novexa-edit.png", { type: "image/png" });
        await navigator.share({ files: [file], title: "Novexa AI Edit" });
        return;
      } catch (e) {}
    }
    setError(t.shareNotSupported || "Copied to clipboard!");
    setTimeout(() => setError(""), 1800);
  }

  return (
    <>
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(!sidebarOpen)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.editTitle}</div>
          <div className="nx-topbar-sub">{t.editSubtitle}</div>
        </div>
      </div>

      <div className="nx-img-layout">
        {/* LEFT PANEL */}
        <div className="nx-img-panel">
          <div>
            <h2 className="nx-img-panel-title">🖼️ {t.editTitle}</h2>
            <p className="nx-img-panel-sub">{t.editSubtitle}</p>
          </div>

          {!imageApiKey && (
            <div className="nx-img-api-note">
              <Image size={14} style={{ flexShrink: 0, marginTop: 2 }} />
              <span>{t.editApiKeyNote}</span>
            </div>
          )}

          {!uploadedImage ? (
            <div
              className={`nx-i2i-upload-zone${dragging ? " drag" : ""}`}
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
            >
              <UploadCloud size={28} />
              <h4>{t.editUploadTitle}</h4>
              <p>{t.editUploadSub}</p>
              <p style={{ fontSize: 10.5, opacity: .8 }}>{t.editUploadHint}</p>
              <input ref={fileInputRef} type="file" accept={EDIT_ACCEPTED_TYPES.join(",")} hidden
                onChange={(e) => handleFile(e.target.files?.[0])} />
            </div>
          ) : (
            <>
              <div className="nx-edit-toolbar-row">
                <button className="nx-btn nx-btn-ghost" style={{ flex: 1, fontSize: 12 }} onClick={() => fileInputRef.current?.click()}>
                  <ImagePlus size={13} /> {t.editChangeImage}
                </button>
                <button className="nx-btn nx-btn-ghost" style={{ flex: 1, fontSize: 12 }} onClick={resetToOriginal}>
                  <RotateCcw size={13} /> {t.editStartOver}
                </button>
                <input ref={fileInputRef} type="file" accept={EDIT_ACCEPTED_TYPES.join(",")} hidden
                  onChange={(e) => handleFile(e.target.files?.[0])} />
              </div>

              {/* One-click tools */}
              <div>
                <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.editOneClickLabel}</div>
                <div className="nx-edit-tool-grid">
                  {EDIT_TOOLS.map(tool => (
                    <button key={tool.id} className="nx-edit-tool-btn" disabled={!!busyTool} onClick={() => runOneClickTool(tool.id)}>
                      {busyTool === tool.id ? <Loader2 size={16} className="nx-spin" /> : <span className="nx-edit-tool-icon">{tool.icon}</span>}
                      <span>{t[`editTool${tool.id.charAt(0).toUpperCase() + tool.id.slice(1)}`] || tool.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Instruction-based edit */}
              <div>
                <div className="nx-section-label" style={{ margin: "0 0 6px" }}>{t.editInstructionLabel}</div>
                <textarea className="nx-img-prompt" placeholder={t.editInstructionPlaceholder}
                  value={instruction} onChange={(e) => setInstruction(e.target.value)} />
                <button className="nx-img-gen-btn" style={{ marginTop: 8 }} disabled={applying || !instruction.trim()}
                  onClick={() => applyAIEdit(instruction)}>
                  {applying ? <><Loader2 size={16} className="nx-spin" /> {t.editApplying}</> : <><Wand2 size={16} /> {t.editApplyBtn}</>}
                </button>
              </div>

              {/* Crop / Resize / Rotate */}
              <div>
                <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.editTransformLabel}</div>
                <div className="nx-img-mode-tabs">
                  <button className={`nx-img-mode-tab${transformTab === "crop" ? " active" : ""}`} onClick={() => setTransformTab("crop")}>
                    <Crop size={14} /> {t.editCropTab}
                  </button>
                  <button className={`nx-img-mode-tab${transformTab === "resize" ? " active" : ""}`} onClick={() => setTransformTab("resize")}>
                    <Maximize2 size={14} /> {t.editResizeTab}
                  </button>
                  <button className={`nx-img-mode-tab${transformTab === "rotate" ? " active" : ""}`} onClick={() => setTransformTab("rotate")}>
                    <RefreshCw size={14} /> {t.editRotateTab}
                  </button>
                </div>

                {transformTab === "crop" && (
                  <div style={{ marginTop: 10 }}>
                    <p className="nx-i2i-note">{t.editCropHint}</p>
                    <button className="nx-img-gen-btn" style={{ marginTop: 8 }} disabled={busyTool === "crop"} onClick={applyCrop}>
                      {busyTool === "crop" ? <Loader2 size={16} className="nx-spin" /> : <Crop size={16} />} {t.editApplyCrop}
                    </button>
                  </div>
                )}
                {transformTab === "resize" && (
                  <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8 }}>
                    <div style={{ display: "flex", gap: 8 }}>
                      <div className="nx-field" style={{ flex: 1 }}>
                        <label>{t.editWidthLabel}</label>
                        <input className="nx-input" type="number" value={resizeW} onChange={(e) => onResizeWChange(e.target.value)} />
                      </div>
                      <div className="nx-field" style={{ flex: 1 }}>
                        <label>{t.editHeightLabel}</label>
                        <input className="nx-input" type="number" value={resizeH} onChange={(e) => onResizeHChange(e.target.value)} />
                      </div>
                    </div>
                    <label className="nx-edit-checkbox-row">
                      <input type="checkbox" checked={lockAspect} onChange={(e) => setLockAspect(e.target.checked)} /> {t.editLockAspect}
                    </label>
                    <button className="nx-img-gen-btn" disabled={busyTool === "resize"} onClick={applyResize}>
                      {busyTool === "resize" ? <Loader2 size={16} className="nx-spin" /> : <Maximize2 size={16} />} {t.editApplyResize}
                    </button>
                  </div>
                )}
                {transformTab === "rotate" && (
                  <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8 }}>
                    <div style={{ display: "flex", gap: 8 }}>
                      <button className="nx-btn nx-btn-ghost" style={{ flex: 1, fontSize: 12 }} disabled={busyTool === "rotate"} onClick={() => applyRotateBy(-90)}>
                        <RotateCcw size={14} /> {t.editRotateLeft}
                      </button>
                      <button className="nx-btn nx-btn-ghost" style={{ flex: 1, fontSize: 12 }} disabled={busyTool === "rotate"} onClick={() => applyRotateBy(90)}>
                        <RotateCcw size={14} style={{ transform: "scaleX(-1)" }} /> {t.editRotateRight}
                      </button>
                    </div>
                    <div className="nx-i2i-strength-row" style={{ "--pct": ((rotatePreview + 45) / 90) * 100 }}>
                      <input type="range" min={-45} max={45} step={1} value={rotatePreview}
                        onChange={(e) => setRotatePreview(parseInt(e.target.value))} />
                    </div>
                    <div className="nx-i2i-strength-labels"><span>-45°</span><span>{rotatePreview}°</span><span>+45°</span></div>
                    <button className="nx-img-gen-btn" disabled={busyTool === "rotate" || rotatePreview === 0} onClick={() => applyRotateBy(rotatePreview)}>
                      {busyTool === "rotate" ? <Loader2 size={16} className="nx-spin" /> : <RefreshCw size={16} />} {t.editApplyRotate}
                    </button>
                  </div>
                )}
              </div>

              <div style={{ display: "flex", gap: 6 }}>
                <button className="nx-btn nx-btn-ghost" style={{ flex: 1, fontSize: 12 }} disabled={historyIdx <= 0} onClick={undo}>
                  <ArrowLeft size={13} /> {t.editUndo}
                </button>
                <button className="nx-btn nx-btn-ghost" style={{ flex: 1, fontSize: 12 }} disabled={historyIdx >= historyStack.length - 1} onClick={redo}>
                  <ArrowLeft size={13} style={{ transform: "scaleX(-1)" }} /> {t.editRedo}
                </button>
              </div>
            </>
          )}

          {error && (
            <div className="nx-banner" style={{ margin: 0 }}>
              <AlertCircle size={14} />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* RIGHT: preview */}
        <div className="nx-img-main">
          {!uploadedImage ? (
            <div className="nx-img-empty">
              <div className="nx-img-empty-icon">🖼️</div>
              <h3>{t.editTitle}</h3>
              <p>{t.editNoImage}</p>
            </div>
          ) : (
            <div className="nx-edit-canvas-wrap">
              {transformTab === "crop" ? (
                <div className="nx-edit-crop-stage" ref={cropBoxRef}>
                  <img src={workingUrl} alt="Editing" draggable={false} />
                  <div
                    className="nx-edit-crop-box"
                    style={{ left: `${crop.x * 100}%`, top: `${crop.y * 100}%`, width: `${crop.w * 100}%`, height: `${crop.h * 100}%` }}
                    onPointerDown={(e) => onCropPointerDown(e, "move")}
                  >
                    <span className="nx-edit-crop-handle nw" onPointerDown={(e) => { e.stopPropagation(); onCropPointerDown(e, "nw"); }} />
                    <span className="nx-edit-crop-handle se" onPointerDown={(e) => { e.stopPropagation(); onCropPointerDown(e, "se"); }} />
                  </div>
                </div>
              ) : (
                <img className="nx-edit-preview-img" src={workingUrl} alt="Editing"
                  style={{ transform: `rotate(${rotatePreview}deg)` }} />
              )}

              {demoDesc && (
                <div className="nx-edit-demo-card">
                  <div className="nx-edit-demo-card-title">✨ {t.editApiKeyNote}</div>
                  <p>{demoDesc}</p>
                </div>
              )}

              <div className="nx-edit-action-row">
                <button className="nx-btn nx-btn-ghost" onClick={downloadCurrent}><Download size={14} /> {t.editDownload}</button>
                <button className="nx-btn nx-btn-ghost" onClick={shareCurrent}><Share2 size={14} /> {t.editShare}</button>
                <button className="nx-btn nx-btn-primary" onClick={saveToGallery}>
                  {savedFlag ? <><Check size={14} /> {t.editSavedToGallery}</> : <><Grid3x3 size={14} /> {t.editSaveToGallery}</>}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

/* ============================== v1.8: Text-to-Video Generator (Feature 76) ============================== */
function VideoGenDashboard({ t, callAI, imageApiKey, videoModel, videoHistory, setVideoHistory, sidebarOpen, setSidebarOpen, galleryCloudSync }) {
  const [prompt, setPrompt] = useState("");
  const [activeStyle, setActiveStyle] = useState(VIDEO_STYLES[0].id);
  const [activeSize, setActiveSize] = useState(VIDEO_SIZES[0].id);
  const [duration, setDuration] = useState(VIDEO_DURATIONS[1]);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState("");
  const [currentResult, setCurrentResult] = useState(null); // {id, prompt, style, size, duration, video:{url,isDemo,desc}, ts}
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const styleObj = VIDEO_STYLES.find(s => s.id === activeStyle) || VIDEO_STYLES[0];
  const sizeObj = VIDEO_SIZES.find(s => s.id === activeSize) || VIDEO_SIZES[0];

  async function generateVideo() {
    const finalPrompt = prompt.trim();
    if (!finalPrompt) { setError("Please describe the video you want."); return; }
    setGenerating(true);
    setError("");
    setCurrentResult(null);

    const fullPrompt = `${finalPrompt}, ${styleObj.suffix}`;
    let video = null;

    if (imageApiKey) {
      try {
        const response = await fetch(`https://api-inference.huggingface.co/models/${videoModel}`, {
          method: "POST",
          headers: { "Authorization": `Bearer ${imageApiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            inputs: fullPrompt,
            parameters: { num_frames: duration * 8, width: sizeObj.w, height: sizeObj.h, num_inference_steps: 25 },
          }),
        });
        if (response.ok) {
          const blob = await response.blob();
          const url = URL.createObjectURL(blob);
          video = { url, isDemo: false, desc: "" };
          if (galleryCloudSync) {
            try { const d = await blobToDataURL(blob); if (d.length <= GALLERY_SYNC_MAX_BYTES) video.persisted = d; } catch {}
          }
        } else if (response.status === 503) {
          await new Promise(r => setTimeout(r, 5000));
          const retry = await fetch(`https://api-inference.huggingface.co/models/${videoModel}`, {
            method: "POST",
            headers: { "Authorization": `Bearer ${imageApiKey}`, "Content-Type": "application/json" },
            body: JSON.stringify({ inputs: fullPrompt, parameters: { num_frames: duration * 8, width: sizeObj.w, height: sizeObj.h } }),
          });
          if (retry.ok) {
            const blob = await retry.blob();
            video = { url: URL.createObjectURL(blob), isDemo: false, desc: "" };
          }
        }
      } catch (e) { /* fall through to storyboard demo below */ }
    }

    if (!video) {
      try {
        const shots = Math.max(3, Math.min(6, Math.round(duration / 1.5)));
        const storyboard = await callAI([{
          role: "user",
          content: `You are an AI text-to-video simulator. For the following video prompt, write a shot-by-shot storyboard with exactly ${shots} shots covering a ${duration}-second video. Each shot: one numbered line, vivid and specific, describing camera movement, action, and visual detail. Style: ${styleObj.label}. Aspect ratio: ${sizeObj.label}.\n\nPrompt: "${fullPrompt}"`
        }]);
        video = { url: null, isDemo: true, desc: storyboard.trim() };
      } catch (e) {
        setError(t.vidErrorTryAgain);
        setGenerating(false);
        return;
      }
    }

    const result = { id: Date.now().toString(36), prompt: finalPrompt, style: activeStyle, size: activeSize, duration, video, ts: Date.now() };
    setCurrentResult(result);
    setVideoHistory(prev => [result, ...prev.slice(0, 99)]);
    setGenerating(false);
  }

  function downloadVideo() {
    if (!currentResult) return;
    const v = currentResult.video;
    if (v.isDemo) {
      const blob = new Blob([`Novexa AI — Storyboard Preview\nPrompt: ${currentResult.prompt}\nStyle: ${currentResult.style} · ${currentResult.size} · ${currentResult.duration}s\n\n${v.desc}`], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `novexa-storyboard-${Date.now()}.txt`; a.click();
      URL.revokeObjectURL(url);
    } else {
      const a = document.createElement("a");
      a.href = v.url; a.download = `novexa-video-${Date.now()}.mp4`; a.click();
    }
  }
  async function shareVideo() {
    const v = currentResult?.video;
    if (!v) return;
    if (!v.isDemo && v.url && navigator.share) {
      try {
        const resp = await fetch(v.url);
        const blob = await resp.blob();
        const file = new File([blob], "novexa-video.mp4", { type: blob.type || "video/mp4" });
        await navigator.share({ files: [file], title: "Novexa AI Video" });
        return;
      } catch (e) {}
    }
    try { await navigator.clipboard.writeText(v.isDemo ? v.desc : currentResult.prompt); } catch (e) {}
    setError("Copied to clipboard!");
    setTimeout(() => setError(""), 1800);
  }
  function loadFromHistory(item) {
    setPrompt(item.prompt);
    setActiveStyle(item.style);
    setActiveSize(item.size);
    setDuration(item.duration);
    setCurrentResult(item);
  }
  function deleteFromHistory(id) {
    setVideoHistory(prev => prev.filter(i => i.id !== id));
    if (currentResult?.id === id) setCurrentResult(null);
  }

  return (
    <>
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(!sidebarOpen)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.vidGenTitle}</div>
          <div className="nx-topbar-sub">{t.vidGenSubtitle}</div>
        </div>
      </div>

      {lightboxOpen && currentResult && !currentResult.video.isDemo && (
        <div className="nx-img-lightbox" onClick={() => setLightboxOpen(false)}>
          <video src={currentResult.video.url} controls autoPlay style={{ maxWidth: "90vw", maxHeight: "85vh", borderRadius: "var(--radius-lg)" }}
            onClick={(e) => e.stopPropagation()} />
          <button className="nx-img-lightbox-close" onClick={() => setLightboxOpen(false)}><X size={20} /></button>
        </div>
      )}

      <div className="nx-img-layout">
        {/* LEFT PANEL */}
        <div className="nx-img-panel">
          <div>
            <h2 className="nx-img-panel-title">🎬 {t.vidGenTitle}</h2>
            <p className="nx-img-panel-sub">{t.vidGenSubtitle}</p>
          </div>

          {!imageApiKey && (
            <div className="nx-img-api-note">
              <Clapperboard size={14} style={{ flexShrink: 0, marginTop: 2 }} />
              <span>{t.vidApiKeyNote}</span>
            </div>
          )}

          <div>
            <div className="nx-section-label" style={{ margin: "0 0 6px" }}>{t.vidPromptLabel}</div>
            <textarea className="nx-img-prompt" placeholder={t.vidPromptPlaceholder} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
          </div>

          <div>
            <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.vidStyleLabel}</div>
            <div className="nx-img-style-grid">
              {VIDEO_STYLES.map(s => (
                <button key={s.id} className={`nx-img-style-btn${activeStyle === s.id ? " active" : ""}`} onClick={() => setActiveStyle(s.id)}>
                  <span className="nx-img-style-icon">{s.icon}</span>{s.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.vidSizeLabel}</div>
            <div className="nx-img-size-row">
              {VIDEO_SIZES.map(sz => (
                <button key={sz.id} className={`nx-img-size-btn${activeSize === sz.id ? " active" : ""}`} onClick={() => setActiveSize(sz.id)}>
                  <div className="nx-img-size-preview" style={{
                    width: sz.id === "16:9" ? 36 : sz.id === "9:16" ? 18 : 28,
                    height: sz.id === "9:16" ? 36 : sz.id === "16:9" ? 18 : 28,
                  }} />
                  <div className="nx-img-size-label">{sz.label}</div>
                  <div className="nx-img-size-sub">{sz.sublabel}</div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="nx-section-label" style={{ margin: "0 0 8px" }}>{t.vidDurationLabel}</div>
            <div className="nx-img-count-row">
              {VIDEO_DURATIONS.map(d => (
                <button key={d} className={`nx-img-count-btn${duration === d ? " active" : ""}`} onClick={() => setDuration(d)}>
                  {d}{t.vidSeconds}
                </button>
              ))}
            </div>
          </div>

          <button className="nx-img-gen-btn" onClick={generateVideo} disabled={generating || !prompt.trim()}>
            {generating
              ? <><Loader2 size={18} className="nx-spin" /> {t.vidGenerating}</>
              : <><Clapperboard size={18} /> {t.vidGenerateBtn}</>}
          </button>

          {error && (
            <div className="nx-banner" style={{ margin: 0 }}>
              <AlertCircle size={14} />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* RIGHT: result + history */}
        <div className="nx-img-main">
          {generating ? (
            <div className="nx-img-loading">
              <div className="nx-vid-shimmer" />
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
                <Loader2 size={16} className="nx-spin" /> {t.vidGenerating}
              </div>
            </div>
          ) : currentResult ? (
            <>
              <div className="nx-img-results-header">
                <span className="nx-img-results-title"><Clapperboard size={13} style={{ marginRight: 5 }} />{t.vidGenerated}</span>
              </div>
              <div style={{ padding: "0 20px 12px" }}>
                {currentResult.video.isDemo ? (
                  <div className="nx-vid-storyboard-card">
                    <div className="nx-vid-storyboard-head">
                      <Clapperboard size={16} /> {t.vidStoryboardTitle}
                      <span className="nx-vid-style-chip">{VIDEO_STYLES.find(s => s.id === currentResult.style)?.icon} {VIDEO_STYLES.find(s => s.id === currentResult.style)?.label}</span>
                    </div>
                    <p className="nx-vid-storyboard-note">{t.vidStoryboardNote}</p>
                    <pre className="nx-vid-storyboard-text">{currentResult.video.desc}</pre>
                  </div>
                ) : (
                  <div className="nx-vid-player-wrap" onClick={() => setLightboxOpen(true)}>
                    <video src={currentResult.video.url} controls />
                  </div>
                )}
              </div>

              <div className="nx-img-used-prompt">
                <div className="nx-img-used-prompt-text">
                  <strong style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: ".05em" }}>Prompt: </strong>
                  {currentResult.prompt}
                </div>
                <button className="nx-img-regen-btn" onClick={generateVideo}>
                  <RefreshCw size={12} /> {t.vidRegenerateBtn}
                </button>
              </div>

              <div style={{ padding: "0 20px 20px", display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button className="nx-btn nx-btn-ghost" style={{ fontSize: 12, padding: "7px 12px" }} onClick={downloadVideo}>
                  <Download size={13} /> {t.vidDownload}
                </button>
                <button className="nx-btn nx-btn-ghost" style={{ fontSize: 12, padding: "7px 12px" }} onClick={shareVideo}>
                  <Share2 size={13} /> {t.vidShare}
                </button>
              </div>
            </>
          ) : (
            <div className="nx-img-empty">
              <div className="nx-img-empty-icon">🎬</div>
              <h3>{t.vidGenTitle}</h3>
              <p>{t.vidApiKeyNote}</p>
            </div>
          )}

          {videoHistory.length > 0 && (
            <div className="nx-img-history-section">
              <div className="nx-img-history-header">
                <span className="nx-img-history-title"><History size={13} /> {t.vidHistory}</span>
                <button className="nx-btn nx-btn-ghost" style={{ fontSize: 11, padding: "5px 10px" }}
                  onClick={() => { setVideoHistory([]); setCurrentResult(null); }}>
                  <Trash2 size={12} /> {t.vidClearHistory}
                </button>
              </div>
              <div className="nx-img-history-grid">
                {videoHistory.map(item => {
                  const styleItem = VIDEO_STYLES.find(s => s.id === item.style);
                  return (
                    <div key={item.id} style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                      <div className="nx-img-history-thumb" onClick={() => loadFromHistory(item)}>
                        <div className="nx-img-history-demo">
                          <div className="nx-img-history-demo-icon">{styleItem?.icon || "🎬"}</div>
                          <div className="nx-img-history-demo-style">{item.duration}{t.vidSeconds}</div>
                        </div>
                        <div className="nx-img-history-overlay">
                          <button className="nx-img-hist-icon-btn" onClick={(e) => { e.stopPropagation(); loadFromHistory(item); }} title="Load">
                            <RefreshCw size={13} />
                          </button>
                          <button className="nx-img-hist-icon-btn" onClick={(e) => { e.stopPropagation(); deleteFromHistory(item.id); }} title={t.vidDeleteVideo}>
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                      <div className="nx-img-history-prompt">{item.prompt}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

/* ============================== v1.8: AI Media Gallery (Feature 78) ============================== */
function MediaGalleryDashboard({ t, imageHistory, setImageHistory, videoHistory, setVideoHistory, galleryCloudSync, setGalleryCloudSync, sidebarOpen, setSidebarOpen }) {
  const [query, setQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("all");
  const [lightboxItem, setLightboxItem] = useState(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [toast, setToast] = useState("");

  /* Flatten imageHistory (text/image/audio/edit images) + videoHistory into one list of gallery items */
  const items = [];
  for (const entry of imageHistory) {
    const type = entry.mode === "edit" ? "edit" : "image";
    (entry.images || []).forEach((media, idx) => {
      items.push({
        id: `${entry.id}-${idx}`, parentId: entry.id, parentKey: "images", parentIdx: idx,
        type, prompt: entry.prompt, style: entry.style, ts: entry.ts, media,
      });
    });
  }
  for (const entry of videoHistory) {
    items.push({
      id: entry.id, parentId: entry.id, parentKey: "video", parentIdx: null,
      type: "video", prompt: entry.prompt, style: entry.style, ts: entry.ts, media: entry.video,
    });
  }
  items.sort((a, b) => b.ts - a.ts);

  const filtered = items
    .filter(it => activeFilter === "all" || it.type === activeFilter)
    .filter(it => !query.trim() || (it.prompt || "").toLowerCase().includes(query.trim().toLowerCase()));

  function typeIcon(type) {
    return type === "video" ? <Clapperboard size={13} /> : type === "edit" ? <Crop size={13} /> : <Image size={13} />;
  }
  function typeLabel(type) {
    return type === "video" ? t.galleryTypeVideo : type === "edit" ? t.galleryTypeEdit : t.galleryTypeImage;
  }
  function styleIcon(item) {
    const arr = item.type === "video" ? VIDEO_STYLES : IMAGE_STYLES;
    return arr.find(s => s.id === item.style)?.icon || (item.type === "video" ? "🎬" : "🎨");
  }

  function deleteItem(item) {
    if (item.type === "video") {
      setVideoHistory(prev => prev.filter(v => v.id !== item.parentId));
    } else {
      setImageHistory(prev => prev
        .map(entry => entry.id === item.parentId
          ? { ...entry, images: entry.images.filter((_, i) => i !== item.parentIdx) }
          : entry)
        .filter(entry => entry.images.length > 0));
    }
    if (lightboxItem?.id === item.id) setLightboxItem(null);
  }
  function clearAll() {
    setImageHistory([]);
    setVideoHistory([]);
    setConfirmClear(false);
    setLightboxItem(null);
  }
  function downloadItem(item) {
    const m = item.media;
    if (m.isDemo) {
      const blob = new Blob([m.desc || ""], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `novexa-${item.type}-${Date.now()}.txt`; a.click();
      URL.revokeObjectURL(url);
    } else if (m.url) {
      const a = document.createElement("a");
      a.href = m.url; a.download = `novexa-${item.type}-${Date.now()}.${item.type === "video" ? "mp4" : "png"}`; a.click();
    }
  }
  async function shareItem(item) {
    const m = item.media;
    if (!m.isDemo && m.url && navigator.share) {
      try {
        const resp = await fetch(m.url);
        const blob = await resp.blob();
        const file = new File([blob], `novexa-${item.type}.${item.type === "video" ? "mp4" : "png"}`, { type: blob.type });
        await navigator.share({ files: [file], title: "Novexa AI Media" });
        return;
      } catch (e) {}
    }
    try { await navigator.clipboard.writeText(m.isDemo ? (m.desc || "") : item.prompt); } catch (e) {}
    setToast(t.shareNotSupported || "Copied to clipboard!");
    setTimeout(() => setToast(""), 1800);
  }

  return (
    <>
      <div className="nx-topbar">
        <button className="nx-btn-icon nx-menu-btn" onClick={() => setSidebarOpen(!sidebarOpen)}><Menu size={19} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="nx-topbar-title">{t.galleryTitle}</div>
          <div className="nx-topbar-sub">{t.gallerySubtitle}</div>
        </div>
      </div>

      {lightboxItem && (
        <div className="nx-img-lightbox" onClick={() => setLightboxItem(null)}>
          {lightboxItem.media.isDemo ? (
            <div style={{ maxWidth: 480, background: "var(--surface)", borderRadius: 16, padding: 32, color: "var(--text)" }} onClick={(e) => e.stopPropagation()}>
              <div style={{ fontSize: 36, marginBottom: 16, textAlign: "center" }}>{styleIcon(lightboxItem)}</div>
              <p style={{ margin: 0, lineHeight: 1.6, whiteSpace: "pre-wrap" }}>{lightboxItem.media.desc}</p>
            </div>
          ) : lightboxItem.type === "video" ? (
            <video src={lightboxItem.media.url} controls autoPlay style={{ maxWidth: "90vw", maxHeight: "85vh", borderRadius: "var(--radius-lg)" }} onClick={(e) => e.stopPropagation()} />
          ) : (
            <img src={lightboxItem.media.url} alt="Media" onClick={(e) => e.stopPropagation()} />
          )}
          <button className="nx-img-lightbox-close" onClick={() => setLightboxItem(null)}><X size={20} /></button>
        </div>
      )}

      <div className="nx-gallery-wrap">
        <div className="nx-gallery-toolbar">
          <div className="nx-gallery-search">
            <Search size={15} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t.gallerySearchPlaceholder} />
          </div>
          <div className="nx-gallery-filters">
            {GALLERY_FILTERS.map(f => (
              <button key={f} className={`nx-chip${activeFilter === f ? " active" : ""}`} onClick={() => setActiveFilter(f)}>
                {f === "all" ? t.galleryFilterAll : f === "image" ? t.galleryFilterImage : f === "video" ? t.galleryFilterVideo : t.galleryFilterEdit}
              </button>
            ))}
          </div>
          <div className="nx-gallery-toolbar-right">
            <span className="nx-gallery-count">{t.galleryItemCount(filtered.length)}</span>
            {items.length > 0 && (
              confirmClear ? (
                <div className="nx-confirm-row">
                  <span>{t.galleryConfirmClearAll}</span>
                  <button className="nx-btn-icon" onClick={clearAll}><Check size={14} /></button>
                  <button className="nx-btn-icon" onClick={() => setConfirmClear(false)}><X size={14} /></button>
                </div>
              ) : (
                <button className="nx-btn nx-btn-ghost" style={{ fontSize: 12, padding: "6px 10px" }} onClick={() => setConfirmClear(true)}>
                  <Trash2 size={13} /> {t.galleryClearAll}
                </button>
              )
            )}
          </div>
        </div>

        {/* Cloud Sync toggle */}
        <div className="nx-gallery-sync-row">
          <div>
            <div className="nx-gallery-sync-label"><Cloud size={14} /> {t.galleryCloudSyncLabel}</div>
            <p className="nx-i2i-note" style={{ margin: "2px 0 0" }}>{t.galleryCloudSyncHint}</p>
          </div>
          <div className="nx-pill-group">
            <button className={`nx-pill${!galleryCloudSync ? " active" : ""}`} onClick={() => setGalleryCloudSync(false)}>{t.galleryCloudSyncOff}</button>
            <button className={`nx-pill${galleryCloudSync ? " active" : ""}`} onClick={() => setGalleryCloudSync(true)}>{t.galleryCloudSyncOn}</button>
          </div>
        </div>

        {toast && <div className="nx-banner" style={{ margin: "0 20px" }}><Check size={14} /><span>{toast}</span></div>}

        {/* Grid */}
        {items.length === 0 ? (
          <div className="nx-img-empty">
            <div className="nx-img-empty-icon">🗂️</div>
            <h3>{t.galleryTitle}</h3>
            <p>{t.galleryEmpty}</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="nx-img-empty">
            <div className="nx-img-empty-icon">🔍</div>
            <p>{t.galleryNoResults}</p>
          </div>
        ) : (
          <div className="nx-gallery-grid">
            {filtered.map(item => (
              <div key={item.id} className="nx-img-card nx-gallery-card">
                <span className="nx-gallery-type-badge">{typeIcon(item.type)} {typeLabel(item.type)}</span>
                {item.media.isDemo ? (
                  <div className="nx-img-demo-placeholder" style={{ aspectRatio: item.type === "video" ? "16/9" : "1" }}>
                    <div className="nx-img-demo-icon">{styleIcon(item)}</div>
                    <div className="nx-img-demo-desc">{(item.media.desc || "").slice(0, 90)}{(item.media.desc || "").length > 90 ? "…" : ""}</div>
                  </div>
                ) : item.type === "video" ? (
                  <div className="nx-gallery-video-thumb">
                    <video src={item.media.url} muted />
                    <PlayCircle size={28} className="nx-gallery-play-icon" />
                  </div>
                ) : item.media.url ? (
                  <img src={item.media.url} alt={item.prompt} />
                ) : (
                  <div className="nx-img-demo-placeholder">
                    <div className="nx-img-demo-icon">🖼️</div>
                    <div className="nx-img-demo-desc" style={{ fontSize: 11, opacity: .7 }}>Preview expired — regenerate to view again</div>
                  </div>
                )}
                <div className="nx-img-card-actions">
                  <button className="nx-img-action-btn" onClick={() => setLightboxItem(item)} title={t.galleryViewFull}>
                    <ZoomIn size={12} /> {t.galleryViewFull}
                  </button>
                  <button className="nx-img-action-btn" onClick={() => downloadItem(item)} title={t.galleryDownload}>
                    <Download size={12} /> {t.galleryDownload}
                  </button>
                  <button className="nx-img-action-btn" onClick={() => shareItem(item)} title={t.galleryShare}>
                    <Share2 size={12} /> {t.galleryShare}
                  </button>
                  <button className="nx-img-action-btn" onClick={() => deleteItem(item)} title={t.galleryDelete}>
                    <Trash2 size={12} /> {t.galleryDelete}
                  </button>
                </div>
                <div className="nx-gallery-card-prompt">{item.prompt}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

/* ============================ Plans Modal ============================ */
function PlansModal({ userPlan, usageToday, onUpgrade, onClose }) {
  const plan = PLANS[userPlan];
  const msgPct = Math.min(100, (usageToday.messages / plan.limits.messages) * 100);

  return (
    <div className="nx-modal-overlay" onClick={onClose}>
      <div className="nx-modal" style={{maxWidth: 480}} onClick={(e) => e.stopPropagation()}>
        <div className="nx-modal-head">
          <h3 style={{margin:0}}>⚡ Novexa Plans</h3>
          <button className="nx-btn-icon" onClick={onClose}><X size={18} /></button>
        </div>

        {/* Usage bar */}
        <div className="nx-usage-bar-wrap">
          <div className="nx-usage-label">
            <span>Messages today</span>
            <span>{usageToday.messages} / {plan.limits.messages === 99999 ? "∞" : plan.limits.messages}</span>
          </div>
          <div className="nx-usage-bar">
            <div className="nx-usage-fill" style={{width: `${msgPct}%`, background: plan.color}} />
          </div>
        </div>

        <div className="nx-plans-grid">
          {Object.values(PLANS).map((p) => (
            <div key={p.id} className={`nx-plan-card${p.popular ? " popular" : ""}${p.id === userPlan ? " current" : ""}`}>
              {p.popular && <div className="nx-plan-popular-tag">🔥 Most Popular</div>}
              <div className="nx-plan-badge" style={{background: p.color}}>{p.badge}</div>
              <div className="nx-plan-name">{p.name}</div>
              <div className="nx-plan-price">{p.price}<span>{p.period}</span></div>
              <ul className="nx-plan-features">
                {p.features.map((f, i) => <li key={i}>{f}</li>)}
              </ul>
              {p.id === userPlan ? (
                <button className="nx-plan-btn active">✓ Current Plan</button>
              ) : (
                <button
                  className="nx-plan-btn upgrade"
                  style={{background: p.color}}
                  onClick={() => {
                    alert(`🚧 Payment coming soon!\n\nFor now, plan switched to ${p.name} (demo mode).`);
                    onUpgrade(p.id);
                  }}
                >
                  {p.id === "free" ? "Downgrade" : `Upgrade to ${p.name} →`}
                </button>
              )}
            </div>
          ))}
        </div>

        <p style={{fontSize:11, color:"var(--text-muted)", textAlign:"center", marginTop:14}}>
          💳 UPI / Card payment integration coming soon. Plans are in demo mode.
        </p>
      </div>
    </div>
  );
}

/* ============================ Dream11 AI Panel ============================ */
function Dream11Panel({ callAI, sidebarOpen, setSidebarOpen, lang }) {
  const [team1, setTeam1] = useState("");
  const [team2, setTeam2] = useState("");
  const [matchType, setMatchType] = useState("T20");
  const [pitch, setPitch] = useState("balanced");
  const [credits, setCredits] = useState(100);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [activeTab, setActiveTab] = useState("team");

  const MATCH_TYPES = ["T20", "ODI", "Test", "T10"];
  const PITCH_TYPES = ["batting", "bowling", "balanced", "spin"];

  async function generatePrediction() {
    if (!team1.trim() || !team2.trim()) return alert("Dono team ka naam likho!");
    setLoading(true);
    setResult(null);
    try {
      const prompt = `You are a Dream11 fantasy cricket expert AI. Generate a detailed Dream11 team prediction for:

Match: ${team1} vs ${team2}
Format: ${matchType}
Pitch: ${pitch} friendly
Credits available: ${credits}

Respond ONLY in JSON format (no markdown, no backticks):
{
  "captain": {"name": "player name", "team": "team name", "role": "WK/BAT/AR/BOWL", "credits": 9.5, "reason": "why captain"},
  "vice_captain": {"name": "player name", "team": "team name", "role": "WK/BAT/AR/BOWL", "credits": 9.0, "reason": "why vc"},
  "playing11": [
    {"name": "player name", "team": "team name", "role": "WK/BAT/AR/BOWL", "credits": 8.5, "selected": true}
  ],
  "team_composition": {"wk": 1, "bat": 4, "ar": 2, "bowl": 4},
  "total_credits": 98.5,
  "win_prediction": "${team1} 60% | ${team2} 40%",
  "key_tips": ["tip1", "tip2", "tip3"],
  "pitch_analysis": "brief pitch analysis",
  "differential_pick": {"name": "player name", "reason": "low ownership high impact"}
}`;

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }]
        })
      });
      const data = await res.json();
      const text = data.content?.map(c => c.text || "").join("") || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setResult(parsed);
    } catch (e) {
      alert("Prediction generate karne mein error aaya. Dobara try karo.");
    }
    setLoading(false);
  }

  const roleColor = (role) => {
    if (role === "WK") return "#7c3aed";
    if (role === "BAT") return "#2563eb";
    if (role === "AR") return "#d97706";
    if (role === "BOWL") return "#16a34a";
    return "#6b7280";
  };

  return (
    <div style={{display:"flex", flexDirection:"column", height:"100%", background:"var(--bg)", overflowY:"auto"}}>
      {/* Header */}
      <div style={{background:"linear-gradient(135deg,#16a34a,#15803d)", padding:"16px 18px", display:"flex", alignItems:"center", gap:12}}>
        <button style={{background:"none", border:"none", color:"#fff", cursor:"pointer"}} onClick={() => setSidebarOpen(!sidebarOpen)}>
          <Menu size={20} />
        </button>
        <div>
          <div style={{color:"#fff", fontWeight:700, fontSize:18}}>🏏 Dream11 AI Predictor</div>
          <div style={{color:"rgba(255,255,255,.75)", fontSize:12}}>AI-powered fantasy team generator</div>
        </div>
      </div>

      <div style={{padding:"16px", maxWidth:600, margin:"0 auto", width:"100%"}}>
        {/* Input Form */}
        <div style={{background:"var(--surface)", borderRadius:16, padding:16, marginBottom:14, border:"1px solid var(--border)"}}>
          <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12}}>
            <div>
              <label style={{fontSize:12, color:"var(--text-muted)", fontWeight:600}}>TEAM 1</label>
              <input value={team1} onChange={e => setTeam1(e.target.value)}
                placeholder="e.g. India, CSK, MI"
                style={{width:"100%", padding:"8px 10px", borderRadius:8, border:"1px solid var(--border)", background:"var(--bg)", color:"var(--text)", fontSize:14, marginTop:4, boxSizing:"border-box"}} />
            </div>
            <div>
              <label style={{fontSize:12, color:"var(--text-muted)", fontWeight:600}}>TEAM 2</label>
              <input value={team2} onChange={e => setTeam2(e.target.value)}
                placeholder="e.g. Australia, RCB, DC"
                style={{width:"100%", padding:"8px 10px", borderRadius:8, border:"1px solid var(--border)", background:"var(--bg)", color:"var(--text)", fontSize:14, marginTop:4, boxSizing:"border-box"}} />
            </div>
          </div>

          <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12}}>
            <div>
              <label style={{fontSize:12, color:"var(--text-muted)", fontWeight:600}}>FORMAT</label>
              <div style={{display:"flex", gap:4, marginTop:4, flexWrap:"wrap"}}>
                {MATCH_TYPES.map(m => (
                  <button key={m} onClick={() => setMatchType(m)}
                    style={{padding:"4px 10px", borderRadius:6, border:"1px solid var(--border)", background: matchType === m ? "#16a34a" : "var(--bg)", color: matchType === m ? "#fff" : "var(--text)", fontSize:12, cursor:"pointer", fontWeight:600}}>
                    {m}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label style={{fontSize:12, color:"var(--text-muted)", fontWeight:600}}>PITCH</label>
              <div style={{display:"flex", gap:4, marginTop:4, flexWrap:"wrap"}}>
                {PITCH_TYPES.map(p => (
                  <button key={p} onClick={() => setPitch(p)}
                    style={{padding:"4px 8px", borderRadius:6, border:"1px solid var(--border)", background: pitch === p ? "#d97706" : "var(--bg)", color: pitch === p ? "#fff" : "var(--text)", fontSize:11, cursor:"pointer", fontWeight:600, textTransform:"capitalize"}}>
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button onClick={generatePrediction} disabled={loading}
            style={{width:"100%", padding:"12px", borderRadius:10, border:"none", background:"linear-gradient(135deg,#16a34a,#15803d)", color:"#fff", fontWeight:700, fontSize:15, cursor: loading ? "wait" : "pointer", opacity: loading ? .7 : 1}}>
            {loading ? "🔄 AI generating team..." : "⚡ Generate Dream11 Team"}
          </button>
        </div>

        {/* Results */}
        {result && (
          <div>
            {/* Win Prediction */}
            <div style={{background:"linear-gradient(135deg,#16a34a22,#15803d11)", border:"1px solid #16a34a44", borderRadius:12, padding:14, marginBottom:12, textAlign:"center"}}>
              <div style={{fontSize:12, color:"var(--text-muted)", marginBottom:4}}>WIN PREDICTION</div>
              <div style={{fontWeight:700, fontSize:16}}>{result.win_prediction}</div>
              <div style={{fontSize:12, color:"var(--text-muted)", marginTop:4}}>{result.pitch_analysis}</div>
            </div>

            {/* Tabs */}
            <div style={{display:"flex", gap:6, marginBottom:12}}>
              {["team","captain","tips","differential"].map(tab => (
                <button key={tab} onClick={() => setActiveTab(tab)}
                  style={{flex:1, padding:"7px 4px", borderRadius:8, border:"1px solid var(--border)", background: activeTab === tab ? "#16a34a" : "var(--surface)", color: activeTab === tab ? "#fff" : "var(--text)", fontSize:11, fontWeight:600, cursor:"pointer", textTransform:"capitalize"}}>
                  {tab === "team" ? "🏏 Team" : tab === "captain" ? "⭐ C/VC" : tab === "tips" ? "💡 Tips" : "🎯 Diff"}
                </button>
              ))}
            </div>

            {/* Team tab */}
            {activeTab === "team" && (
              <div style={{background:"var(--surface)", borderRadius:12, border:"1px solid var(--border)", overflow:"hidden"}}>
                <div style={{padding:"10px 14px", background:"var(--surface-2)", display:"flex", justifyContent:"space-between", alignItems:"center"}}>
                  <span style={{fontWeight:700, fontSize:13}}>Playing 11</span>
                  <span style={{fontSize:12, color:"var(--text-muted)"}}>💰 {result.total_credits} cr used</span>
                </div>
                {result.playing11?.map((p, i) => (
                  <div key={i} style={{display:"flex", alignItems:"center", padding:"10px 14px", borderBottom:"1px solid var(--border)", gap:10}}>
                    <div style={{width:28, height:28, borderRadius:"50%", background: roleColor(p.role), display:"flex", alignItems:"center", justifyContent:"center", fontSize:9, color:"#fff", fontWeight:700, flexShrink:0}}>
                      {p.role}
                    </div>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:600, fontSize:13}}>{p.name}</div>
                      <div style={{fontSize:11, color:"var(--text-muted)"}}>{p.team}</div>
                    </div>
                    <div style={{fontSize:12, fontWeight:700, color:"#d97706"}}>{p.credits} cr</div>
                  </div>
                ))}
                <div style={{padding:"10px 14px", display:"flex", gap:12, justifyContent:"center"}}>
                  {Object.entries(result.team_composition || {}).map(([role, count]) => (
                    <span key={role} style={{fontSize:11, fontWeight:700, color: roleColor(role.toUpperCase())}}>
                      {role.toUpperCase()}: {count}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Captain tab */}
            {activeTab === "captain" && (
              <div style={{display:"flex", flexDirection:"column", gap:10}}>
                {[{label:"⭐ CAPTAIN", data: result.captain, bg:"#d97706"}, {label:"🔸 VICE CAPTAIN", data: result.vice_captain, bg:"#7c3aed"}].map(({label, data, bg}) => (
                  <div key={label} style={{background:"var(--surface)", borderRadius:12, border:"2px solid " + bg, padding:16}}>
                    <div style={{fontSize:11, fontWeight:700, color:bg, marginBottom:8}}>{label}</div>
                    <div style={{display:"flex", alignItems:"center", gap:10}}>
                      <div style={{width:44, height:44, borderRadius:"50%", background:bg, display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontWeight:700, fontSize:12}}>
                        {data?.role}
                      </div>
                      <div>
                        <div style={{fontWeight:700, fontSize:15}}>{data?.name}</div>
                        <div style={{fontSize:12, color:"var(--text-muted)"}}>{data?.team} · {data?.credits} cr</div>
                      </div>
                    </div>
                    <div style={{marginTop:10, fontSize:13, color:"var(--text-muted)", background:"var(--surface-2)", borderRadius:8, padding:10}}>
                      💡 {data?.reason}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Tips tab */}
            {activeTab === "tips" && (
              <div style={{background:"var(--surface)", borderRadius:12, border:"1px solid var(--border)", padding:14}}>
                <div style={{fontWeight:700, marginBottom:12}}>💡 Key Tips</div>
                {result.key_tips?.map((tip, i) => (
                  <div key={i} style={{display:"flex", gap:10, padding:"8px 0", borderBottom:"1px solid var(--border)"}}>
                    <div style={{width:22, height:22, borderRadius:"50%", background:"#16a34a", color:"#fff", fontSize:11, fontWeight:700, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0}}>
                      {i+1}
                    </div>
                    <div style={{fontSize:13}}>{tip}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Differential tab */}
            {activeTab === "differential" && result.differential_pick && (
              <div style={{background:"linear-gradient(135deg,#7c3aed22,#7c3aed11)", border:"2px solid #7c3aed44", borderRadius:12, padding:16}}>
                <div style={{fontSize:12, fontWeight:700, color:"#7c3aed", marginBottom:8}}>🎯 DIFFERENTIAL PICK</div>
                <div style={{fontWeight:700, fontSize:17}}>{result.differential_pick.name}</div>
                <div style={{fontSize:13, color:"var(--text-muted)", marginTop:8}}>{result.differential_pick.reason}</div>
                <div style={{marginTop:10, fontSize:11, background:"rgba(124,58,237,.1)", borderRadius:8, padding:8, color:"#7c3aed", fontWeight:600}}>
                  ⚡ Low ownership = High reward if performs!
                </div>
              </div>
            )}

            <p style={{fontSize:11, color:"var(--text-muted)", textAlign:"center", marginTop:12}}>
              ⚠️ Sirf entertainment ke liye. Real money invest karne se pehle apni research karein.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
